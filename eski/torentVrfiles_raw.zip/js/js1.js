let isSeeking \u003d false\u003b
        let isHardSeeking \u003d false\u003b \u002f\u002f \u2705 FIX\u003a syncVideo ve listenKeyframes \u00e7ak\u0131\u015fmas\u0131n\u0131 \u00f6nlemek i\u00e7in

        
        \u002f\u002f \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d CONFIG \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d
        \u002f\u002f Firebase Yap\u0131land\u0131rmas\u0131
const firebaseConfig \u003d \u007b
    apiKey\u003a \u0022AIzaSyC60idSLdAiqAjPWAOMaM3g8LAKPGEUwH8\u0022\u002c
    authDomain\u003a \u0022vr-sinema.firebaseapp.com\u0022\u002c
    databaseURL\u003a \u0022https\u003a\u002f\u002fvr-sinema-default-rtdb.firebaseio.com\u0022\u002c
    projectId\u003a \u0022vr-sinema\u0022\u002c
    storageBucket\u003a \u0022vr-sinema.firebasestorage.app\u0022\u002c
    messagingSenderId\u003a \u0022724648238300\u0022\u002c
    appId\u003a \u00221\u003a724648238300\u003aweb\u003adceba8c536e8a5ffd96819\u0022
\u007d\u003b
        
        \u002f\u002f \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d OPTIMIZED CONSTANTS \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d
        const SYNCCHECKINTERVAL \u003d 750\u003b \u002f\u002f \u2705 FIX\u003a drift timing sorunu i\u00e7in art\u0131r\u0131ld\u0131
        const KEYFRAME_INTERVAL \u003d 10000\u003b
        const CLOCK_SYNC_INTERVAL \u003d 60000\u003b
        const DRIFT_UPDATE_INTERVAL \u003d 10000\u003b
        const PRESENCE_UPDATE_INTERVAL \u003d 30000\u003b
        const CLEANUP_INTERVAL \u003d 10000\u003b
        const PLAY_BUFFER_TIME \u003d 5000\u003b
        const PRELOAD_BUFFER_SECONDS \u003d 9\u003b \u002f\u002f \u2705 FIX\u003a 7 -\u003e 9 saniye buffer
        
        \u002f\u002f Optimized thresholds
        const TIER1_THRESHOLD \u003d 300\u003b
        const TIER2_THRESHOLD \u003d 800\u003b
        const TIER3_THRESHOLD \u003d 1500\u003b
        const TIER2_LAGGING_SPEED \u003d 1.05\u003b
        const TIER3_LAGGING_SPEED \u003d 1.15\u003b
        
        \u002f\u002f Hard seek throttle sabitleri
        const LARGE_DRIFT_THRESHOLD \u003d 9000\u003b \u002f\u002f \u2705 FIX\u003a 3000 -\u003e 9000ms \u00289sn sonra hard seek\u0029
        const HARD_SEEK_MIN_INTERVAL \u003d 2000\u003b
        
        const OWNER_PRESENCE_UPDATE_INTERVAL \u003d 30000\u003b
        const OWNER_PRESENCE_TIMEOUT \u003d 45000\u003b
        const DEBUG_MODE \u003d true\u003b
        
        \u002f\u002f \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d GLOBAL STATE \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d
        let db\u002c auth\u002c currentUser\u002c currentRoomId\u002c currentRoomData\u003b
        let videoElement\u002c isRoomOwner \u003d false\u003b
        let clockOffset \u003d 0\u003b
        
        \u002f\u002f Interval tracking for cleanup \u0028Memory Leak Prevention\u0029
        const activeIntervals \u003d \u005b\u005d\u003b
        const activeTimeouts \u003d \u005b\u005d\u003b
        const firebaseListeners \u003d \u005b\u005d\u003b
        
        \u002f\u002f Performance optimization
        let lastDriftValue \u003d null\u003b
        let lastFirebaseUpdate \u003d 0\u003b
        let lastUIUpdate \u003d 0\u003b
        
        \u002f\u002f Hard seek throttle tracking
        let lastHardSeekTime \u003d 0\u003b
        let lastSyncedPosition \u003d 0\u003b
        
        \u002f\u002f Command source tracking \u0028to prevent self-triggering\u0029
        let lastCommandSource \u003d null\u003b
