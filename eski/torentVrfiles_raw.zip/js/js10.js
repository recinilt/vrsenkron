        
        \u002f\u002f \u2705 MEMORY LEAK FIX\u003a Object URL temizleme
        function revokeCurrentVideoURL\u0028\u0029 \u007b
            if \u0028currentVideoObjectURL\u0029 \u007b
                URL.revokeObjectURL\u0028currentVideoObjectURL\u0029\u003b
                currentVideoObjectURL \u003d null\u003b
                debugLog\u0028\u0027\ud83e\uddf9 Object URL revoked\u0027\u0029\u003b
            \u007d
        \u007d
        
        \u002f\u002f \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d P2P WebTorrent FUNCTIONS \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d
        
        \u002f\u002f Video source tab de\u011fi\u015ftirme
        function switchVideoSourceTab\u0028tab\u0029 \u007b
            currentVideoSourceType \u003d tab\u003b
            
            const tabUrl \u003d getCachedElement\u0028\u0027tab-url\u0027\u0029\u003b
            const tabLocal \u003d getCachedElement\u0028\u0027tab-local\u0027\u0029\u003b
            const urlSection \u003d getCachedElement\u0028\u0027url-section\u0027\u0029\u003b
            const localSection \u003d getCachedElement\u0028\u0027local-file-section\u0027\u0029\u003b
            
            if \u0028tab \u003d\u003d\u003d \u0027url\u0027\u0029 \u007b
                tabUrl.classList.add\u0028\u0027active\u0027\u0029\u003b
                tabLocal.classList.remove\u0028\u0027active\u0027\u0029\u003b
                urlSection.classList.remove\u0028\u0027hidden-tab\u0027\u0029\u003b
                localSection.classList.remove\u0028\u0027active\u0027\u0029\u003b
            \u007d else \u007b
                tabUrl.classList.remove\u0028\u0027active\u0027\u0029\u003b
                tabLocal.classList.add\u0028\u0027active\u0027\u0029\u003b
                urlSection.classList.add\u0028\u0027hidden-tab\u0027\u0029\u003b
                localSection.classList.add\u0028\u0027active\u0027\u0029\u003b
            \u007d
        \u007d
        
        \u002f\u002f P2P Client ba\u015flatma
        function initP2PClient\u0028\u0029 \u007b
            if \u0028p2pClient\u0029 return p2pClient\u003b
            
            try \u007b
                p2pClient \u003d new WebTorrent\u0028\u0029\u003b
                
                p2pClient.on\u0028\u0027error\u0027\u002c \u0028err\u0029 \u003d\u003e \u007b
                    console.error\u0028\u0027WebTorrent error\u003a\u0027\u002c err\u0029\u003b
                    updateP2PStatus\u0028\u0027\u274c P2P Hatas\u0131\u003a \u0027 \u002b err.message\u002c 0\u0029\u003b
                \u007d\u0029\u003b
                
                debugLog\u0028\u0027\u2705 WebTorrent client initialized\u0027\u0029\u003b
                return p2pClient\u003b
            \u007d catch \u0028e\u0029 \u007b
                console.error\u0028\u0027WebTorrent init error\u003a\u0027\u002c e\u0029\u003b
                return null\u003b
            \u007d
        \u007d
