        
        \u002f\u002f P2P Client temizleme
        function destroyP2PClient\u0028\u0029 \u007b
            if \u0028p2pUpdateInterval\u0029 \u007b
                clearInterval\u0028p2pUpdateInterval\u0029\u003b
                p2pUpdateInterval \u003d null\u003b
            \u007d
            
            if \u0028currentTorrent\u0029 \u007b
                try \u007b
                    currentTorrent.destroy\u0028\u0029\u003b
                \u007d catch \u0028e\u0029 \u007b\u007d
                currentTorrent \u003d null\u003b
            \u007d
            
            if \u0028p2pClient\u0029 \u007b
                try \u007b
                    p2pClient.destroy\u0028\u0029\u003b
                \u007d catch \u0028e\u0029 \u007b\u007d
                p2pClient \u003d null\u003b
            \u007d
            
            hideP2PStatus\u0028\u0029\u003b
            debugLog\u0028\u0027\ud83e\uddf9 P2P client destroyed\u0027\u0029\u003b
        \u007d
