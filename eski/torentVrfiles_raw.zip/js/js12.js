        
        \u002f\u002f Lokal dosyay\u0131 seed et \u0028yay\u0131nc\u0131 i\u00e7in\u0029
        async function seedLocalVideo\u0028file\u0029 \u007b
            return new Promise\u0028\u0028resolve\u002c reject\u0029 \u003d\u003e \u007b
                if \u0028\u0021file\u0029 \u007b
                    reject\u0028new Error\u0028\u0027Dosya se\u00e7ilmedi\u0027\u0029\u0029\u003b
                    return\u003b
                \u007d
                
                initP2PClient\u0028\u0029\u003b
                
                if \u0028\u0021p2pClient\u0029 \u007b
                    reject\u0028new Error\u0028\u0027WebTorrent ba\u015flat\u0131lamad\u0131\u0027\u0029\u0029\u003b
                    return\u003b
                \u007d
                
                showP2PStatus\u0028\u0027\ud83d\udce4 Torrent olu\u015fturuluyor...\u0027\u002c 0\u0029\u003b
                
                const opts \u003d \u007b
                    announce\u003a WEBTORRENT_TRACKERS\u002c
                    name\u003a file.name
                \u007d\u003b
                
                p2pClient.seed\u0028file\u002c opts\u002c \u0028torrent\u0029 \u003d\u003e \u007b
                    currentTorrent \u003d torrent\u003b
                    
                    debugLog\u0028\u0027\u2705 Seeding started\u003a\u0027\u002c torrent.magnetURI\u0029\u003b
                    updateP2PStatus\u0028\u0027\ud83d\udce4 Payla\u015f\u0131l\u0131yor\u003a \u0027 \u002b torrent.numPeers \u002b \u0027 peer\u0027\u002c 100\u0029\u003b
                    
                    \u002f\u002f Periyodik g\u00fcncelleme
                    p2pUpdateInterval \u003d setInterval\u0028\u0028\u0029 \u003d\u003e \u007b
                        if \u0028currentTorrent\u0029 \u007b
                            const stats \u003d \u0060\ud83d\udce4 \u0024\u007bformatBytes\u0028currentTorrent.uploadSpeed\u0029\u007d\u002fs \u007c \ud83d\udc65 \u0024\u007bcurrentTorrent.numPeers\u007d peer\u0060\u003b
                            updateP2PStats\u0028stats\u0029\u003b
                        \u007d
                    \u007d\u002c 1000\u0029\u003b
                    trackInterval\u0028p2pUpdateInterval\u0029\u003b
                    
                    resolve\u0028torrent.magnetURI\u0029\u003b
                \u007d\u0029\u003b
                
                \u002f\u002f Timeout
                setTimeout\u0028\u0028\u0029 \u003d\u003e \u007b
                    if \u0028\u0021currentTorrent\u0029 \u007b
                        reject\u0028new Error\u0028\u0027Torrent olu\u015fturma zaman a\u015f\u0131m\u0131\u0027\u0029\u0029\u003b
                    \u007d
                \u007d\u002c 30000\u0029\u003b
            \u007d\u0029\u003b
        \u007d
