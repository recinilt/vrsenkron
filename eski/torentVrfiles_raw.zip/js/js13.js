        
        \u002f\u002f Magnet URI\u0027den video indir \u0028izleyici i\u00e7in\u0029
        async function joinP2PTorrent\u0028magnetURI\u0029 \u007b
            return new Promise\u0028\u0028resolve\u002c reject\u0029 \u003d\u003e \u007b
                if \u0028\u0021magnetURI\u0029 \u007b
                    reject\u0028new Error\u0028\u0027Magnet URI bulunamad\u0131\u0027\u0029\u0029\u003b
                    return\u003b
                \u007d
                
                initP2PClient\u0028\u0029\u003b
                
                if \u0028\u0021p2pClient\u0029 \u007b
                    reject\u0028new Error\u0028\u0027WebTorrent ba\u015flat\u0131lamad\u0131\u0027\u0029\u0029\u003b
                    return\u003b
                \u007d
                
                showP2PStatus\u0028\u0027\ud83d\udd0d Torrent aran\u0131yor...\u0027\u002c 0\u0029\u003b
                
                const opts \u003d \u007b
                    announce\u003a WEBTORRENT_TRACKERS
                \u007d\u003b
                
                p2pClient.add\u0028magnetURI\u002c opts\u002c \u0028torrent\u0029 \u003d\u003e \u007b
                    currentTorrent \u003d torrent\u003b
                    
                    debugLog\u0028\u0027\u2705 Torrent joined\u003a\u0027\u002c torrent.infoHash\u0029\u003b
                    debugLog\u0028\u0027\ud83d\udcc1 Files\u003a\u0027\u002c torrent.files.map\u0028f \u003d\u003e f.name\u0029\u0029\u003b
                    
                    \u002f\u002f Video dosyas\u0131n\u0131 bul
                    const videoFile \u003d torrent.files.find\u0028file \u003d\u003e \u007b
                        const ext \u003d file.name.split\u0028\u0027.\u0027\u0029.pop\u0028\u0029.toLowerCase\u0028\u0029\u003b
                        return \u005b\u0027mp4\u0027\u002c \u0027webm\u0027\u002c \u0027mkv\u0027\u002c \u0027ogv\u0027\u002c \u0027mov\u0027\u002c \u0027avi\u0027\u005d.includes\u0028ext\u0029\u003b
                    \u007d\u0029\u003b
                    
                    if \u0028\u0021videoFile\u0029 \u007b
                        reject\u0028new Error\u0028\u0027Video dosyas\u0131 bulunamad\u0131\u0027\u0029\u0029\u003b
                        return\u003b
                    \u007d
                    
                    \u002f\u002f Progress g\u00fcncelleme
                    p2pUpdateInterval \u003d setInterval\u0028\u0028\u0029 \u003d\u003e \u007b
                        if \u0028currentTorrent\u0029 \u007b
                            const progress \u003d Math.round\u0028currentTorrent.progress \u002a 100\u0029\u003b
                            const stats \u003d \u0060\ud83d\udce5 \u0024\u007bformatBytes\u0028currentTorrent.downloadSpeed\u0029\u007d\u002fs \u007c \ud83d\udce4 \u0024\u007bformatBytes\u0028currentTorrent.uploadSpeed\u0029\u007d\u002fs \u007c \ud83d\udc65 \u0024\u007bcurrentTorrent.numPeers\u007d\u0060\u003b
                            updateP2PStatus\u0028\u0060\ud83d\udce5 \u0130ndiriliyor\u003a \u0025\u0024\u007bprogress\u007d\u0060\u002c progress\u0029\u003b
                            updateP2PStats\u0028stats\u0029\u003b
                            
                            if \u0028currentTorrent.progress \u003d\u003d\u003d 1\u0029 \u007b
                                updateP2PStatus\u0028\u0027\u2705 Tamamland\u0131 - Payla\u015f\u0131l\u0131yor\u0027\u002c 100\u0029\u003b
                            \u007d
                        \u007d
                    \u007d\u002c 500\u0029\u003b
                    trackInterval\u0028p2pUpdateInterval\u0029\u003b
                    
                    resolve\u0028videoFile\u0029\u003b
                \u007d\u0029\u003b
                
                \u002f\u002f Timeout
                setTimeout\u0028\u0028\u0029 \u003d\u003e \u007b
                    if \u0028\u0021currentTorrent\u0029 \u007b
                        reject\u0028new Error\u0028\u0027Torrent ba\u011flant\u0131 zaman a\u015f\u0131m\u0131\u0027\u0029\u0029\u003b
                    \u007d
                \u007d\u002c 60000\u0029\u003b
            \u007d\u0029\u003b
        \u007d
