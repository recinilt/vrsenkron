        
        \u002f\u002f P2P Status UI
        function showP2PStatus\u0028text\u002c progress\u0029 \u007b
            const statusEl \u003d getCachedElement\u0028\u0027p2p-status\u0027\u0029\u003b
            const textEl \u003d getCachedElement\u0028\u0027p2p-status-text\u0027\u0029\u003b
            const fillEl \u003d getCachedElement\u0028\u0027p2p-progress-fill\u0027\u0029\u003b
            
            if \u0028statusEl\u0029 statusEl.style.display \u003d \u0027block\u0027\u003b
            if \u0028textEl\u0029 textEl.textContent \u003d text\u003b
            if \u0028fillEl\u0029 fillEl.style.width \u003d progress \u002b \u0027\u0025\u0027\u003b
        \u007d
        
        function updateP2PStatus\u0028text\u002c progress\u0029 \u007b
            const textEl \u003d getCachedElement\u0028\u0027p2p-status-text\u0027\u0029\u003b
            const fillEl \u003d getCachedElement\u0028\u0027p2p-progress-fill\u0027\u0029\u003b
            
            if \u0028textEl\u0029 textEl.textContent \u003d text\u003b
            if \u0028fillEl\u0029 fillEl.style.width \u003d progress \u002b \u0027\u0025\u0027\u003b
        \u007d
        
        function updateP2PStats\u0028stats\u0029 \u007b
            const statsEl \u003d getCachedElement\u0028\u0027p2p-stats\u0027\u0029\u003b
            if \u0028statsEl\u0029 statsEl.textContent \u003d stats\u003b
        \u007d
        
        function hideP2PStatus\u0028\u0029 \u007b
            const statusEl \u003d getCachedElement\u0028\u0027p2p-status\u0027\u0029\u003b
            if \u0028statusEl\u0029 statusEl.style.display \u003d \u0027none\u0027\u003b
        \u007d
        
        function formatBytes\u0028bytes\u0029 \u007b
            if \u0028bytes \u003d\u003d\u003d 0\u0029 return \u00270 B\u0027\u003b
            const k \u003d 1024\u003b
            const sizes \u003d \u005b\u0027B\u0027\u002c \u0027KB\u0027\u002c \u0027MB\u0027\u002c \u0027GB\u0027\u005d\u003b
            const i \u003d Math.floor\u0028Math.log\u0028bytes\u0029 \u002f Math.log\u0028k\u0029\u0029\u003b
            return parseFloat\u0028\u0028bytes \u002f Math.pow\u0028k\u002c i\u0029\u0029.toFixed\u00281\u0029\u0029 \u002b \u0027 \u0027 \u002b sizes\u005bi\u005d\u003b
        \u007d
