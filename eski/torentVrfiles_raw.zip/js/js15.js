        
        \u002f\u002f Dosya se\u00e7me event\u0027leri
        function setupFileInput\u0028\u0029 \u007b
            const fileInput \u003d document.getElementById\u0028\u0027local-video-file\u0027\u0029\u003b
            const dropZone \u003d document.getElementById\u0028\u0027file-drop-zone\u0027\u0029\u003b
            const fileNameDisplay \u003d document.getElementById\u0028\u0027selected-file-name\u0027\u0029\u003b
            
            if \u0028fileInput\u0029 \u007b
                fileInput.addEventListener\u0028\u0027change\u0027\u002c \u0028e\u0029 \u003d\u003e \u007b
                    const file \u003d e.target.files\u005b0\u005d\u003b
                    if \u0028file\u0029 \u007b
                        selectedLocalFile \u003d file\u003b
                        if \u0028fileNameDisplay\u0029 \u007b
                            fileNameDisplay.textContent \u003d \u0027\u2705 \u0027 \u002b file.name \u002b \u0027 \u0028\u0027 \u002b formatBytes\u0028file.size\u0029 \u002b \u0027\u0029\u0027\u003b
                        \u007d
                        debugLog\u0028\u0027\ud83d\udcc1 File selected\u003a\u0027\u002c file.name\u002c file.size\u0029\u003b
                    \u007d
                \u007d\u0029\u003b
            \u007d
            
            if \u0028dropZone\u0029 \u007b
                dropZone.addEventListener\u0028\u0027dragover\u0027\u002c \u0028e\u0029 \u003d\u003e \u007b
                    e.preventDefault\u0028\u0029\u003b
                    dropZone.classList.add\u0028\u0027dragover\u0027\u0029\u003b
                \u007d\u0029\u003b
                
                dropZone.addEventListener\u0028\u0027dragleave\u0027\u002c \u0028\u0029 \u003d\u003e \u007b
                    dropZone.classList.remove\u0028\u0027dragover\u0027\u0029\u003b
                \u007d\u0029\u003b
                
                dropZone.addEventListener\u0028\u0027drop\u0027\u002c \u0028e\u0029 \u003d\u003e \u007b
                    e.preventDefault\u0028\u0029\u003b
                    dropZone.classList.remove\u0028\u0027dragover\u0027\u0029\u003b
                    
                    const file \u003d e.dataTransfer.files\u005b0\u005d\u003b
                    if \u0028file \u0026\u0026 file.type.startsWith\u0028\u0027video\u002f\u0027\u0029\u0029 \u007b
                        selectedLocalFile \u003d file\u003b
                        if \u0028fileNameDisplay\u0029 \u007b
                            fileNameDisplay.textContent \u003d \u0027\u2705 \u0027 \u002b file.name \u002b \u0027 \u0028\u0027 \u002b formatBytes\u0028file.size\u0029 \u002b \u0027\u0029\u0027\u003b
                        \u007d
                        debugLog\u0028\u0027\ud83d\udcc1 File dropped\u003a\u0027\u002c file.name\u002c file.size\u0029\u003b
                    \u007d
                \u007d\u0029\u003b
            \u007d
        \u007d
