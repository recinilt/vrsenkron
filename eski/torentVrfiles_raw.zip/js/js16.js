        
        \u002f\u002f \u2705 FIX \u00237 \u0026 \u00238\u003a hashchange ve onDisconnect temizleme
        function fullCleanup\u0028\u0029 \u007b
            \u002f\u002f \u2705 ABR cleanup
            destroyAdaptiveStreaming\u0028\u0029\u003b
            
            \u002f\u002f \u2705 P2P cleanup
            destroyP2PClient\u0028\u0029\u003b

            \u002f\u002f Flush pending Firebase updates first
            if \u0028firebaseBatchTimeout\u0029 \u007b
                clearTimeout\u0028firebaseBatchTimeout\u0029\u003b
                flushFirebaseUpdates\u0028\u0029\u003b
            \u007d
            
            \u002f\u002f \u2705 FIX\u003a Owner task\u0027lar\u0131n\u0131 temizle
            clearOwnerTasks\u0028\u0029\u003b
            
            clearAllIntervals\u0028\u0029\u003b
            clearAllTimeouts\u0028\u0029\u003b
            clearAllListeners\u0028\u0029\u003b
            clearElementCache\u0028\u0029\u003b
            
            \u002f\u002f \u2705 FIX \u00237\u003a hashchange listener kald\u0131r
            if \u0028hashChangeHandler\u0029 \u007b
                window.removeEventListener\u0028\u0027hashchange\u0027\u002c hashChangeHandler\u0029\u003b
                hashChangeHandler \u003d null\u003b
            \u007d
            
            \u002f\u002f \u2705 FIX\u003a Scene listener\u0027lar\u0131 kald\u0131r
            const scene \u003d document.querySelector\u0028\u0027a-scene\u0027\u0029\u003b
            if \u0028scene\u0029 \u007b
                if \u0028sceneEnterVRHandler\u0029 \u007b
                    scene.removeEventListener\u0028\u0027enter-vr\u0027\u002c sceneEnterVRHandler\u0029\u003b
                    sceneEnterVRHandler \u003d null\u003b
                \u007d
                if \u0028sceneExitVRHandler\u0029 \u007b
                    scene.removeEventListener\u0028\u0027exit-vr\u0027\u002c sceneExitVRHandler\u0029\u003b
                    sceneExitVRHandler \u003d null\u003b
                \u007d
            \u007d
            
            \u002f\u002f \u2705 FIX\u003a Keyboard listener kald\u0131r
            if \u0028keydownHandler\u0029 \u007b
                document.removeEventListener\u0028\u0027keydown\u0027\u002c keydownHandler\u0029\u003b
                keydownHandler \u003d null\u003b
            \u007d
            
            \u002f\u002f \u2705 FIX \u00238\u003a onDisconnect referans\u0131n\u0131 iptal et
            if \u0028currentOnDisconnectRef\u0029 \u007b
                currentOnDisconnectRef.cancel\u0028\u0029.catch\u0028\u0028\u0029 \u003d\u003e \u007b\u007d\u0029\u003b
                currentOnDisconnectRef \u003d null\u003b
            \u007d
            
            \u002f\u002f \u2705 MEMORY LEAK FIX\u003a Object URL temizle
            revokeCurrentVideoURL\u0028\u0029\u003b
            
            \u002f\u002f Remove from active viewers
            if \u0028currentRoomId \u0026\u0026 currentUser\u0029 \u007b
                db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId \u002b \u0027\u002factiveViewers\u002f\u0027 \u002b currentUser.uid\u0029.remove\u0028\u0029.catch\u0028\u0028\u0029 \u003d\u003e \u007b\u007d\u0029\u003b
            \u007d
            
            pendingFirebaseUpdates \u003d \u007b\u007d\u003b
            
            \u002f\u002f Reset tracking variables
            lastHardSeekTime \u003d 0\u003b
            lastSyncedPosition \u003d 0\u003b
            isJoiningRoom \u003d false\u003b
            isHardSeeking \u003d false\u003b \u002f\u002f \u2705 FIX\u003a Reset isHardSeeking
            ownerTransferInProgress \u003d false\u003b
            selectedLocalFile \u003d null\u003b
            currentVideoSourceType \u003d \u0027url\u0027\u003b
            
            debugLog\u0028\u0027\ud83e\uddf9 Full cleanup completed\u0027\u0029\u003b
        \u007d
