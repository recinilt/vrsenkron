        
        \u002f\u002f \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d FIREBASE BATCH UPDATES \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d
        function queueFirebaseUpdate\u0028path\u002c value\u0029 \u007b
            pendingFirebaseUpdates\u005bpath\u005d \u003d value\u003b
            
            if \u0028\u0021firebaseBatchTimeout\u0029 \u007b
                firebaseBatchTimeout \u003d setTimeout\u0028\u0028\u0029 \u003d\u003e \u007b
                    flushFirebaseUpdates\u0028\u0029\u003b
                \u007d\u002c 1000\u0029\u003b
            \u007d
        \u007d
        
        function flushFirebaseUpdates\u0028\u0029 \u007b
            if \u0028Object.keys\u0028pendingFirebaseUpdates\u0029.length \u003e 0 \u0026\u0026 currentRoomId\u0029 \u007b
                db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId\u0029
                    .update\u0028pendingFirebaseUpdates\u0029
                    .catch\u0028err \u003d\u003e console.warn\u0028\u0027Batch update error\u003a\u0027\u002c err\u0029\u0029\u003b
                
                pendingFirebaseUpdates \u003d \u007b\u007d\u003b
            \u007d
            firebaseBatchTimeout \u003d null\u003b
        \u007d
        
        function shouldUpdateFirebase\u0028\u0029 \u007b
            const now \u003d Date.now\u0028\u0029\u003b
            if \u0028now - lastFirebaseUpdate \u003c 5000\u0029 \u007b
                return false\u003b
            \u007d
            lastFirebaseUpdate \u003d now\u003b
            return true\u003b
        \u007d
        
        function shouldUpdateUI\u0028\u0029 \u007b
            const now \u003d Date.now\u0028\u0029\u003b
            if \u0028now - lastUIUpdate \u003c 300\u0029 \u007b
                return false\u003b
            \u007d
            lastUIUpdate \u003d now\u003b
            return true\u003b
        \u007d
        
        \u002f\u002f \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d CLOCK SYNC \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d
        async function initClockSync\u0028\u0029 \u007b
            try \u007b
                const samples \u003d \u005b\u005d\u003b
                for \u0028let i \u003d 0\u003b i \u003c 3\u003b i\u002b\u002b\u0029 \u007b
                    const t0 \u003d Date.now\u0028\u0029\u003b
                    const ref \u003d db.ref\u0028\u0027.info\u002fserverTimeOffset\u0027\u0029\u003b
                    const snapshot \u003d await ref.once\u0028\u0027value\u0027\u0029\u003b
                    const offset \u003d snapshot.val\u0028\u0029\u003b
                    const t1 \u003d Date.now\u0028\u0029\u003b
                    const rtt \u003d t1 - t0\u003b
                    const serverTime \u003d Date.now\u0028\u0029 \u002b offset\u003b
                    const calculatedOffset \u003d serverTime - \u0028t0 \u002b rtt \u002f 2\u0029\u003b
                    samples.push\u0028calculatedOffset\u0029\u003b
                    await new Promise\u0028resolve \u003d\u003e setTimeout\u0028resolve\u002c 100\u0029\u0029\u003b
                \u007d
                clockOffset \u003d samples.reduce\u0028\u0028a\u002c b\u0029 \u003d\u003e a \u002b b\u002c 0\u0029 \u002f samples.length\u003b
                debugLog\u0028\u0027\ud83d\udd50 Clock offset\u003a\u0027\u002c clockOffset\u002c \u0027ms\u0027\u0029\u003b
            \u007d catch \u0028error\u0029 \u007b
                console.warn\u0028\u0027Clock sync error\u003a\u0027\u002c error\u0029\u003b
            \u007d
        \u007d
