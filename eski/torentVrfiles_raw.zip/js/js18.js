        
        \u002f\u002f \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d ROOM MANAGEMENT \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d
        async function createRoom\u0028\u0029 \u007b
            const roomName \u003d getCachedElement\u0028\u0027room-name\u0027\u0029.value.trim\u0028\u0029\u003b
            const videoUrl \u003d getCachedElement\u0028\u0027video-url\u0027\u0029.value.trim\u0028\u0029\u003b
            const screenSize \u003d getCachedElement\u0028\u0027screen-size\u0027\u0029.value\u003b
            const environment \u003d getCachedElement\u0028\u0027environment\u0027\u0029.value\u003b
            
            \u002f\u002f P2P modu kontrol\u00fc
            const isP2PMode \u003d currentVideoSourceType \u003d\u003d\u003d \u0027local\u0027\u003b
            
            if \u0028\u0021roomName\u0029 \u007b
                alert\u0028\u0027L\u00fctfen oda ad\u0131 giriniz\u0021\u0027\u0029\u003b
                return\u003b
            \u007d
            
            if \u0028\u0021isP2PMode \u0026\u0026 \u0021videoUrl\u0029 \u007b
                alert\u0028\u0027L\u00fctfen video URL giriniz\u0021\u0027\u0029\u003b
                return\u003b
            \u007d
            
            if \u0028isP2PMode \u0026\u0026 \u0021selectedLocalFile\u0029 \u007b
                alert\u0028\u0027L\u00fctfen bir video dosyas\u0131 se\u00e7iniz\u0021\u0027\u0029\u003b
                return\u003b
            \u007d
            
            try \u007b
                const userCredential \u003d await auth.signInAnonymously\u0028\u0029\u003b
                currentUser \u003d userCredential.user\u003b
                
                let finalVideoUrl \u003d videoUrl\u003b
                let magnetURI \u003d null\u003b
                
                \u002f\u002f P2P modunda dosyay\u0131 seed et
                if \u0028isP2PMode \u0026\u0026 selectedLocalFile\u0029 \u007b
                    try \u007b
                        magnetURI \u003d await seedLocalVideo\u0028selectedLocalFile\u0029\u003b
                        finalVideoUrl \u003d \u0027p2p\u003a\u002f\u002f\u0027 \u002b magnetURI\u003b \u002f\u002f P2P marker
                        debugLog\u0028\u0027\u2705 Magnet URI created\u003a\u0027\u002c magnetURI\u0029\u003b
                    \u007d catch \u0028e\u0029 \u007b
                        console.error\u0028\u0027Seed error\u003a\u0027\u002c e\u0029\u003b
                        alert\u0028\u0027Video payla\u015f\u0131m\u0131 ba\u015flat\u0131lamad\u0131\u003a \u0027 \u002b e.message\u0029\u003b
                        return\u003b
                    \u007d
                \u007d
                
                const roomRef \u003d db.ref\u0028\u0027rooms\u0027\u0029.push\u0028\u0029\u003b
                currentRoomId \u003d roomRef.key\u003b
                
                const roomData \u003d \u007b
                    name\u003a roomName\u002c
                    owner\u003a currentUser.uid\u002c
                    videoUrl\u003a finalVideoUrl\u002c
                    screenSize\u003a screenSize\u002c
                    environment\u003a environment\u002c
                    createdAt\u003a firebase.database.ServerValue.TIMESTAMP\u002c
                    videoState\u003a \u007b
                        isPlaying\u003a false\u002c
                        currentTime\u003a 0\u002c
                        startTimestamp\u003a 0\u002c
                        lastUpdate\u003a firebase.database.ServerValue.TIMESTAMP
                    \u007d
                \u007d\u003b
                
                \u002f\u002f P2P modunda magnet URI\u0027yi ayr\u0131 kaydet
                if \u0028magnetURI\u0029 \u007b
                    roomData.p2p \u003d \u007b
                        magnetURI\u003a magnetURI\u002c
                        fileName\u003a selectedLocalFile.name\u002c
                        fileSize\u003a selectedLocalFile.size
                    \u007d\u003b
                \u007d
                
                await roomRef.set\u0028roomData\u0029\u003b
                
                await joinRoom\u0028currentRoomId\u0029\u003b
            \u007d catch \u0028error\u0029 \u007b
                console.error\u0028\u0027\u274c Oda olu\u015fturma hatas\u0131\u003a\u0027\u002c error\u0029\u003b
                alert\u0028\u0027Oda olu\u015fturulamad\u0131\u003a \u0027 \u002b error.message\u0029\u003b
            \u007d
        \u007d
