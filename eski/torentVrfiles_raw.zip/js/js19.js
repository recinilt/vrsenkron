        
        \u002f\u002f \u2705 FIX \u00233\u003a joinRoom race condition \u00f6nleme
        async function joinRoom\u0028roomId\u0029 \u007b
            \u002f\u002f \u2705 FIX \u00233\u003a Yar\u0131\u015fma \u00f6nleme - zaten kat\u0131l\u0131m varsa \u00e7\u0131k
            if \u0028isJoiningRoom\u0029 \u007b
                debugLog\u0028\u0027\u26a0\ufe0f Already joining a room\u002c skipping duplicate call\u0027\u0029\u003b
                return\u003b
            \u007d
            isJoiningRoom \u003d true\u003b
            
            try \u007b
                if \u0028\u0021auth.currentUser\u0029 \u007b
                    const userCredential \u003d await auth.signInAnonymously\u0028\u0029\u003b
                    currentUser \u003d userCredential.user\u003b
                \u007d else \u007b
                    currentUser \u003d auth.currentUser\u003b
                \u007d
                
                \u002f\u002f \u2705 FIX \u00238\u003a \u00d6nceki onDisconnect\u0027i iptal et
                if \u0028currentOnDisconnectRef\u0029 \u007b
                    await currentOnDisconnectRef.cancel\u0028\u0029.catch\u0028\u0028\u0029 \u003d\u003e \u007b\u007d\u0029\u003b
                    currentOnDisconnectRef \u003d null\u003b
                \u007d
                
                currentRoomId \u003d roomId\u003b
                const roomSnapshot \u003d await db.ref\u0028\u0027rooms\u002f\u0027 \u002b roomId\u0029.once\u0028\u0027value\u0027\u0029\u003b
                currentRoomData \u003d roomSnapshot.val\u0028\u0029\u003b
                
                if \u0028\u0021currentRoomData\u0029 \u007b
                    alert\u0028\u0027Oda bulunamad\u0131\u0021\u0027\u0029\u003b
                    isJoiningRoom \u003d false\u003b
                    return\u003b
                \u007d
                
                \u002f\u002f \u2705 Sahiplik kontrol\u00fc\u003a Mevcut owner ile kar\u015f\u0131la\u015ft\u0131r
                isRoomOwner \u003d currentUser.uid \u003d\u003d\u003d currentRoomData.owner\u003b
                
                \u002f\u002f Add to active viewers
                const viewerRef \u003d db.ref\u0028\u0027rooms\u002f\u0027 \u002b roomId \u002b \u0027\u002factiveViewers\u002f\u0027 \u002b currentUser.uid\u0029\u003b
                await viewerRef.set\u0028\u007b
                    joinedAt\u003a firebase.database.ServerValue.TIMESTAMP\u002c
                    lastSeen\u003a firebase.database.ServerValue.TIMESTAMP\u002c
                    isOwner\u003a isRoomOwner\u002c
                    currentDrift\u003a 0
                \u007d\u0029\u003b
                
                \u002f\u002f \u2705 FIX \u00238\u003a onDisconnect referans\u0131n\u0131 sakla
                currentOnDisconnectRef \u003d viewerRef.onDisconnect\u0028\u0029\u003b
                currentOnDisconnectRef.remove\u0028\u0029\u003b
                
                await initClockSync\u0028\u0029\u003b
                await create3DScene\u0028\u0029\u003b
                
                getCachedElement\u0028\u0027ui-overlay\u0027\u0029.classList.add\u0028\u0027hidden\u0027\u0029\u003b
                getCachedElement\u0028\u0027vr-controls\u0027\u0029.style.display \u003d \u0027flex\u0027\u003b
                getCachedElement\u0028\u0027room-info\u0027\u0029.style.display \u003d \u0027block\u0027\u003b
                getCachedElement\u0028\u0027sync-status\u0027\u0029.style.display \u003d \u0027block\u0027\u003b
                
                updateRoomInfoDisplay\u0028\u0029\u003b
                listenVideoState\u0028\u0029\u003b
                listenSyncState\u0028\u0029\u003b
                
                \u002f\u002f \u2705 Sahip ayr\u0131lma listener\u0027\u0131 - herkes i\u00e7in
                listenOwnerLeft\u0028\u0029\u003b
                
                if \u0028isRoomOwner\u0029 \u007b
                    startOwnerTasks\u0028\u0029\u003b
                \u007d else \u007b
                    listenKeyframes\u0028\u0029\u003b
                \u007d
                
                \u002f\u002f Start all periodic tasks
                startPeriodicTasks\u0028\u0029\u003b
                
                isJoiningRoom \u003d false\u003b
                
            \u007d catch \u0028error\u0029 \u007b
                console.error\u0028\u0027\u274c Odaya kat\u0131lma hatas\u0131\u003a\u0027\u002c error\u0029\u003b
                alert\u0028\u0027Odaya kat\u0131l\u0131namad\u0131\u003a \u0027 \u002b error.message\u0029\u003b
                isJoiningRoom \u003d false\u003b
            \u007d
        \u007d
