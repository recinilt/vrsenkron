        
        \u002f\u002f Sync mechanism
        let syncState \u003d null\u003b
        let countdownInterval \u003d null\u003b
        let syncTimeoutId \u003d null\u003b
        let lastSyncCheck \u003d 0\u003b
        
        \u002f\u002f Buffer countdown system
        let bufferCountdownInterval \u003d null\u003b
        let bufferTargetTime \u003d null\u003b
        let isBuffering \u003d false\u003b
        
        \u002f\u002f Cached DOM elements
        let cachedElements \u003d \u007b\u007d\u003b
        
        \u002f\u002f Firebase batch updates
        let pendingFirebaseUpdates \u003d \u007b\u007d\u003b
        let firebaseBatchTimeout \u003d null\u003b

        \u002f\u002f \u2705 FIX \u00233\u003a joinRoom yar\u0131\u015fmas\u0131 \u00f6nleme
        let isJoiningRoom \u003d false\u003b
        
        \u002f\u002f \u2705 FIX \u00238\u003a onDisconnect referans\u0131
        let currentOnDisconnectRef \u003d null\u003b
        
        \u002f\u002f \u2705 FIX \u00237\u003a hashchange listener referans\u0131
        let hashChangeHandler \u003d null\u003b

        \u002f\u002f \u2705 FIX\u003a Scene ve keyboard listener referanslar\u0131 \u0028cleanup i\u00e7in\u0029
        let sceneEnterVRHandler \u003d null\u003b
        let sceneExitVRHandler \u003d null\u003b
        let keydownHandler \u003d null\u003b

        let seekDebounceTimer \u003d null\u003b
        let pendingSeekAmount \u003d 0\u003b
        let pendingSeekDirection \u003d null\u003b
        let syncModeActive \u003d false\u003b
        let seekTimeoutId \u003d null\u003b
        let commandSourceTimeoutId \u003d null\u003b
        let videoStateUpdateDebounce \u003d null\u003b

        \u002f\u002f \u2705 MEMORY LEAK FIX\u003a Object URL tracking
        let currentVideoObjectURL \u003d null\u003b

        \u002f\u002f \u2705 Owner transfer tracking
        let ownerTransferInProgress \u003d false\u003b

        \u002f\u002f \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d P2P WebTorrent STATE \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d
        let p2pClient \u003d null\u003b
        let currentTorrent \u003d null\u003b
        let selectedLocalFile \u003d null\u003b
        let currentVideoSourceType \u003d \u0027url\u0027\u003b \u002f\u002f \u0027url\u0027 veya \u0027p2p\u0027
        let p2pUpdateInterval \u003d null\u003b
        
        \u002f\u002f WebTorrent Tracker URLs
        const WEBTORRENT_TRACKERS \u003d \u005b
            \u0027wss\u003a\u002f\u002ftracker.btorrent.xyz\u0027\u002c
            \u0027wss\u003a\u002f\u002ftracker.openwebtorrent.com\u0027\u002c
            \u0027wss\u003a\u002f\u002ftracker.webtorrent.dev\u0027
        \u005d\u003b

\u002f\u002f \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d ADAPTIVE STREAMING \u0028ABR\u0029 \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d
let hlsInstance \u003d null\u003b
let dashInstance \u003d null\u003b

\u002f\u002f Start as low as possible\u002c cap max at \u003c\u003d 720p \u0028user adjustable\u0029
const QUALITY_CAPS \u003d \u005b360\u002c 480\u002c 720\u005d\u003b
let abrMaxHeightCap \u003d 720\u003b

function getStreamType\u0028url\u0029 \u007b
    const u \u003d \u0028url \u007c\u007c \u0027\u0027\u0029.split\u0028\u0027\u003f\u0027\u0029\u005b0\u005d.toLowerCase\u0028\u0029\u003b
    if \u0028u.endsWith\u0028\u0027.m3u8\u0027\u0029\u0029 return \u0027hls\u0027\u003b
    if \u0028u.endsWith\u0028\u0027.mpd\u0027\u0029\u0029 return \u0027dash\u0027\u003b
    return \u0027native\u0027\u003b
\u007d
