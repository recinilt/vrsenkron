        
        \u002f\u002f \u2705 YEN\u0130\u003a Oda sahibi ayr\u0131ld\u0131\u011f\u0131nda yeni sahip atama
        function listenOwnerLeft\u0028\u0029 \u007b
            const viewersRef \u003d db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId \u002b \u0027\u002factiveViewers\u0027\u0029\u003b
            trackListener\u0028viewersRef\u0029\u003b
            
            viewersRef.on\u0028\u0027value\u0027\u002c async \u0028snapshot\u0029 \u003d\u003e \u007b
                if \u0028\u0021currentRoomId \u007c\u007c \u0021currentUser \u007c\u007c ownerTransferInProgress\u0029 return\u003b
                
                const viewers \u003d snapshot.val\u0028\u0029\u003b
                if \u0028\u0021viewers\u0029 return\u003b
                
                \u002f\u002f G\u00fcncel oda verisini al
                const roomSnapshot \u003d await db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId\u0029.once\u0028\u0027value\u0027\u0029\u003b
                const roomData \u003d roomSnapshot.val\u0028\u0029\u003b
                if \u0028\u0021roomData\u0029 return\u003b
                
                const currentOwnerUid \u003d roomData.owner\u003b
                
                \u002f\u002f Mevcut sahip hala odada m\u0131\u003f
                const ownerStillHere \u003d viewers\u005bcurrentOwnerUid\u005d \u0021\u003d\u003d undefined\u003b
                
                if \u0028\u0021ownerStillHere \u0026\u0026 Object.keys\u0028viewers\u0029.length \u003e 0\u0029 \u007b
                    \u002f\u002f Sahip ayr\u0131lm\u0131\u015f\u002c yeni sahip ata
                    \u002f\u002f En eski kat\u0131l\u0131mc\u0131y\u0131 bul \u0028en d\u00fc\u015f\u00fck joinedAt\u0029
                    let oldestViewer \u003d null\u003b
                    let oldestTime \u003d Infinity\u003b
                    
                    Object.keys\u0028viewers\u0029.forEach\u0028uid \u003d\u003e \u007b
                        const viewer \u003d viewers\u005buid\u005d\u003b
                        if \u0028viewer.joinedAt \u0026\u0026 viewer.joinedAt \u003c oldestTime\u0029 \u007b
                            oldestTime \u003d viewer.joinedAt\u003b
                            oldestViewer \u003d uid\u003b
                        \u007d
                    \u007d\u0029\u003b
                    
                    \u002f\u002f E\u011fer en eski kat\u0131l\u0131mc\u0131 bensem\u002c sahipli\u011fi al
                    if \u0028oldestViewer \u003d\u003d\u003d currentUser.uid\u0029 \u007b
                        ownerTransferInProgress \u003d true\u003b
                        
                        try \u007b
                            \u002f\u002f Atomik g\u00fcncelleme\u003a owner\u0027\u0131 ve viewer\u0027\u0131m\u0131 g\u00fcncelle
                            await db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId\u0029.update\u0028\u007b
                                owner\u003a currentUser.uid
                            \u007d\u0029\u003b
                            
                            await db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId \u002b \u0027\u002factiveViewers\u002f\u0027 \u002b currentUser.uid\u0029.update\u0028\u007b
                                isOwner\u003a true
                            \u007d\u0029\u003b
                            
                            \u002f\u002f Lokal state g\u00fcncelle
                            isRoomOwner \u003d true\u003b
                            currentRoomData.owner \u003d currentUser.uid\u003b
                            
                            \u002f\u002f Owner task\u0027lar\u0131n\u0131 ba\u015flat
                            startOwnerTasks\u0028\u0029\u003b
                            
                            \u002f\u002f Keyframe listener\u0027\u0131 kapat \u0028art\u0131k owner\u0027\u0131z\u0029
                            \u002f\u002f Not\u003a listenKeyframes zaten trackListener ile eklendi\u002c 
                            \u002f\u002f ama owner olunca keyframe dinlemeye gerek yok
                            
                            console.log\u0028\u0027\ud83d\udc51 Sahiplik size devredildi\u0021\u0027\u0029\u003b
                            debugLog\u0028\u0027\ud83d\udc51 Ownership transferred to\u003a\u0027\u002c currentUser.uid\u0029\u003b
                            
                            \u002f\u002f UI g\u00fcncelle
                            updateRoomInfoDisplay\u0028\u0029\u003b
                            
                        \u007d catch \u0028error\u0029 \u007b
                            console.error\u0028\u0027Sahiplik transfer hatas\u0131\u003a\u0027\u002c error\u0029\u003b
                        \u007d finally \u007b
                            ownerTransferInProgress \u003d false\u003b
                        \u007d
                    \u007d
                \u007d
            \u007d\u0029\u003b
        \u007d
