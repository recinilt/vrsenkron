        
        \u002f\u002f \u2705 FIX \u00237\u003a leaveRoom - t\u00fcm temizlikler
        function leaveRoom\u0028\u0029 \u007b
            if \u0028currentRoomId \u0026\u0026 currentUser\u0029 \u007b
                db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId \u002b \u0027\u002factiveViewers\u002f\u0027 \u002b currentUser.uid\u0029.remove\u0028\u0029\u003b
            \u007d
            
            \u002f\u002f Clear sync state
            clearSyncState\u0028\u0029\u003b
            
            \u002f\u002f \u2705 FIX \u00231\u003a Video listener\u0027lar\u0131n\u0131 temizle
            clearVideoListeners\u0028\u0029\u003b
            
            \u002f\u002f Full cleanup \u0028includes FIX \u00237 \u0026 \u00238\u0029
            fullCleanup\u0028\u0029\u003b
            
            \u002f\u002f Clean up video element
            if \u0028videoElement\u0029 \u007b
                videoElement.pause\u0028\u0029\u003b
                videoElement.removeAttribute\u0028\u0027src\u0027\u0029\u003b
                videoElement.load\u0028\u0029\u003b
                videoElement.remove\u0028\u0029\u003b
                videoElement \u003d null\u003b
            \u007d
            
            \u002f\u002f Remove scene elements with A-Frame cleanup
            const scene \u003d document.querySelector\u0028\u0027a-scene\u0027\u0029\u003b
            const videoScreen \u003d document.getElementById\u0028\u0027video-screen\u0027\u0029\u003b
            const vrPanel \u003d document.getElementById\u0028\u0027vr-panel\u0027\u0029\u003b
            
            if \u0028videoScreen\u0029 \u007b
                const material \u003d videoScreen.components.material\u003b
                if \u0028material \u0026\u0026 material.material \u0026\u0026 material.material.map\u0029 \u007b
                    material.material.map.dispose\u0028\u0029\u003b
                    material.material.dispose\u0028\u0029\u003b
                \u007d
                videoScreen.remove\u0028\u0029\u003b
            \u007d
            
            \u002f\u002f \u2705 FIX\u003a VR panel button listener\u0027lar\u0131n\u0131 temizle
            if \u0028vrPanel \u0026\u0026 vrPanel._buttonListeners\u0029 \u007b
                vrPanel._buttonListeners.forEach\u0028\u0028\u007b element\u002c handler \u007d\u0029 \u003d\u003e \u007b
                    element.removeEventListener\u0028\u0027click\u0027\u002c handler\u0029\u003b
                \u007d\u0029\u003b
                vrPanel._buttonListeners \u003d \u005b\u005d\u003b
            \u007d
            if \u0028vrPanel\u0029 vrPanel.remove\u0028\u0029\u003b
            
            getCachedElement\u0028\u0027ui-overlay\u0027\u0029.classList.remove\u0028\u0027hidden\u0027\u0029\u003b
            getCachedElement\u0028\u0027vr-controls\u0027\u0029.style.display \u003d \u0027none\u0027\u003b
            getCachedElement\u0028\u0027room-info\u0027\u0029.style.display \u003d \u0027none\u0027\u003b
            getCachedElement\u0028\u0027sync-status\u0027\u0029.style.display \u003d \u0027none\u0027\u003b
            
            const bufferEl \u003d getCachedElement\u0028\u0027buffer-countdown\u0027\u0029\u003b
            if \u0028bufferEl\u0029 bufferEl.style.display \u003d \u0027none\u0027\u003b
            
            hideP2PStatus\u0028\u0029\u003b
            
            isBuffering \u003d false\u003b
            bufferTargetTime \u003d null\u003b
            
            currentRoomId \u003d null\u003b
            currentRoomData \u003d null\u003b
            isRoomOwner \u003d false\u003b
            lastDriftValue \u003d null\u003b
        \u007d
