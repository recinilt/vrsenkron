        
        async function showRoomList\u0028\u0029 \u007b
            try \u007b
                if \u0028\u0021auth.currentUser\u0029 \u007b
                    await auth.signInAnonymously\u0028\u0029\u003b
                \u007d
                
                const roomsSnapshot \u003d await db.ref\u0028\u0027rooms\u0027\u0029.limitToLast\u002820\u0029.once\u0028\u0027value\u0027\u0029\u003b
                const roomList \u003d getCachedElement\u0028\u0027room-list\u0027\u0029\u003b
                roomList.innerHTML \u003d \u0027\u0027\u003b
                
                const rooms \u003d \u005b\u005d\u003b
                const roomsToDelete \u003d \u005b\u005d\u003b
                
                roomsSnapshot.forEach\u0028child \u003d\u003e \u007b
                    const roomData \u003d child.val\u0028\u0029\u003b
                    const viewerCount \u003d roomData.activeViewers \u003f Object.keys\u0028roomData.activeViewers\u0029.length \u003a 0\u003b
                    
                    if \u0028viewerCount \u003d\u003d\u003d 0\u0029 \u007b
                        roomsToDelete.push\u0028child.key\u0029\u003b
                    \u007d else \u007b
                        rooms.push\u0028\u007b id\u003a child.key\u002c data\u003a roomData\u002c viewers\u003a viewerCount \u007d\u0029\u003b
                    \u007d
                \u007d\u0029\u003b
                
                roomsToDelete.forEach\u0028roomId \u003d\u003e \u007b
                    db.ref\u0028\u0027rooms\u002f\u0027 \u002b roomId\u0029.remove\u0028\u0029\u003b
                \u007d\u0029\u003b
                
                if \u0028rooms.length \u003d\u003d\u003d 0\u0029 \u007b
                    roomList.innerHTML \u003d \u0027\u003cp style\u003d\u0022text-align\u003a center\u003b opacity\u003a 0.7\u003b\u0022\u003eAktif oda bulunamad\u0131\u003c\u002fp\u003e\u0027\u003b
                \u007d else \u007b
                    rooms.forEach\u0028room \u003d\u003e \u007b
                        const isP2P \u003d room.data.p2p \u0026\u0026 room.data.p2p.magnetURI\u003b
                        const roomDiv \u003d document.createElement\u0028\u0027div\u0027\u0029\u003b
                        roomDiv.className \u003d \u0027room-item\u0027\u003b
                        roomDiv.innerHTML \u003d \u0060
                            \u003cdiv class\u003d\u0022room-name\u0022\u003e\u0024\u007broom.data.name\u007d \u0024\u007bisP2P \u003f \u0027\ud83d\udd17 P2P\u0027 \u003a \u0027\u0027\u007d\u003c\u002fdiv\u003e
                            \u003cdiv class\u003d\u0022room-details\u0022\u003e\ud83d\udc65 \u0024\u007broom.viewers\u007d izleyici \u0024\u007bisP2P \u003f \u0027\u007c \ud83d\udcc1 \u0027 \u002b room.data.p2p.fileName \u003a \u0027\u0027\u007d\u003c\u002fdiv\u003e
                        \u0060\u003b
                        roomDiv.onclick \u003d \u0028\u0029 \u003d\u003e joinRoom\u0028room.id\u0029\u003b
                        roomList.appendChild\u0028roomDiv\u0029\u003b
                    \u007d\u0029\u003b
                \u007d
                
                getCachedElement\u0028\u0027create-room-section\u0027\u0029.classList.add\u0028\u0027hidden\u0027\u0029\u003b
                getCachedElement\u0028\u0027room-list-section\u0027\u0029.classList.remove\u0028\u0027hidden\u0027\u0029\u003b
                
            \u007d catch \u0028error\u0029 \u007b
                console.error\u0028\u0027\u274c Oda listesi hatas\u0131\u003a\u0027\u002c error\u0029\u003b
                alert\u0028\u0027Odalar y\u00fcklenirken hata olu\u015ftu\u003a \u0027 \u002b error.message \u002b \u0027\u005cn\u005cnL\u00fctfen Firebase Rules ayarlar\u0131n\u0131z\u0131 kontrol edin.\u0027\u0029\u003b
            \u007d
        \u007d
