        
        function showCreateRoom\u0028\u0029 \u007b
            getCachedElement\u0028\u0027room-list-section\u0027\u0029.classList.add\u0028\u0027hidden\u0027\u0029\u003b
            getCachedElement\u0028\u0027create-room-section\u0027\u0029.classList.remove\u0028\u0027hidden\u0027\u0029\u003b
        \u007d
