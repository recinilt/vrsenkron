        
        \u002f\u002f \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d 3D SCENE \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d
        \u002f\u002f \u2705 FIX \u00231 \u0026 \u00232\u003a Video listener\u0027lar\u0131 d\u00fczg\u00fcn y\u00f6netim
        async function create3DScene\u0028\u0029 \u007b
    const scene \u003d document.querySelector\u0028\u0027a-scene\u0027\u0029\u003b
    const assets \u003d document.querySelector\u0028\u0027a-assets\u0027\u0029\u003b

    revokeCurrentVideoURL\u0028\u0029\u003b

    videoElement \u003d document.createElement\u0028\u0027video\u0027\u0029\u003b
    videoElement.setAttribute\u0028\u0027id\u0027\u002c \u0027video-source\u0027\u0029\u003b
    videoElement.setAttribute\u0028\u0027crossorigin\u0027\u002c \u0027anonymous\u0027\u0029\u003b
    videoElement.setAttribute\u0028\u0027playsinline\u0027\u002c \u0027\u0027\u0029\u003b
    videoElement.setAttribute\u0028\u0027webkit-playsinline\u0027\u002c \u0027\u0027\u0029\u003b
    videoElement.setAttribute\u0028\u0027preload\u0027\u002c \u0027auto\u0027\u0029\u003b

    videoElement.listeners \u003d \u005b\u005d\u003b

    const handleLoadedMetadata \u003d \u0028\u0029 \u003d\u003e \u007b
        debugLog\u0028\u0027\ud83d\udcf9 Video metadata loaded\u002c duration\u003a\u0027\u002c videoElement.duration\u0029\u003b
    \u007d\u003b

    const handleError \u003d \u0028e\u0029 \u003d\u003e \u007b
        console.error\u0028\u0027Video error\u003a\u0027\u002c e\u0029\u003b
    \u007d\u003b

    videoElement.addEventListener\u0028\u0027loadedmetadata\u0027\u002c handleLoadedMetadata\u0029\u003b
    videoElement.addEventListener\u0028\u0027error\u0027\u002c handleError\u0029\u003b

    videoElement.listeners.push\u0028
        \u007b event\u003a \u0027loadedmetadata\u0027\u002c handler\u003a handleLoadedMetadata \u007d\u002c
        \u007b event\u003a \u0027error\u0027\u002c handler\u003a handleError \u007d
    \u0029\u003b

    \u002f\u002f P2P mi yoksa URL mi kontrol et
    const isP2PRoom \u003d currentRoomData.p2p \u0026\u0026 currentRoomData.p2p.magnetURI\u003b
    
    if \u0028isP2PRoom \u0026\u0026 \u0021isRoomOwner\u0029 \u007b
        \u002f\u002f \u0130zleyici\u003a P2P\u0027den indir
        try \u007b
            showP2PStatus\u0028\u0027\ud83d\udd0d P2P ba\u011flant\u0131s\u0131 kuruluyor...\u0027\u002c 0\u0029\u003b
            const videoFile \u003d await joinP2PTorrent\u0028currentRoomData.p2p.magnetURI\u0029\u003b
            
            \u002f\u002f WebTorrent file\u0027\u0131 video element\u0027e ba\u011fla
            videoFile.renderTo\u0028videoElement\u002c \u007b autoplay\u003a false \u007d\u002c \u0028err\u0029 \u003d\u003e \u007b
                if \u0028err\u0029 \u007b
                    console.error\u0028\u0027Render error\u003a\u0027\u002c err\u0029\u003b
                    updateP2PStatus\u0028\u0027\u274c Video y\u00fcklenemedi\u0027\u002c 0\u0029\u003b
                \u007d else \u007b
                    debugLog\u0028\u0027\u2705 P2P video rendered to element\u0027\u0029\u003b
                \u007d
            \u007d\u0029\u003b
        \u007d catch \u0028e\u0029 \u007b
            console.error\u0028\u0027P2P join error\u003a\u0027\u002c e\u0029\u003b
            updateP2PStatus\u0028\u0027\u274c P2P hatas\u0131\u003a \u0027 \u002b e.message\u002c 0\u0029\u003b
        \u007d
    \u007d else if \u0028isP2PRoom \u0026\u0026 isRoomOwner\u0029 \u007b
        \u002f\u002f Sahip\u003a Zaten seed ediyoruz\u002c lokal dosyay\u0131 kullan
        if \u0028selectedLocalFile\u0029 \u007b
            const objectURL \u003d URL.createObjectURL\u0028selectedLocalFile\u0029\u003b
            currentVideoObjectURL \u003d objectURL\u003b
            videoElement.src \u003d objectURL\u003b
            showP2PStatus\u0028\u0027\ud83d\udce4 Payla\u015f\u0131l\u0131yor...\u0027\u002c 100\u0029\u003b
        \u007d
    \u007d else \u007b
        \u002f\u002f Normal URL modu
        setupAdaptiveSource\u0028currentRoomData.videoUrl\u0029\u003b
    \u007d

    const playListener \u003d \u0028\u0029 \u003d\u003e \u007b
        if \u0028syncState\u0029 return\u003b
        if \u0028currentRoomData.videoState \u0026\u0026 \u0021currentRoomData.videoState.isPlaying\u0029 \u007b
            syncVideoState\u0028\u0029\u003b
        \u007d
    \u007d\u003b

    const pauseListener \u003d \u0028\u0029 \u003d\u003e \u007b
        if \u0028syncState\u0029 return\u003b
        if \u0028currentRoomData.videoState \u0026\u0026 currentRoomData.videoState.isPlaying\u0029 \u007b
            syncVideoState\u0028\u0029\u003b
        \u007d
    \u007d\u003b

    const seekedListener \u003d \u0028\u0029 \u003d\u003e \u007b
        if \u0028syncState \u007c\u007c isSeeking\u0029 return\u003b
        syncVideoState\u0028\u0029\u003b
    \u007d\u003b

    if \u0028isRoomOwner\u0029 \u007b
        videoElement.addEventListener\u0028\u0027play\u0027\u002c playListener\u0029\u003b
        videoElement.addEventListener\u0028\u0027pause\u0027\u002c pauseListener\u0029\u003b
        videoElement.addEventListener\u0028\u0027seeked\u0027\u002c seekedListener\u0029\u003b

        videoElement.listeners.push\u0028
            \u007b event\u003a \u0027play\u0027\u002c handler\u003a playListener \u007d\u002c
            \u007b event\u003a \u0027pause\u0027\u002c handler\u003a pauseListener \u007d\u002c
            \u007b event\u003a \u0027seeked\u0027\u002c handler\u003a seekedListener \u007d
        \u0029\u003b
    \u007d

    assets.appendChild\u0028videoElement\u0029\u003b

    if \u0028currentRoomData.environment \u003d\u003d\u003d \u0027minimal\u0027\u0029 \u007b
        const sky \u003d document.createElement\u0028\u0027a-sky\u0027\u0029\u003b
        sky.setAttribute\u0028\u0027color\u0027\u002c \u0027\u0023000\u0027\u0029\u003b
        scene.appendChild\u0028sky\u0029\u003b
    \u007d

    const screenSizes \u003d \u007b
        medium\u003a \u007b width\u003a 8\u002c height\u003a 4.5 \u007d\u002c
        large\u003a \u007b width\u003a 10\u002c height\u003a 4.76 \u007d\u002c
        imax\u003a \u007b width\u003a 7\u002c height\u003a 10 \u007d
    \u007d\u003b
    const size \u003d screenSizes\u005bcurrentRoomData.screenSize\u005d \u007c\u007c screenSizes.medium\u003b

    const videoScreen \u003d document.createElement\u0028\u0027a-plane\u0027\u0029\u003b
    videoScreen.setAttribute\u0028\u0027id\u0027\u002c \u0027video-screen\u0027\u0029\u003b
    videoScreen.setAttribute\u0028\u0027position\u0027\u002c \u00270 2 -5\u0027\u0029\u003b
    videoScreen.setAttribute\u0028\u0027width\u0027\u002c size.width\u0029\u003b
    videoScreen.setAttribute\u0028\u0027height\u0027\u002c size.height\u0029\u003b
    videoScreen.setAttribute\u0028\u0027material\u0027\u002c \u0027src\u003a \u0023video-source\u003b shader\u003a flat\u0027\u0029\u003b
    videoScreen.setAttribute\u0028\u0027video-texture-fix\u0027\u002c \u0027\u0023video-source\u0027\u0029\u003b
    scene.appendChild\u0028videoScreen\u0029\u003b

    if \u0028isRoomOwner\u0029 \u007b
        const panel \u003d document.createElement\u0028\u0027a-entity\u0027\u0029\u003b
        panel.setAttribute\u0028\u0027id\u0027\u002c \u0027vr-panel\u0027\u0029\u003b
        panel.setAttribute\u0028\u0027position\u0027\u002c \u00270 1 -2\u0027\u0029\u003b

        const buttons \u003d \u005b
            \u007b text\u003a \u0027\u25b6\u0027\u002c position\u003a \u0027-0.6 0 0\u0027\u002c event\u003a \u0027play\u0027 \u007d\u002c
            \u007b text\u003a \u0027\u23f8\u0027\u002c position\u003a \u0027-0.2 0 0\u0027\u002c event\u003a \u0027pause\u0027 \u007d\u002c
            \u007b text\u003a \u0027\u23ea\u0027\u002c position\u003a \u00270.2 0 0\u0027\u002c event\u003a \u0027rewind\u0027 \u007d\u002c
            \u007b text\u003a \u0027\u23e9\u0027\u002c position\u003a \u00270.6 0 0\u0027\u002c event\u003a \u0027forward\u0027 \u007d
        \u005d\u003b

        \u002f\u002f \u2705 FIX\u003a VR button listener\u0027lar\u0131n\u0131 track et \u0028cleanup i\u00e7in\u0029
        panel._buttonListeners \u003d \u005b\u005d\u003b

        buttons.forEach\u0028btn \u003d\u003e \u007b
            const button \u003d document.createElement\u0028\u0027a-text\u0027\u0029\u003b
            button.setAttribute\u0028\u0027value\u0027\u002c btn.text\u0029\u003b
            button.setAttribute\u0028\u0027position\u0027\u002c btn.position\u0029\u003b
            button.setAttribute\u0028\u0027align\u0027\u002c \u0027center\u0027\u0029\u003b
            button.setAttribute\u0028\u0027color\u0027\u002c \u0027\u00234ade80\u0027\u0029\u003b
            button.setAttribute\u0028\u0027width\u0027\u002c 4\u0029\u003b
            button.setAttribute\u0028\u0027class\u0027\u002c \u0027clickable\u0027\u0029\u003b
            
            const clickHandler \u003d \u0028\u0029 \u003d\u003e handleVRButton\u0028btn.event\u0029\u003b
            button.addEventListener\u0028\u0027click\u0027\u002c clickHandler\u0029\u003b
            
            \u002f\u002f \u2705 FIX\u003a Listener\u0027\u0131 kaydet
            panel._buttonListeners.push\u0028\u007b element\u003a button\u002c handler\u003a clickHandler \u007d\u0029\u003b
            
            panel.appendChild\u0028button\u0029\u003b
        \u007d\u0029\u003b

        scene.appendChild\u0028panel\u0029\u003b
    \u007d
\u007d
