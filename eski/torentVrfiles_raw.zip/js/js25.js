
        function handleVRButton\u0028action\u0029 \u007b
            if \u0028\u0021isRoomOwner\u0029 return\u003b
            
            switch\u0028action\u0029 \u007b
                case \u0027play\u0027\u003a
                    playVideo\u0028\u0029\u003b
                    break\u003b
                case \u0027pause\u0027\u003a
                    pauseVideo\u0028\u0029\u003b
                    break\u003b
                case \u0027rewind\u0027\u003a
                    seekBackward\u0028\u0029\u003b
                    break\u003b
                case \u0027forward\u0027\u003a
                    seekForward\u0028\u0029\u003b
                    break\u003b
            \u007d
        \u007d
        
        \u002f\u002f \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d VIDEO CONTROLS \u0028OWNER ONLY\u0029 \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d
        let playPromisePending \u003d false\u003b
