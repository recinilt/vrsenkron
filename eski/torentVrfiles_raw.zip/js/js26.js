        
        function playVideo\u0028\u0029 \u007b
            if \u0028\u0021isRoomOwner \u007c\u007c \u0021videoElement\u0029 return\u003b
            
            if \u0028syncState \u0026\u0026 syncState.isBuffering\u0029 \u007b
                startSyncCountdown\u0028\u0029\u003b
                return\u003b
            \u007d
            
            if \u0028playPromisePending\u0029 return\u003b
            playPromisePending \u003d true\u003b
            
            lastCommandSource \u003d \u0027self\u0027\u003b
            
            const playPromise \u003d videoElement.play\u0028\u0029\u003b
            
            if \u0028playPromise \u0021\u003d\u003d undefined\u0029 \u007b
                playPromise.then\u0028\u0028\u0029 \u003d\u003e \u007b
                    playPromisePending \u003d false\u003b
                    const serverTime \u003d getServerTime\u0028\u0029\u003b
                    
                    db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId \u002b \u0027\u002fvideoState\u0027\u0029.update\u0028\u007b
                        isPlaying\u003a true\u002c
                        currentTime\u003a videoElement.currentTime\u002c
                        startTimestamp\u003a serverTime\u002c
                        lastUpdate\u003a firebase.database.ServerValue.TIMESTAMP
                    \u007d\u0029\u003b
                    
                    \u002f\u002f \u2705 FIX\u003a Timeout\u0027u track et
                    trackTimeout\u0028setTimeout\u0028\u0028\u0029 \u003d\u003e \u007b
                        lastCommandSource \u003d null\u003b
                    \u007d\u002c 300\u0029\u0029\u003b
                \u007d\u0029.catch\u0028error \u003d\u003e \u007b
                    playPromisePending \u003d false\u003b
                    lastCommandSource \u003d null\u003b
                    
                    if \u0028error.name \u003d\u003d\u003d \u0027NotAllowedError\u0027\u0029 \u007b
                        console.warn\u0028\u0027Autoplay blocked - user interaction required\u0027\u0029\u003b
                    \u007d else if \u0028error.name \u0021\u003d\u003d \u0027AbortError\u0027\u0029 \u007b
                        console.warn\u0028\u0027Play error\u003a\u0027\u002c error\u0029\u003b
                    \u007d
                \u007d\u0029\u003b
            \u007d else \u007b
                playPromisePending \u003d false\u003b
                const serverTime \u003d getServerTime\u0028\u0029\u003b
                db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId \u002b \u0027\u002fvideoState\u0027\u0029.update\u0028\u007b
                    isPlaying\u003a true\u002c
                    currentTime\u003a videoElement.currentTime\u002c
                    startTimestamp\u003a serverTime\u002c
                    lastUpdate\u003a firebase.database.ServerValue.TIMESTAMP
                \u007d\u0029\u003b
                \u002f\u002f \u2705 FIX\u003a Timeout\u0027u track et
                trackTimeout\u0028setTimeout\u0028\u0028\u0029 \u003d\u003e \u007b lastCommandSource \u003d null\u003b \u007d\u002c 300\u0029\u0029\u003b
            \u007d
        \u007d
