        
        function pauseVideo\u0028\u0029 \u007b
            if \u0028\u0021isRoomOwner \u007c\u007c \u0021videoElement\u0029 return\u003b
            
            if \u0028playPromisePending\u0029 \u007b
                const checkAndPause \u003d \u0028\u0029 \u003d\u003e \u007b
                    if \u0028\u0021playPromisePending\u0029 \u007b
                        executePause\u0028\u0029\u003b
                    \u007d else \u007b
                        setTimeout\u0028checkAndPause\u002c 50\u0029\u003b
                    \u007d
                \u007d\u003b
                setTimeout\u0028checkAndPause\u002c 50\u0029\u003b
                return\u003b
            \u007d
            
            executePause\u0028\u0029\u003b
        \u007d
        
        function executePause\u0028\u0029 \u007b
            if \u0028\u0021videoElement\u0029 return\u003b
            
            lastCommandSource \u003d \u0027self\u0027\u003b
            
            videoElement.pause\u0028\u0029\u003b
            
            const currentPos \u003d videoElement.currentTime\u003b
            
            const updates \u003d \u007b
                \u0027videoState\u002fisPlaying\u0027\u003a false\u002c
                \u0027videoState\u002fcurrentTime\u0027\u003a currentPos\u002c
                \u0027videoState\u002fstartTimestamp\u0027\u003a getServerTime\u0028\u0029\u002c
                \u0027videoState\u002flastUpdate\u0027\u003a firebase.database.ServerValue.TIMESTAMP\u002c
                \u0027keyframes\u0027\u003a null\u002c
                \u0027syncState\u0027\u003a null
            \u007d\u003b
            
            db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId\u0029.update\u0028updates\u0029.then\u0028\u0028\u0029 \u003d\u003e \u007b
                debugLog\u0028\u0027\u23f8\ufe0f Pause broadcasted\u002c keyframes\u002fsyncState cleared\u0027\u0029\u003b
            \u007d\u0029.catch\u0028err \u003d\u003e console.warn\u0028\u0027Pause update error\u003a\u0027\u002c err\u0029\u0029\u003b
            
            \u002f\u002f \u2705 FIX\u003a Timeout\u0027u track et
            trackTimeout\u0028setTimeout\u0028\u0028\u0029 \u003d\u003e \u007b
                lastCommandSource \u003d null\u003b
            \u007d\u002c 300\u0029\u0029\u003b
        \u007d
