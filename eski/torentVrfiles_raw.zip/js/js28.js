        
        \u002f\u002f \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d SYNC MECHANISM \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d
        
        function initiateSync\u0028\u0029 \u007b
            if \u0028\u0021currentRoomId \u007c\u007c \u0021videoElement\u0029 return\u003b
            
            debugLog\u0028\u0027\ud83d\udd04 Sync initiated by user\u0027\u0029\u003b
            
            const syncBtn \u003d getCachedElement\u0028\u0027btn-sync\u0027\u0029\u003b
            if \u0028syncBtn\u0029 syncBtn.disabled \u003d true\u003b
            
            db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId \u002b \u0027\u002factiveViewers\u0027\u0029.once\u0028\u0027value\u0027\u0029
                .then\u0028snapshot \u003d\u003e \u007b
                    const viewers \u003d snapshot.val\u0028\u0029\u003b
                    if \u0028\u0021viewers\u0029 return\u003b
                    
                    const positions \u003d \u005b\u005d\u003b
                    
                    positions.push\u0028videoElement.currentTime\u0029\u003b
                    
                    Object.keys\u0028viewers\u0029.forEach\u0028uid \u003d\u003e \u007b
                        if \u0028uid \u0021\u003d\u003d currentUser.uid \u0026\u0026 viewers\u005buid\u005d.currentPosition \u0021\u003d\u003d undefined\u0029 \u007b
                            positions.push\u0028viewers\u005buid\u005d.currentPosition\u0029\u003b
                        \u007d
                    \u007d\u0029\u003b
                    
                    let minPosition \u003d Math.min\u0028...positions\u0029\u003b
                    \u002f\u002f \u2705 FIX\u003a NaN\u002fInfinity validation
                    if \u0028\u0021isFinite\u0028minPosition\u0029 \u007c\u007c isNaN\u0028minPosition\u0029\u0029 \u007b
                        minPosition \u003d videoElement.currentTime \u007c\u007c 0\u003b
                    \u007d
                    const targetPosition \u003d Math.max\u00280\u002c minPosition - 4\u0029\u003b
                    
                    debugLog\u0028\u0027\ud83d\udccd Positions\u003a\u0027\u002c positions\u002c \u0027\u2192 Target\u003a\u0027\u002c targetPosition\u0029\u003b
                    
                    const currentPos \u003d videoElement.currentTime\u003b
                    if \u0028Math.abs\u0028currentPos - targetPosition\u0029 \u003e 1\u0029 \u007b
                        db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId \u002b \u0027\u002fsyncState\u0027\u0029.set\u0028\u007b
                            isBuffering\u003a true\u002c
                            syncedSeekPosition\u003a targetPosition\u002c
                            syncedPlayTime\u003a null\u002c
                            initiatedBy\u003a currentUser.uid\u002c
                            initiatedAt\u003a firebase.database.ServerValue.TIMESTAMP
                        \u007d\u0029\u003b
                    \u007d
                    
                    applySyncState\u0028\u007b
                        isBuffering\u003a true\u002c
                        syncedSeekPosition\u003a targetPosition\u002c
                        syncedPlayTime\u003a null
                    \u007d\u0029\u003b
                \u007d\u0029
                .catch\u0028error \u003d\u003e \u007b
                    console.error\u0028\u0027Sync error\u003a\u0027\u002c error\u0029\u003b
                    if \u0028syncBtn\u0029 syncBtn.disabled \u003d false\u003b
                \u007d\u0029\u003b
        \u007d
