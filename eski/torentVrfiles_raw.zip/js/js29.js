        
        function applySyncState\u0028state\u0029 \u007b
            if \u0028\u0021videoElement \u007c\u007c \u0021state\u0029 return\u003b
            
            \u002f\u002f \u2705 FIX\u003a syncedSeekPosition validation
            if \u0028state.syncedSeekPosition \u0021\u003d\u003d undefined \u0026\u0026 state.syncedSeekPosition \u0021\u003d\u003d null\u0029 \u007b
                if \u0028\u0021isFinite\u0028state.syncedSeekPosition\u0029 \u007c\u007c isNaN\u0028state.syncedSeekPosition\u0029\u0029 \u007b
                    debugLog\u0028\u0027\u26a0\ufe0f Invalid syncedSeekPosition in applySyncState\u0027\u0029\u003b
                    state.syncedSeekPosition \u003d videoElement.currentTime \u007c\u007c 0\u003b
                \u007d
            \u007d
            
            syncState \u003d state\u003b
            syncModeActive \u003d true\u003b
            
            if \u0028state.isBuffering\u0029 \u007b
                videoElement.pause\u0028\u0029\u003b
                videoElement.currentTime \u003d state.syncedSeekPosition\u003b
                
                updateSyncUI\u0028\u0027\ud83d\udd04 Senkronizasyon ba\u015flat\u0131ld\u0131...\u0027\u0029\u003b
                \u002f\u002f \u2705 FIX\u003a Timeout\u0027lar\u0131 track et
                trackTimeout\u0028setTimeout\u0028\u0028\u0029 \u003d\u003e \u007b
                    updateSyncUI\u0028\u0060\u23f8\ufe0f Video \u0024\u007bstate.syncedSeekPosition.toFixed\u00281\u0029\u007ds\u0027de duraklat\u0131ld\u0131\u0060\u0029\u003b
                \u007d\u002c 500\u0029\u0029\u003b
                trackTimeout\u0028setTimeout\u0028\u0028\u0029 \u003d\u003e \u007b
                    if \u0028isRoomOwner\u0029 \u007b
                        updateSyncUI\u0028\u0027\u23f3 Haz\u0131r oldu\u011funuzda \u25b6\ufe0f OYNAT butonuna bas\u0131n\u0027\u0029\u003b
                    \u007d else \u007b
                        updateSyncUI\u0028\u0027\u23f3 Oda sahibinin oynatmas\u0131n\u0131 bekliyoruz...\u0027\u0029\u003b
                    \u007d
                \u007d\u002c 1000\u0029\u0029\u003b
                
                updateControlsForSync\u0028true\u0029\u003b
                
                \u002f\u002f \u2705 FIX \u00239\u003a Buffer timeout 30s \u2192 15s
                if \u0028isRoomOwner\u0029 \u007b
                    syncTimeoutId \u003d setTimeout\u0028\u0028\u0029 \u003d\u003e \u007b
                        debugLog\u0028\u0027\u23f0 Sync timeout - auto starting countdown\u0027\u0029\u003b
                        startSyncCountdown\u0028\u0029\u003b
                    \u007d\u002c 15000\u0029\u003b \u002f\u002f 30s \u2192 15s
                \u007d
                
            \u007d else if \u0028state.syncedPlayTime\u0029 \u007b
                startSyncCountdownFromState\u0028state\u0029\u003b
            \u007d
        \u007d
        
        function startSyncCountdown\u0028\u0029 \u007b
            if \u0028\u0021isRoomOwner \u007c\u007c \u0021syncState\u0029 return\u003b
            
            if \u0028syncTimeoutId\u0029 \u007b
                clearTimeout\u0028syncTimeoutId\u0029\u003b
                syncTimeoutId \u003d null\u003b
            \u007d
            
            const playTime \u003d Date.now\u0028\u0029 \u002b 5000\u003b
            
            db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId \u002b \u0027\u002fsyncState\u0027\u0029.update\u0028\u007b
                isBuffering\u003a false\u002c
                syncedPlayTime\u003a playTime
            \u007d\u0029\u003b
        \u007d
