
function destroyAdaptiveStreaming\u0028\u0029 \u007b
    try \u007b
        if \u0028hlsInstance\u0029 \u007b
            hlsInstance.destroy\u0028\u0029\u003b
            hlsInstance \u003d null\u003b
        \u007d
    \u007d catch \u0028e\u0029 \u007b\u007d

    try \u007b
        if \u0028dashInstance\u0029 \u007b
            dashInstance.reset\u0028\u0029\u003b
            dashInstance \u003d null\u003b
        \u007d
    \u007d catch \u0028e\u0029 \u007b\u007d
\u007d

function updateQualityCapUI\u0028\u0029 \u007b
    const label \u003d getCachedElement\u0028\u0027quality-cap-label\u0027\u0029\u003b
    if \u0028label\u0029 label.textContent \u003d \u0060Max\u003a \u0024\u007babrMaxHeightCap\u007dp\u0060\u003b

    const upBtn \u003d getCachedElement\u0028\u0027btn-quality-up\u0027\u0029\u003b
    const downBtn \u003d getCachedElement\u0028\u0027btn-quality-down\u0027\u0029\u003b
    if \u0028upBtn\u0029 upBtn.disabled \u003d abrMaxHeightCap \u003e\u003d 720\u003b
    if \u0028downBtn\u0029 downBtn.disabled \u003d abrMaxHeightCap \u003c\u003d QUALITY_CAPS\u005b0\u005d\u003b
\u007d

function setMaxQualityCap\u0028newCap\u0029 \u007b
    abrMaxHeightCap \u003d Math.max\u0028QUALITY_CAPS\u005b0\u005d\u002c Math.min\u0028720\u002c newCap\u0029\u0029\u003b
    updateQualityCapUI\u0028\u0029\u003b
    applyAdaptiveCap\u0028\u0029\u003b
\u007d

function increaseMaxQuality\u0028\u0029 \u007b
    const idx \u003d QUALITY_CAPS.indexOf\u0028abrMaxHeightCap\u0029\u003b
    const next \u003d idx \u003d\u003d\u003d -1 \u003f 720 \u003a QUALITY_CAPS\u005bMath.min\u0028QUALITY_CAPS.length - 1\u002c idx \u002b 1\u0029\u005d\u003b
    setMaxQualityCap\u0028next\u0029\u003b
\u007d

function decreaseMaxQuality\u0028\u0029 \u007b
    const idx \u003d QUALITY_CAPS.indexOf\u0028abrMaxHeightCap\u0029\u003b
    const next \u003d idx \u003d\u003d\u003d -1 \u003f 480 \u003a QUALITY_CAPS\u005bMath.max\u00280\u002c idx - 1\u0029\u005d\u003b
    setMaxQualityCap\u0028next\u0029\u003b
\u007d

function applyAdaptiveCap\u0028\u0029 \u007b
    if \u0028hlsInstance\u0029 \u007b
        applyHlsCap\u0028\u0029\u003b
    \u007d
    if \u0028dashInstance\u0029 \u007b
        applyDashCap\u0028\u0029\u003b
    \u007d
\u007d

function applyHlsCap\u0028\u0029 \u007b
    if \u0028\u0021hlsInstance \u007c\u007c \u0021hlsInstance.levels \u007c\u007c hlsInstance.levels.length \u003d\u003d\u003d 0\u0029 return\u003b

    let capIndex \u003d -1\u003b
    for \u0028let i \u003d 0\u003b i \u003c hlsInstance.levels.length\u003b i\u002b\u002b\u0029 \u007b
        const h \u003d hlsInstance.levels\u005bi\u005d.height \u007c\u007c 0\u003b
        if \u0028h \u003e 0 \u0026\u0026 h \u003c\u003d abrMaxHeightCap\u0029 capIndex \u003d i\u003b
    \u007d

    if \u0028capIndex \u003d\u003d\u003d -1\u0029 \u007b
        \u002f\u002f If levels don\u0027t expose height\u002c just cap to the top level \u0028best effort\u0029
        capIndex \u003d hlsInstance.levels.length - 1\u003b
    \u007d

    hlsInstance.autoLevelCapping \u003d capIndex\u003b

    \u002f\u002f If currently above cap\u002c force next segment down
    if \u0028hlsInstance.currentLevel \u003e capIndex\u0029 \u007b
        hlsInstance.nextAutoLevel \u003d capIndex\u003b
    \u007d
\u007d

function normalizeKbps\u0028value\u0029 \u007b
    if \u0028\u0021isFinite\u0028value\u0029 \u007c\u007c isNaN\u0028value\u0029\u0029 return null\u003b
    \u002f\u002f dash.js commonly uses kbps\u002c but guard if bits\u002fs slipped in
    if \u0028value \u003e 100000\u0029 return Math.round\u0028value \u002f 1000\u0029\u003b
    return Math.round\u0028value\u0029\u003b
\u007d
