        
        \u002f\u002f \u2705 FIX \u002311\u003a Countdown interval\u0027\u0131 track et
        function startSyncCountdownFromState\u0028state\u0029 \u007b
            if \u0028\u0021state.syncedPlayTime\u0029 return\u003b
            
            const playTime \u003d state.syncedPlayTime\u003b
            const now \u003d Date.now\u0028\u0029\u003b
            
            if \u0028playTime \u003c\u003d now\u0029 \u007b
                \u002f\u002f \u2705 FIX\u003a Timeout\u0027u track et
                trackTimeout\u0028setTimeout\u0028\u0028\u0029 \u003d\u003e \u007b
                    executeSync\u0028state\u0029\u003b
                \u007d\u002c 100\u0029\u0029\u003b
                return\u003b
            \u007d
            
            \u002f\u002f \u2705 INTERVAL FIX\u003a DOM element\u0027i d\u00f6ng\u00fc d\u0131\u015f\u0131nda cache\u0027le
            const countdownElement \u003d getCachedElement\u0028\u0027sync-countdown\u0027\u0029\u003b
            if \u0028countdownElement\u0029 \u007b
                countdownElement.style.display \u003d \u0027block\u0027\u003b
            \u007d
            
            \u002f\u002f \u2705 FIX \u002311\u003a Mevcut interval\u0027\u0131 temizle
            if \u0028countdownInterval\u0029 \u007b
                clearInterval\u0028countdownInterval\u0029\u003b
                countdownInterval \u003d null\u003b
            \u007d
            
            countdownInterval \u003d setInterval\u0028\u0028\u0029 \u003d\u003e \u007b
                const remaining \u003d playTime - Date.now\u0028\u0029\u003b
                
                if \u0028remaining \u003c\u003d 0\u0029 \u007b
                    clearInterval\u0028countdownInterval\u0029\u003b
                    countdownInterval \u003d null\u003b
                    
                    \u002f\u002f \u2705 FIX\u003a Timeout\u0027u track et
                    trackTimeout\u0028setTimeout\u0028\u0028\u0029 \u003d\u003e \u007b
                        executeSync\u0028state\u0029\u003b
                    \u007d\u002c 100\u0029\u0029\u003b
                \u007d else \u007b
                    const seconds \u003d Math.ceil\u0028remaining \u002f 1000\u0029\u003b
                    \u002f\u002f \u2705 countdownElement d\u00f6ng\u00fc d\u0131\u015f\u0131nda cache\u0027lendi
                    if \u0028countdownElement\u0029 \u007b
                        countdownElement.textContent \u003d \u0060\u25b6\ufe0f \u0024\u007bseconds\u007d saniye sonra ba\u015fl\u0131yor...\u0060\u003b
                    \u007d
                    updateSyncUI\u0028\u0060\u23f1\ufe0f \u0024\u007bseconds\u007d saniye sonra oynat\u0131lacak...\u0060\u0029\u003b
                \u007d
            \u007d\u002c 100\u0029\u003b
            
            \u002f\u002f \u2705 FIX \u002311\u003a Interval\u0027\u0131 track et
            trackInterval\u0028countdownInterval\u0029\u003b
        \u007d
