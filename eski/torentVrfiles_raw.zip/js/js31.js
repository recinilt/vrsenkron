        
        \u002f\u002f \u2705 FIX \u00234\u003a executeSync - seek\u002fplay yar\u0131\u015fmas\u0131n\u0131 \u00f6nle
        function executeSync\u0028state\u0029 \u007b
            if \u0028\u0021videoElement \u007c\u007c \u0021state\u0029 return\u003b
            
            \u002f\u002f \u2705 FIX\u003a syncedSeekPosition NaN\u002fInfinity validation
            if \u0028\u0021isFinite\u0028state.syncedSeekPosition\u0029 \u007c\u007c isNaN\u0028state.syncedSeekPosition\u0029\u0029 \u007b
                debugLog\u0028\u0027\u26a0\ufe0f Invalid syncedSeekPosition\u002c aborting sync\u0027\u0029\u003b
                clearSyncState\u0028\u0029\u003b
                return\u003b
            \u007d
            
            debugLog\u0028\u0027\ud83c\udfac Executing sync at\u003a\u0027\u002c Date.now\u0028\u0029\u0029\u003b
            
            \u002f\u002f \u2705 FIX \u00234\u003a \u00d6nce seek\u002c sonra seeked event\u0027i bekle\u002c sonra play
            videoElement.currentTime \u003d state.syncedSeekPosition\u003b
            videoElement.playbackRate \u003d 1.0\u003b
            
            \u002f\u002f \u2705 FIX\u003a seeked listener\u0027\u0131 track et
            let syncSeekCompleted \u003d false\u003b
            
            const onSeekedForSync \u003d \u0028\u0029 \u003d\u003e \u007b
                if \u0028syncSeekCompleted\u0029 return\u003b
                syncSeekCompleted \u003d true\u003b
                videoElement.removeEventListener\u0028\u0027seeked\u0027\u002c onSeekedForSync\u0029\u003b
                
                videoElement.play\u0028\u0029.then\u0028\u0028\u0029 \u003d\u003e \u007b
                    debugLog\u0028\u0027\u2705 Sync play successful\u0027\u0029\u003b
                    
                    syncModeActive \u003d false\u003b
                    
                    if \u0028isRoomOwner\u0029 \u007b
                        const serverTime \u003d getServerTime\u0028\u0029\u003b
                        db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId \u002b \u0027\u002fvideoState\u0027\u0029.update\u0028\u007b
                            isPlaying\u003a true\u002c
                            currentTime\u003a state.syncedSeekPosition\u002c
                            startTimestamp\u003a serverTime\u002c
                            lastUpdate\u003a firebase.database.ServerValue.TIMESTAMP
                        \u007d\u0029.then\u0028\u0028\u0029 \u003d\u003e \u007b
                            \u002f\u002f \u2705 FIX\u003a Timeout\u0027u track et
                            trackTimeout\u0028setTimeout\u0028\u0028\u0029 \u003d\u003e \u007b
                                clearSyncState\u0028\u0029\u003b
                            \u007d\u002c 500\u0029\u0029\u003b
                        \u007d\u0029\u003b
                    \u007d else \u007b
                        \u002f\u002f \u2705 FIX\u003a Timeout\u0027u track et
                        trackTimeout\u0028setTimeout\u0028\u0028\u0029 \u003d\u003e \u007b
                            clearSyncState\u0028\u0029\u003b
                        \u007d\u002c 1000\u0029\u0029\u003b
                    \u007d
                \u007d\u0029.catch\u0028error \u003d\u003e \u007b
                    console.error\u0028\u0027Sync play error\u003a\u0027\u002c error\u0029\u003b
                    \u002f\u002f \u2705 FIX\u003a Timeout\u0027u track et
                    trackTimeout\u0028setTimeout\u0028\u0028\u0029 \u003d\u003e \u007b
                        clearSyncState\u0028\u0029\u003b
                    \u007d\u002c 500\u0029\u0029\u003b
                \u007d\u0029\u003b
            \u007d\u003b
            
            videoElement.addEventListener\u0028\u0027seeked\u0027\u002c onSeekedForSync\u0029\u003b
            
            \u002f\u002f \u2705 FIX \u00234\u003a Timeout fallback - track edildi
            trackTimeout\u0028setTimeout\u0028\u0028\u0029 \u003d\u003e \u007b
                if \u0028\u0021syncSeekCompleted\u0029 \u007b
                    syncSeekCompleted \u003d true\u003b
                    videoElement.removeEventListener\u0028\u0027seeked\u0027\u002c onSeekedForSync\u0029\u003b
                    debugLog\u0028\u0027\u26a0\ufe0f Sync seeked timeout\u002c forcing play\u0027\u0029\u003b
                    videoElement.play\u0028\u0029.catch\u0028\u0028\u0029 \u003d\u003e \u007b\u007d\u0029\u003b
                    syncModeActive \u003d false\u003b
                    clearSyncState\u0028\u0029\u003b
                \u007d
            \u007d\u002c 3000\u0029\u0029\u003b
        \u007d
