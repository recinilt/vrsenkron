        
        function clearSyncState\u0028\u0029 \u007b
            syncState \u003d null\u003b
            syncModeActive \u003d false\u003b
            
            if \u0028countdownInterval\u0029 \u007b
                clearInterval\u0028countdownInterval\u0029\u003b
                countdownInterval \u003d null\u003b
            \u007d
            
            if \u0028syncTimeoutId\u0029 \u007b
                clearTimeout\u0028syncTimeoutId\u0029\u003b
                syncTimeoutId \u003d null\u003b
            \u007d
            
            const countdownElement \u003d getCachedElement\u0028\u0027sync-countdown\u0027\u0029\u003b
            if \u0028countdownElement\u0029 \u007b
                countdownElement.style.display \u003d \u0027none\u0027\u003b
                countdownElement.textContent \u003d \u0027\u0027\u003b
            \u007d
            
            updateControlsForSync\u0028false\u0029\u003b
            
            if \u0028isRoomOwner \u0026\u0026 currentRoomId\u0029 \u007b
                db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId \u002b \u0027\u002fsyncState\u0027\u0029.remove\u0028\u0029\u003b
            \u007d
            
            debugLog\u0028\u0027\ud83e\uddf9 Sync state cleared\u0027\u0029\u003b
        \u007d
        
        function updateSyncUI\u0028message\u0029 \u007b
            const statusText \u003d getCachedElement\u0028\u0027sync-text\u0027\u0029\u003b
            if \u0028statusText\u0029 \u007b
                statusText.textContent \u003d message\u003b
                statusText.className \u003d \u0027status-warning\u0027\u003b
            \u007d
        \u007d
        
        function updateControlsForSync\u0028inSync\u0029 \u007b
            const playBtn \u003d getCachedElement\u0028\u0027btn-play\u0027\u0029\u003b
            const pauseBtn \u003d getCachedElement\u0028\u0027btn-pause\u0027\u0029\u003b
            const rewindBtn \u003d getCachedElement\u0028\u0027btn-rewind\u0027\u0029\u003b
            const forwardBtn \u003d getCachedElement\u0028\u0027btn-forward\u0027\u0029\u003b
            const syncBtn \u003d getCachedElement\u0028\u0027btn-sync\u0027\u0029\u003b
            
            if \u0028inSync\u0029 \u007b
                if \u0028pauseBtn\u0029 pauseBtn.disabled \u003d true\u003b
                if \u0028rewindBtn\u0029 rewindBtn.disabled \u003d true\u003b
                if \u0028forwardBtn\u0029 forwardBtn.disabled \u003d true\u003b
                if \u0028syncBtn\u0029 syncBtn.disabled \u003d true\u003b
                
                if \u0028playBtn\u0029 \u007b
                    playBtn.disabled \u003d \u0021isRoomOwner\u003b
                \u007d
            \u007d else \u007b
                if \u0028isRoomOwner\u0029 \u007b
                    if \u0028playBtn\u0029 playBtn.disabled \u003d false\u003b
                    if \u0028pauseBtn\u0029 pauseBtn.disabled \u003d false\u003b
                    if \u0028rewindBtn\u0029 rewindBtn.disabled \u003d false\u003b
                    if \u0028forwardBtn\u0029 forwardBtn.disabled \u003d false\u003b
                \u007d
                if \u0028syncBtn\u0029 syncBtn.disabled \u003d false\u003b
            \u007d
        \u007d
