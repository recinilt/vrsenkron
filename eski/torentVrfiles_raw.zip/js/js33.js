        
        function listenSyncState\u0028\u0029 \u007b
            const ref \u003d db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId \u002b \u0027\u002fsyncState\u0027\u0029\u003b
            trackListener\u0028ref\u0029\u003b
            
            ref.on\u0028\u0027value\u0027\u002c \u0028snapshot\u0029 \u003d\u003e \u007b
                const state \u003d snapshot.val\u0028\u0029\u003b
                
                if \u0028state\u0029 \u007b
                    applySyncState\u0028state\u0029\u003b
                \u007d else \u007b
                    if \u0028syncState\u0029 \u007b
                        clearSyncState\u0028\u0029\u003b
                    \u007d
                \u007d
            \u007d\u0029\u003b
        \u007d
        
        function updateViewerPosition\u0028\u0029 \u007b
            if \u0028\u0021currentUser \u007c\u007c \u0021currentRoomId \u007c\u007c \u0021videoElement\u0029 return\u003b
            
            try \u007b
                db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId \u002b \u0027\u002factiveViewers\u002f\u0027 \u002b currentUser.uid \u002b \u0027\u002fcurrentPosition\u0027\u0029
                    .set\u0028videoElement.currentTime\u0029
                    .catch\u0028\u0028\u0029 \u003d\u003e \u007b\u007d\u0029\u003b
            \u007d catch \u0028error\u0029 \u007b
                console.warn\u0028\u0027Position update error\u003a\u0027\u002c error\u0029\u003b
            \u007d
        \u007d
        
        \u002f\u002f \u2705 FIX \u002310\u003a syncVideoState - recursive trigger \u00f6nleme
        let isSyncingVideoState \u003d false\u003b
        
        

function syncVideoState\u0028\u0029 \u007b
    if \u0028\u0021isRoomOwner \u007c\u007c \u0021videoElement\u0029 return\u003b

    if \u0028isSyncingVideoState\u0029 \u007b
        debugLog\u0028\u0027\u26a0\ufe0f syncVideoState already in progress\u002c skipping\u0027\u0029\u003b
        return\u003b
    \u007d

    isSyncingVideoState \u003d true\u003b
    const serverTime \u003d getServerTime\u0028\u0029\u003b

    db.ref\u0028\u0060rooms\u002f\u0024\u007bcurrentRoomId\u007d\u002fvideoState\u0060\u0029.update\u0028\u007b
        isPlaying\u003a \u0021videoElement.paused\u002c
        currentTime\u003a videoElement.currentTime\u002c
        startTimestamp\u003a serverTime\u002c
        lastUpdate\u003a firebase.database.ServerValue.TIMESTAMP
    \u007d\u0029
    .then\u0028\u0028\u0029 \u003d\u003e \u007b
        isSyncingVideoState \u003d false\u003b
    \u007d\u0029
    .catch\u0028\u0028err\u0029 \u003d\u003e \u007b
        console.warn\u0028\u0027Sync update error\u003a\u0027\u002c err\u0029\u003b
        isSyncingVideoState \u003d false\u003b
    \u007d\u0029\u003b
\u007d

        \u002f\u002f \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d VIDEO SYNC \u0028OPTIMIZED\u0029 \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d
        let lastVideoStateUpdate \u003d 0\u003b
        let previousVideoState \u003d null\u003b
