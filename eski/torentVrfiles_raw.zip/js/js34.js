        
        \u002f\u002f \u2705 FIX \u00235 \u0026 \u00236\u003a syncVideo - main thread blokaj\u0131 ve DOM thrashing azaltma
        function syncVideo\u0028\u0029 \u007b
            \u002f\u002f \u2705 FIX\u003a isHardSeeking kontrol\u00fc eklendi
            if \u0028isRoomOwner \u007c\u007c isSeeking \u007c\u007c isHardSeeking\u0029 return\u003b
            if \u0028\u0021videoElement \u007c\u007c \u0021currentRoomData \u007c\u007c \u0021currentRoomData.videoState\u0029 return\u003b

            if \u0028syncState \u0026\u0026 syncState.isBuffering\u0029 return\u003b

            const state \u003d currentRoomData.videoState\u003b
            const serverTime \u003d getServerTime\u0028\u0029\u003b
            let expectedTime \u003d state.currentTime\u003b 

            if \u0028state.isPlaying\u0029 \u007b
                const elapsed \u003d \u0028serverTime - state.startTimestamp\u0029 \u002f 1000\u003b
                \u002f\u002f \u2705 FIX\u003a elapsed NaN\u002fInfinity validation \u0028max 24 saat\u0029
                if \u0028\u0021isFinite\u0028elapsed\u0029 \u007c\u007c elapsed \u003c 0 \u007c\u007c elapsed \u003e 86400\u0029 \u007b
                    debugLog\u0028\u0027\u26a0\ufe0f Invalid elapsed time\u002c skipping sync\u0027\u0029\u003b
                    return\u003b
                \u007d
                expectedTime \u003d state.currentTime \u002b elapsed\u003b
            \u007d

            const duration \u003d videoElement.duration \u007c\u007c Infinity\u003b
            expectedTime \u003d Math.max\u00280\u002c Math.min\u0028duration\u002c expectedTime\u0029\u0029\u003b

            const currentTime \u003d videoElement.currentTime\u003b
            const drift \u003d Math.abs\u0028currentTime - expectedTime\u0029 \u002a 1000\u003b

            debugLog\u0028\u0060Sync - Expected\u003a \u0024\u007bexpectedTime\u007d\u002c Current\u003a \u0024\u007bcurrentTime\u007d\u002c Drift\u003a \u0024\u007bdrift\u007d\u002c Playing\u003a \u0024\u007bstate.isPlaying\u007d\u0060\u0029\u003b

            if \u0028\u0021state.isPlaying\u0029 \u007b
                if \u0028\u0021videoElement.paused\u0029 \u007b
                    videoElement.pause\u0028\u0029\u003b
                \u007d
                videoElement.playbackRate \u003d 1.0\u003b

                \u002f\u002f \u2705 FIX \u00236\u003a isBuffering flag\u0027i pause\u0027da temizle
                if \u0028isBuffering\u0029 \u007b
                    if \u0028bufferCountdownInterval\u0029 \u007b
                        clearInterval\u0028bufferCountdownInterval\u0029\u003b
                        bufferCountdownInterval \u003d null\u003b
                    \u007d
                    isBuffering \u003d false\u003b
                    const bufferEl \u003d getCachedElement\u0028\u0027buffer-countdown\u0027\u0029\u003b
                    if \u0028bufferEl\u0029 bufferEl.style.display \u003d \u0027none\u0027\u003b
                    debugLog\u0028\u0027isBuffering cleared due to pause\u0027\u0029\u003b
                \u007d

                if \u0028drift \u003e 500\u0029 \u007b
                    const alreadyAtPosition \u003d Math.abs\u0028videoElement.currentTime - expectedTime\u0029 \u003c 0.5\u003b
                    if \u0028\u0021alreadyAtPosition\u0029 \u007b
                        debugLog\u0028\u0060Paused - seeking to owner position\u002c \u0024\u007bexpectedTime\u007d\u0060\u0029\u003b
                        videoElement.currentTime \u003d expectedTime\u003b
                    \u007d
                \u007d
                return\u003b
            \u007d

            \u002f\u002f PLAYING STATE SYNC
            if \u0028drift \u003c\u003d TIER1_THRESHOLD\u0029 \u007b
                if \u0028videoElement.paused\u0029 \u007b
                    videoElement.play\u0028\u0029.catch\u0028err \u003d\u003e console.warn\u0028\u0027Play failed\u003a\u0027\u002c err\u0029\u0029\u003b
                    \u002f\u002f \u2705 FIX\u003a Timeout\u0027u track et
                    trackTimeout\u0028setTimeout\u0028\u0028\u0029 \u003d\u003e videoElement.play\u0028\u0029.catch\u0028\u0028\u0029 \u003d\u003e \u007b\u007d\u0029\u002c 200\u0029\u0029\u003b
                \u007d
                videoElement.playbackRate \u003d 1.0\u003b
            \u007d else if \u0028drift \u003c\u003d TIER2_THRESHOLD\u0029 \u007b
                if \u0028videoElement.paused\u0029 \u007b
                    videoElement.play\u0028\u0029.catch\u0028\u0028\u0029 \u003d\u003e \u007b\u007d\u0029\u003b
                \u007d
                const behind \u003d currentTime \u003c expectedTime\u003b
                videoElement.playbackRate \u003d behind \u003f TIER2_LAGGING_SPEED \u003a 0.95\u003b
            \u007d else if \u0028drift \u003c\u003d TIER3_THRESHOLD\u0029 \u007b
                if \u0028videoElement.paused\u0029 \u007b
                    videoElement.play\u0028\u0029.catch\u0028\u0028\u0029 \u003d\u003e \u007b\u007d\u0029\u003b
                \u007d
                const behind \u003d currentTime \u003c expectedTime\u003b
                videoElement.playbackRate \u003d behind \u003f TIER3_LAGGING_SPEED \u003a 0.90\u003b
            \u007d else if \u0028drift \u003c\u003d 3000\u0029 \u007b
                \u002f\u002f 1.5-3 saniye aras\u0131 drift
                if \u0028videoElement.paused\u0029 \u007b
                    videoElement.play\u0028\u0029.catch\u0028\u0028\u0029 \u003d\u003e \u007b\u007d\u0029\u003b
                \u007d
                const behind \u003d currentTime \u003c expectedTime\u003b
                videoElement.playbackRate \u003d behind \u003f 1.25 \u003a 0.85\u003b
            \u007d else if \u0028drift \u003c\u003d LARGE_DRIFT_THRESHOLD\u0029 \u007b
                \u002f\u002f 3-9 saniye aras\u0131 drift - daha agresif playbackRate
                if \u0028videoElement.paused\u0029 \u007b
                    videoElement.play\u0028\u0029.catch\u0028\u0028\u0029 \u003d\u003e \u007b\u007d\u0029\u003b
                \u007d
                const behind \u003d currentTime \u003c expectedTime\u003b
                videoElement.playbackRate \u003d behind \u003f 1.5 \u003a 0.75\u003b
            \u007d else \u007b
                \u002f\u002f Large drift \u00289\u002b seconds\u0029 - Hard seek with throttle
                const now \u003d Date.now\u0028\u0029\u003b
                if \u0028now - lastHardSeekTime \u003c HARD_SEEK_MIN_INTERVAL \u007c\u007c isHardSeeking\u0029 \u007b
                    debugLog\u0028\u0060Hard seek throttled or in progress\u002c using playbackRate\u0060\u0029\u003b
                    if \u0028videoElement.paused\u0029 \u007b
                        videoElement.play\u0028\u0029.catch\u0028\u0028\u0029 \u003d\u003e \u007b\u007d\u0029\u003b
                    \u007d
                    const behind \u003d currentTime \u003c expectedTime\u003b
                    videoElement.playbackRate \u003d behind \u003f 1.75 \u003a 0.65\u003b \u002f\u002f \u2705 FIX\u003a Daha agresif
                    return\u003b
                \u007d

                debugLog\u0028\u0060Large drift detected\u002c \u0024\u007bdrift\u007dms - initiating buffer-wait\u0060\u0029\u003b
                isBuffering \u003d true\u003b
                isHardSeeking \u003d true\u003b \u002f\u002f \u2705 FIX\u003a Hard seek ba\u015fl\u0131yor
                lastHardSeekTime \u003d now\u003b

                const BUFFER_ADVANCE \u003d 9\u003b \u002f\u002f \u2705 FIX\u003a 7 -\u003e 9 saniye
                const targetSeek \u003d expectedTime - BUFFER_ADVANCE\u003b
                const clampedTarget \u003d Math.max\u00280\u002c Math.min\u0028duration\u002c targetSeek\u0029\u0029\u003b

                videoElement.pause\u0028\u0029\u003b
                
                \u002f\u002f \u2705 FIX\u003a seeked event ile isHardSeeking\u0027i temizle
                const onHardSeeked \u003d \u0028\u0029 \u003d\u003e \u007b
                    videoElement.removeEventListener\u0028\u0027seeked\u0027\u002c onHardSeeked\u0029\u003b
                    isHardSeeking \u003d false\u003b
                    debugLog\u0028\u0027\u2705 Hard seek completed \u0028syncVideo\u0029\u0027\u0029\u003b
                \u007d\u003b
                videoElement.addEventListener\u0028\u0027seeked\u0027\u002c onHardSeeked\u0029\u003b
                
                videoElement.currentTime \u003d clampedTarget\u003b
                lastSyncedPosition \u003d clampedTarget\u003b
                bufferTargetTime \u003d Date.now\u0028\u0029 \u002b \u0028BUFFER_ADVANCE \u002a 1000\u0029\u003b
                
                \u002f\u002f \u2705 FIX\u003a Timeout fallback - seeked event gelmezse temizle - TRACKED
                trackTimeout\u0028setTimeout\u0028\u0028\u0029 \u003d\u003e \u007b
                    if \u0028isHardSeeking\u0029 \u007b
                        videoElement.removeEventListener\u0028\u0027seeked\u0027\u002c onHardSeeked\u0029\u003b
                        isHardSeeking \u003d false\u003b
                        debugLog\u0028\u0027\u26a0\ufe0f Hard seek timeout \u0028syncVideo\u0029\u0027\u0029\u003b
                    \u007d
                \u007d\u002c 3000\u0029\u0029\u003b

                \u002f\u002f \u2705 INTERVAL FIX\u003a DOM element\u0027i d\u00f6ng\u00fc d\u0131\u015f\u0131nda cache\u0027le
                const countdownEl \u003d getCachedElement\u0028\u0027buffer-countdown\u0027\u0029\u003b
                if \u0028countdownEl\u0029 countdownEl.style.display \u003d \u0027block\u0027\u003b

                \u002f\u002f \u2705 FIX \u002311\u003a Mevcut interval\u0027\u0131 temizle
                if \u0028bufferCountdownInterval\u0029 \u007b
                    clearInterval\u0028bufferCountdownInterval\u0029\u003b
                    bufferCountdownInterval \u003d null\u003b
                \u007d

                bufferCountdownInterval \u003d setInterval\u0028\u0028\u0029 \u003d\u003e \u007b
                    const remaining \u003d Math.max\u00280\u002c bufferTargetTime - Date.now\u0028\u0029\u0029\u003b
                    const seconds \u003d Math.ceil\u0028remaining \u002f 1000\u0029\u003b

                    \u002f\u002f \u2705 countdownEl d\u00f6ng\u00fc d\u0131\u015f\u0131nda cache\u0027lendi
                    if \u0028countdownEl\u0029 \u007b
                        countdownEl.textContent \u003d \u0060\u0024\u007bseconds\u007ds\u0060\u003b
                    \u007d

                    if \u0028remaining \u003c\u003d 0\u0029 \u007b
                        clearInterval\u0028bufferCountdownInterval\u0029\u003b
                        bufferCountdownInterval \u003d null\u003b
                        isBuffering \u003d false\u003b

                        if \u0028countdownEl\u0029 countdownEl.style.display \u003d \u0027none\u0027\u003b

                        if \u0028currentRoomData.videoState \u0026\u0026 currentRoomData.videoState.isPlaying\u0029 \u007b
                            videoElement.play\u0028\u0029.catch\u0028\u0028\u0029 \u003d\u003e \u007b\u007d\u0029\u003b
                            videoElement.playbackRate \u003d 1.0\u003b
                            debugLog\u0028\u0060Buffer complete - auto-started\u0060\u0029\u003b
                        \u007d
                    \u007d
                \u007d\u002c 100\u0029\u003b
            \u007d
        \u007d
