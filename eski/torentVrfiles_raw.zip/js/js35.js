

        function listenVideoState\u0028\u0029 \u007b
            const ref \u003d db.ref\u0028\u0060rooms\u002f\u0024\u007bcurrentRoomId\u007d\u002fvideoState\u0060\u0029\u003b
            trackListener\u0028ref\u0029\u003b

            ref.on\u0028\u0027value\u0027\u002c snapshot \u003d\u003e \u007b
                const newState \u003d snapshot.val\u0028\u0029\u003b
                if \u0028\u0021newState\u0029 return\u003b

                if \u0028syncModeActive\u0029 \u007b
                    debugLog\u0028\u0027Ignoring video state update - sync mode active\u0027\u0029\u003b
                    return\u003b
                \u007d

                if \u0028lastCommandSource \u003d\u003d\u003d \u0027self\u0027\u0029 \u007b
                    debugLog\u0028\u0027Ignoring self-triggered video state update\u0027\u0029\u003b
                    return\u003b
                \u007d

                const oldState \u003d previousVideoState\u003b

                if \u0028oldState \u0026\u0026
                    oldState.isPlaying \u003d\u003d\u003d newState.isPlaying \u0026\u0026
                    Math.abs\u0028oldState.currentTime - newState.currentTime\u0029 \u003c 0.1 \u0026\u0026
                    oldState.startTimestamp \u003d\u003d\u003d newState.startTimestamp\u0029 \u007b
                    return\u003b
                \u007d

                \u002f\u002f \u2705 FIX\u003a JSON.parse\u002fstringify yerine shallow copy \u0028daha h\u0131zl\u0131\u0029
                previousVideoState \u003d \u007b
                    isPlaying\u003a newState.isPlaying\u002c
                    currentTime\u003a newState.currentTime\u002c
                    startTimestamp\u003a newState.startTimestamp\u002c
                    lastUpdate\u003a newState.lastUpdate
                \u007d\u003b
                currentRoomData.videoState \u003d newState\u003b

                if \u0028\u0021isRoomOwner\u0029 \u007b
                    const now \u003d Date.now\u0028\u0029\u003b

                    if \u0028oldState \u0026\u0026 oldState.isPlaying \u0026\u0026 \u0021newState.isPlaying\u0029 \u007b
                        debugLog\u0028\u0027Pause command detected - syncing immediately \u0028bypass throttle\u0029\u0027\u0029\u003b
                        lastVideoStateUpdate \u003d now\u003b
                        syncVideo\u0028\u0029\u003b
                        return\u003b
                    \u007d

                    if \u0028now - lastVideoStateUpdate \u003c SYNCCHECKINTERVAL\u0029 return\u003b

                    lastVideoStateUpdate \u003d now\u003b
                    syncVideo\u0028\u0029\u003b
                \u007d
            \u007d\u0029\u003b
        \u007d
