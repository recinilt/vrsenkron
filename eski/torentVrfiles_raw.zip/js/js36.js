

        function sendKeyframe\u0028\u0029 \u007b
            \u002f\u002f \u2705 FIX\u003a isHardSeeking kontrol\u00fc eklendi
            if \u0028\u0021videoElement \u007c\u007c \u0021isRoomOwner \u007c\u007c isSeeking \u007c\u007c isHardSeeking\u0029 return\u003b

            try \u007b
                const ref \u003d db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId \u002b \u0027\u002fkeyframes\u0027\u0029.push\u0028\u007b
                    time\u003a videoElement.currentTime\u002c
                    timestamp\u003a firebase.database.ServerValue.TIMESTAMP
                \u007d\u0029\u003b

                trackTimeout\u0028setTimeout\u0028\u0028\u0029 \u003d\u003e ref.remove\u0028\u0029.catch\u0028\u0028\u0029 \u003d\u003e \u007b\u007d\u0029\u002c 30000\u0029\u0029\u003b
            \u007d catch \u0028error\u0029 \u007b
                console.warn\u0028\u0027Keyframe send error\u003a\u0027\u002c error\u0029\u003b
            \u007d
        \u007d
