
        
        function listenKeyframes\u0028\u0029 \u007b
            const ref \u003d db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId \u002b \u0027\u002fkeyframes\u0027\u0029.limitToLast\u00281\u0029\u003b
            trackListener\u0028ref\u0029\u003b

            ref.on\u0028\u0027child_added\u0027\u002c snapshot \u003d\u003e \u007b
                const keyframe \u003d snapshot.val\u0028\u0029\u003b
                if \u0028\u0021videoElement\u0029 return\u003b

                \u002f\u002f \u2705 FIX\u003a isHardSeeking kontrol\u00fc eklendi
                if \u0028syncState \u007c\u007c isBuffering \u007c\u007c isSeeking \u007c\u007c isHardSeeking\u0029 return\u003b

                const drift \u003d Math.abs\u0028videoElement.currentTime - keyframe.time\u0029 \u002a 1000\u003b

                if \u0028drift \u003e LARGE_DRIFT_THRESHOLD\u0029 \u007b
                    if \u0028isSeeking \u007c\u007c isHardSeeking\u0029 return\u003b \u002f\u002f \u2705 FIX\u003a \u00c7ift kontrol

                    const now \u003d Date.now\u0028\u0029\u003b
                    if \u0028now - lastHardSeekTime \u003e HARD_SEEK_MIN_INTERVAL\u0029 \u007b
                        isHardSeeking \u003d true\u003b \u002f\u002f \u2705 FIX\u003a Hard seek ba\u015fl\u0131yor
                        lastHardSeekTime \u003d now\u003b
                        
                        \u002f\u002f \u2705 FIX\u003a seeked event ile isHardSeeking\u0027i temizle
                        const onKeyframeSeeked \u003d \u0028\u0029 \u003d\u003e \u007b
                            videoElement.removeEventListener\u0028\u0027seeked\u0027\u002c onKeyframeSeeked\u0029\u003b
                            isHardSeeking \u003d false\u003b
                            debugLog\u0028\u0027\u2705 Keyframe seek completed\u0027\u0029\u003b
                        \u007d\u003b
                        videoElement.addEventListener\u0028\u0027seeked\u0027\u002c onKeyframeSeeked\u0029\u003b
                        
                        videoElement.currentTime \u003d keyframe.time\u003b
                        lastSyncedPosition \u003d keyframe.time\u003b
                        debugLog\u0028\u0027\ud83d\udd01 Keyframe sync\u0027\u002c keyframe.time\u0029\u003b
                        
                        \u002f\u002f \u2705 FIX\u003a Timeout fallback - TRACKED
                        trackTimeout\u0028setTimeout\u0028\u0028\u0029 \u003d\u003e \u007b
                            if \u0028isHardSeeking\u0029 \u007b
                                videoElement.removeEventListener\u0028\u0027seeked\u0027\u002c onKeyframeSeeked\u0029\u003b
                                isHardSeeking \u003d false\u003b
                                debugLog\u0028\u0027\u26a0\ufe0f Keyframe seek timeout\u0027\u0029\u003b
                            \u007d
                        \u007d\u002c 3000\u0029\u0029\u003b
                    \u007d
                \u007d
            \u007d\u0029\u003b
        \u007d
