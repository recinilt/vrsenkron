
        
        function trackDrift\u0028\u0029 \u007b
            \u002f\u002f \u2705 FIX\u003a isHardSeeking kontrol\u00fc eklendi
            if \u0028\u0021videoElement \u007c\u007c \u0021currentRoomData \u007c\u007c \u0021currentRoomData.videoState \u007c\u007c isSeeking \u007c\u007c isHardSeeking\u0029 return\u003b

            try \u007b
                const state \u003d currentRoomData.videoState\u003b
                const serverTime \u003d getServerTime\u0028\u0029\u003b
                const expectedTime \u003d state.isPlaying 
                    \u003f state.currentTime \u002b \u0028serverTime - state.startTimestamp\u0029 \u002f 1000 
                    \u003a state.currentTime\u003b

                const drift \u003d \u0028videoElement.currentTime - expectedTime\u0029 \u002a 1000\u003b

                if \u0028lastDriftValue \u003d\u003d\u003d null \u007c\u007c Math.abs\u0028drift - lastDriftValue\u0029 \u003e 1000\u0029 \u007b
                    if \u0028shouldUpdateFirebase\u0028\u0029\u0029 \u007b
                        queueFirebaseUpdate\u0028\u0027activeViewers\u002f\u0027 \u002b currentUser.uid \u002b \u0027\u002fcurrentDrift\u0027\u002c drift\u0029\u003b
                    \u007d
                    lastDriftValue \u003d drift\u003b
                \u007d
            \u007d catch \u0028error\u0029 \u007b
                console.warn\u0028\u0027Drift tracking error\u003a\u0027\u002c error\u0029\u003b
            \u007d
        \u007d

        
        function updatePresence\u0028\u0029 \u007b
            if \u0028\u0021currentUser \u007c\u007c \u0021currentRoomId\u0029 return\u003b
            
            try \u007b
                queueFirebaseUpdate\u0028
                    \u0027activeViewers\u002f\u0027 \u002b currentUser.uid \u002b \u0027\u002flastSeen\u0027\u002c
                    firebase.database.ServerValue.TIMESTAMP
                \u0029\u003b
            \u007d catch \u0028error\u0029 \u007b
                console.warn\u0028\u0027Presence update error\u003a\u0027\u002c error\u0029\u003b
            \u007d
        \u007d
