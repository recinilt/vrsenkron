        
        function checkOwnerPresence\u0028\u0029 \u007b
            if \u0028\u0021isRoomOwner \u0026\u0026 currentRoomData \u0026\u0026 currentUser\u0029 \u007b
                db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId \u002b \u0027\u002factiveViewers\u002f\u0027 \u002b currentRoomData.owner\u0029.once\u0028\u0027value\u0027\u0029
                    .then\u0028snapshot \u003d\u003e \u007b
                        const ownerData \u003d snapshot.val\u0028\u0029\u003b
                        if \u0028\u0021ownerData \u007c\u007c \u0028Date.now\u0028\u0029 - ownerData.lastSeen \u003e OWNER_PRESENCE_TIMEOUT\u0029\u0029 \u007b
                            db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId \u002b \u0027\u002factiveViewers\u0027\u0029.once\u0028\u0027value\u0027\u0029
                                .then\u0028viewersSnapshot \u003d\u003e \u007b
                                    const viewers \u003d viewersSnapshot.val\u0028\u0029\u003b
                                    if \u0028viewers\u0029 \u007b
                                        const newOwner \u003d Object.keys\u0028viewers\u0029\u005b0\u005d\u003b
                                        if \u0028newOwner \u003d\u003d\u003d currentUser.uid\u0029 \u007b
                                            db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId\u0029.update\u0028\u007b owner\u003a newOwner \u007d\u0029\u003b
                                            isRoomOwner \u003d true\u003b
                                            debugLog\u0028\u0027\ud83d\udc51 Ownership transferred to you\u0027\u0029\u003b
                                        \u007d
                                    \u007d
                                \u007d\u0029\u003b
                        \u007d
                    \u007d\u0029
                    .catch\u0028\u0028\u0029 \u003d\u003e \u007b\u007d\u0029\u003b
            \u007d
        \u007d
        
        \u002f\u002f \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d UI UPDATES \u0028DEBOUNCED\u0029 \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d
        function updateRoomInfoDisplay\u0028\u0029 \u007b
            if \u0028\u0021currentRoomData\u0029 return\u003b
            getCachedElement\u0028\u0027room-name-display\u0027\u0029.textContent \u003d currentRoomData.name \u002b \u0028isRoomOwner \u003f \u0027 \ud83d\udc51\u0027 \u003a \u0027\u0027\u0029\u003b
            updateViewerCount\u0028\u0029\u003b
        \u007d
        
        \u002f\u002f \u2705 FIX \u002312\u003a DOM thrashing azaltma - queueRAF kullan
        function updateViewerCount\u0028\u0029 \u007b
            if \u0028\u0021currentRoomId \u007c\u007c \u0021shouldUpdateUI\u0028\u0029\u0029 return\u003b
            
            db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId \u002b \u0027\u002factiveViewers\u0027\u0029.once\u0028\u0027value\u0027\u0029
                .then\u0028snapshot \u003d\u003e \u007b
                    const count \u003d snapshot.numChildren\u0028\u0029\u003b
                    queueRAF\u0028\u0028\u0029 \u003d\u003e \u007b
                        const viewerElement \u003d getCachedElement\u0028\u0027viewer-count\u0027\u0029\u003b
                        if \u0028viewerElement\u0029 \u007b
                            viewerElement.textContent \u003d \u0060\ud83d\udc65 \u0024\u007bcount\u007d izleyici\u0060\u003b
                        \u007d
                    \u007d\u0029\u003b
                \u007d\u0029
                .catch\u0028\u0028\u0029 \u003d\u003e \u007b\u007d\u0029\u003b
        \u007d
