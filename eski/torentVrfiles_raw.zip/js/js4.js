
function applyDashCap\u0028\u0029 \u007b
    if \u0028\u0021dashInstance\u0029 return\u003b

    let list \u003d \u005b\u005d\u003b
    try \u007b
        list \u003d dashInstance.getBitrateInfoListFor\u0028\u0027video\u0027\u0029 \u007c\u007c \u005b\u005d\u003b
    \u007d catch \u0028e\u0029 \u007b
        list \u003d \u005b\u005d\u003b
    \u007d
    if \u0028\u0021list.length\u0029 return\u003b

    const kbpsValues \u003d list.map\u0028i \u003d\u003e normalizeKbps\u0028i.bitrate\u0029\u0029.filter\u0028v \u003d\u003e v \u0021\u003d\u003d null\u0029\u003b
    if \u0028\u0021kbpsValues.length\u0029 return\u003b

    const minKbps \u003d Math.min\u0028...kbpsValues\u0029\u003b

    const candidates \u003d list
        .filter\u0028i \u003d\u003e \u0028i.height \u007c\u007c 0\u0029 \u003e 0 \u0026\u0026 i.height \u003c\u003d abrMaxHeightCap\u0029
        .map\u0028i \u003d\u003e normalizeKbps\u0028i.bitrate\u0029\u0029
        .filter\u0028v \u003d\u003e v \u0021\u003d\u003d null\u0029\u003b

    const maxKbps \u003d candidates.length \u003f Math.max\u0028...candidates\u0029 \u003a minKbps\u003b

    \u002f\u002f Start low\u002c keep min low\u002c cap max to selected threshold
    dashInstance.updateSettings\u0028\u007b
        streaming\u003a \u007b
            abr\u003a \u007b
                initialBitrate\u003a \u007b audio\u003a -1\u002c video\u003a minKbps \u007d\u002c
                minBitrate\u003a \u007b audio\u003a -1\u002c video\u003a minKbps \u007d\u002c
                maxBitrate\u003a \u007b audio\u003a -1\u002c video\u003a maxKbps \u007d
            \u007d\u002c
            buffer\u003a \u007b
                fastSwitchEnabled\u003a true
            \u007d
        \u007d
    \u007d\u0029\u003b
\u007d
