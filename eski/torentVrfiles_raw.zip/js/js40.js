        
        function cleanupOldData\u0028\u0029 \u007b
            if \u0028\u0021currentRoomId \u007c\u007c \u0021isRoomOwner\u0029 return\u003b
            
            try \u007b
                const cutoffTime \u003d Date.now\u0028\u0029 - 60000\u003b
                
                db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId \u002b \u0027\u002fkeyframes\u0027\u0029.once\u0028\u0027value\u0027\u0029
                    .then\u0028snapshot \u003d\u003e \u007b
                        if \u0028snapshot.exists\u0028\u0029\u0029 \u007b
                            snapshot.forEach\u0028child \u003d\u003e \u007b
                                const data \u003d child.val\u0028\u0029\u003b
                                if \u0028data.timestamp \u0026\u0026 data.timestamp \u003c cutoffTime\u0029 \u007b
                                    child.ref.remove\u0028\u0029.catch\u0028\u0028\u0029 \u003d\u003e \u007b\u007d\u0029\u003b
                                \u007d
                            \u007d\u0029\u003b
                        \u007d
                    \u007d\u0029
                    .catch\u0028\u0028\u0029 \u003d\u003e \u007b\u007d\u0029\u003b
                
                db.ref\u0028\u0027rooms\u002f\u0027 \u002b currentRoomId \u002b \u0027\u002factiveViewers\u0027\u0029.once\u0028\u0027value\u0027\u0029
                    .then\u0028snapshot \u003d\u003e \u007b
                        if \u0028snapshot.exists\u0028\u0029\u0029 \u007b
                            snapshot.forEach\u0028child \u003d\u003e \u007b
                                const viewer \u003d child.val\u0028\u0029\u003b
                                if \u0028viewer.lastSeen \u0026\u0026 \u0028Date.now\u0028\u0029 - viewer.lastSeen \u003e 60000\u0029\u0029 \u007b
                                    child.ref.remove\u0028\u0029.catch\u0028\u0028\u0029 \u003d\u003e \u007b\u007d\u0029\u003b
                                \u007d
                            \u007d\u0029\u003b
                        \u007d
                    \u007d\u0029
                    .catch\u0028\u0028\u0029 \u003d\u003e \u007b\u007d\u0029\u003b
                
                debugLog\u0028\u0027\ud83e\uddf9 Cleanup old data\u0027\u0029\u003b
            \u007d catch \u0028error\u0029 \u007b
                console.warn\u0028\u0027Cleanup error\u003a\u0027\u002c error\u0029\u003b
            \u007d
        \u007d
        
        \u002f\u002f \u2705 FIX \u002312\u003a updateSyncStatus - queueRAF ile DOM thrashing \u00f6nle
        function updateSyncStatus\u0028drift\u0029 \u007b
            if \u0028\u0021shouldUpdateUI\u0028\u0029\u0029 return\u003b
            
            queueRAF\u0028\u0028\u0029 \u003d\u003e \u007b
                const statusText \u003d getCachedElement\u0028\u0027sync-text\u0027\u0029\u003b
                if \u0028\u0021statusText\u0029 return\u003b
                
                if \u0028drift \u003c TIER1_THRESHOLD\u0029 \u007b
                    statusText.textContent \u003d \u0027\u2705 Senkronize\u0027\u003b
                    statusText.className \u003d \u0027status-good\u0027\u003b
                \u007d else if \u0028drift \u003c TIER2_THRESHOLD\u0029 \u007b
                    statusText.textContent \u003d \u0027\u26a0\ufe0f Hafif sapma\u0027\u003b
                    statusText.className \u003d \u0027status-warning\u0027\u003b
                \u007d else \u007b
                    statusText.textContent \u003d \u0027\u274c Senkronizasyon kayb\u0131\u0027\u003b
                    statusText.className \u003d \u0027status-error\u0027\u003b
                \u007d
            \u007d\u0029\u003b
        \u007d
        
        \u002f\u002f \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d PERIODIC TASKS \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d
        function startPeriodicTasks\u0028\u0029 \u007b
            trackInterval\u0028setInterval\u0028initClockSync\u002c CLOCK_SYNC_INTERVAL\u0029\u0029\u003b
            trackInterval\u0028setInterval\u0028trackDrift\u002c DRIFT_UPDATE_INTERVAL\u0029\u0029\u003b
            trackInterval\u0028setInterval\u0028updatePresence\u002c PRESENCE_UPDATE_INTERVAL\u0029\u0029\u003b
            trackInterval\u0028setInterval\u0028updateViewerCount\u002c 10000\u0029\u0029\u003b
            trackInterval\u0028setInterval\u0028updateViewerPosition\u002c 5000\u0029\u0029\u003b
            
            if \u0028\u0021isRoomOwner\u0029 \u007b
                trackInterval\u0028setInterval\u0028checkOwnerPresence\u002c 30000\u0029\u0029\u003b
            \u007d
            
            debugLog\u0028\u0027\u2705 Periodic tasks started\u0027\u0029\u003b
        \u007d
        
        \u002f\u002f \u2705 FIX\u003a Owner interval ID\u0027lerini ayr\u0131 track et \u0028birikim \u00f6nleme\u0029
        let ownerKeyframeInterval \u003d null\u003b
        let ownerCleanupInterval \u003d null\u003b
        
        function clearOwnerTasks\u0028\u0029 \u007b
            if \u0028ownerKeyframeInterval\u0029 \u007b
                clearInterval\u0028ownerKeyframeInterval\u0029\u003b
                ownerKeyframeInterval \u003d null\u003b
            \u007d
            if \u0028ownerCleanupInterval\u0029 \u007b
                clearInterval\u0028ownerCleanupInterval\u0029\u003b
                ownerCleanupInterval \u003d null\u003b
            \u007d
            debugLog\u0028\u0027\ud83e\uddf9 Owner tasks cleared\u0027\u0029\u003b
        \u007d
        
        function startOwnerTasks\u0028\u0029 \u007b
            \u002f\u002f \u2705 FIX\u003a \u00d6nce mevcut owner interval\u0027lar\u0131n\u0131 temizle \u0028birikim \u00f6nleme\u0029
            clearOwnerTasks\u0028\u0029\u003b
            
            ownerKeyframeInterval \u003d setInterval\u0028sendKeyframe\u002c KEYFRAME_INTERVAL\u0029\u003b
            ownerCleanupInterval \u003d setInterval\u0028cleanupOldData\u002c 30000\u0029\u003b
            
            trackInterval\u0028ownerKeyframeInterval\u0029\u003b
            trackInterval\u0028ownerCleanupInterval\u0029\u003b
            
            debugLog\u0028\u0027\ud83d\udc51 Owner tasks started\u0027\u0029\u003b
        \u007d
        

\u002f\u002f DOMContentLoaded\u0027dan \u00d6NCE\u002c script i\u00e7inde ekle\u003a
\u002f\u002f \u2705 FIX\u003a video-texture-fix art\u0131k throttled - her frame yerine 100ms\u0027de bir
AFRAME.registerComponent\u0028\u0027video-texture-fix\u0027\u002c \u007b
    schema\u003a \u007b type\u003a \u0027selector\u0027 \u007d\u002c
    init\u003a function \u0028\u0029 \u007b
        this.videoEl \u003d this.data\u003b
        this.material \u003d null\u003b
        this.lastUpdate \u003d 0\u003b
        this.updateInterval \u003d 100\u003b \u002f\u002f ms - 10 FPS yeterli texture update i\u00e7in
    \u007d\u002c
    tick\u003a function \u0028time\u0029 \u007b
        if \u0028\u0021this.videoEl\u0029 return\u003b
        
        \u002f\u002f Throttle\u003a sadece 100ms\u0027de bir g\u00fcncelle
        if \u0028time - this.lastUpdate \u003c this.updateInterval\u0029 return\u003b
        this.lastUpdate \u003d time\u003b
        
        \u002f\u002f readyState \u003e\u003d 2 means HAVE_CURRENT_DATA or higher
        \u002f\u002f Sadece video oynat\u0131l\u0131yorken g\u00fcncelle
        if \u0028this.videoEl.readyState \u003e\u003d 2 \u0026\u0026 \u0021this.videoEl.paused\u0029 \u007b
            if \u0028\u0021this.material\u0029 \u007b
                const mesh \u003d this.el.getObject3D\u0028\u0027mesh\u0027\u0029\u003b
                if \u0028mesh \u0026\u0026 mesh.material\u0029 \u007b
                    this.material \u003d mesh.material\u003b
                \u007d
            \u007d
            
            if \u0028this.material \u0026\u0026 this.material.map\u0029 \u007b
                this.material.map.needsUpdate \u003d true\u003b
            \u007d
        \u007d
    \u007d
\u007d\u0029\u003b


        \u002f\u002f \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d INIT \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d
        document.addEventListener\u0028\u0027DOMContentLoaded\u0027\u002c \u0028\u0029 \u003d\u003e \u007b
            console.log\u0028\u0027\ud83c\udfac VR Cinema ULTRA - Optimized v3.7 \u0028P2P WebTorrent Support\u0029\u0027\u0029\u003b
            updateQualityCapUI\u0028\u0029\u003b
            setupFileInput\u0028\u0029\u003b \u002f\u002f P2P dosya se\u00e7im event\u0027lerini kur
            
            const scene \u003d document.querySelector\u0028\u0027a-scene\u0027\u0029\u003b
            if \u0028scene\u0029 \u007b
                \u002f\u002f \u2705 FIX\u003a Listener\u0027lar\u0131 referansla kaydet \u0028cleanup i\u00e7in\u0029
                sceneEnterVRHandler \u003d \u0028\u0029 \u003d\u003e \u007b
                    const cursor \u003d getCachedElement\u0028\u0027vr-cursor\u0027\u0029\u003b
                    if \u0028cursor\u0029 \u007b
                        cursor.setAttribute\u0028\u0027visible\u0027\u002c \u0027true\u0027\u0029\u003b
                        debugLog\u0028\u0027\ud83d\udc53 VR mode\u003a Raycaster enabled\u0027\u0029\u003b
                    \u007d
                \u007d\u003b
                
                sceneExitVRHandler \u003d \u0028\u0029 \u003d\u003e \u007b
                    const cursor \u003d getCachedElement\u0028\u0027vr-cursor\u0027\u0029\u003b
                    if \u0028cursor\u0029 \u007b
                        cursor.setAttribute\u0028\u0027visible\u0027\u002c \u0027false\u0027\u0029\u003b
                        debugLog\u0028\u0027\ud83d\udc53 VR mode exit\u003a Raycaster disabled\u0027\u0029\u003b
                    \u007d
                \u007d\u003b
                
                scene.addEventListener\u0028\u0027enter-vr\u0027\u002c sceneEnterVRHandler\u0029\u003b
                scene.addEventListener\u0028\u0027exit-vr\u0027\u002c sceneExitVRHandler\u0029\u003b
            \u007d
            
            \u002f\u002f \u2705 FIX\u003a Keyboard listener\u0027\u0131 referansla kaydet \u0028cleanup i\u00e7in\u0029
            keydownHandler \u003d \u0028e\u0029 \u003d\u003e \u007b
                if \u0028\u0021currentRoomId \u007c\u007c \u0021isRoomOwner\u0029 return\u003b
                
                switch\u0028e.key\u0029 \u007b
                    case \u0027 \u0027\u003a
                        e.preventDefault\u0028\u0029\u003b
                        if \u0028videoElement \u0026\u0026 videoElement.paused\u0029 \u007b
                            playVideo\u0028\u0029\u003b
                        \u007d else \u007b
                            pauseVideo\u0028\u0029\u003b
                        \u007d
                        break\u003b
                    case \u0027ArrowLeft\u0027\u003a
                        e.preventDefault\u0028\u0029\u003b
                        seekBackward\u0028\u0029\u003b
                        break\u003b
                    case \u0027ArrowRight\u0027\u003a
                        e.preventDefault\u0028\u0029\u003b
                        seekForward\u0028\u0029\u003b
                        break\u003b
                \u007d
            \u007d\u003b
            
            document.addEventListener\u0028\u0027keydown\u0027\u002c keydownHandler\u0029\u003b
        \u007d\u0029\u003b
        
        \u002f\u002f Cleanup on page unload
        window.addEventListener\u0028\u0027beforeunload\u0027\u002c \u0028\u0029 \u003d\u003e \u007b
            fullCleanup\u0028\u0029\u003b
        \u007d\u0029\u003b
