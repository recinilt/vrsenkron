
function setupAdaptiveSource\u0028url\u0029 \u007b
    if \u0028\u0021videoElement\u0029 return\u003b

    destroyAdaptiveStreaming\u0028\u0029\u003b

    const type \u003d getStreamType\u0028url\u0029\u003b

    if \u0028type \u003d\u003d\u003d \u0027hls\u0027\u0029 \u007b
        if \u0028window.Hls \u0026\u0026 Hls.isSupported\u0028\u0029\u0029 \u007b
            hlsInstance \u003d new Hls\u0028\u007b
                startLevel\u003a 0\u002c \u002f\u002f start from lowest
                minAutoBitrate\u003a 0\u002c \u002f\u002f allow lowest
                abrEwmaDefaultEstimate\u003a 150000\u002c \u002f\u002f very low initial estimate \u0028bps\u0029
                abrBandWidthFactor\u003a 0.9\u002c \u002f\u002f \u2705 FIX\u003a 0.8 -\u003e 0.9 \u0028kalite d\u00fc\u015f\u00fcrme i\u00e7in daha muhafazakar\u0029
                abrBandWidthUpFactor\u003a 0.6 \u002f\u002f \u2705 FIX\u003a 0.7 -\u003e 0.6 \u0028yukar\u0131 ge\u00e7i\u015fte daha dikkatli\u0029
            \u007d\u0029\u003b

            hlsInstance.on\u0028Hls.Events.MANIFEST_PARSED\u002c \u0028\u0029 \u003d\u003e \u007b
                applyHlsCap\u0028\u0029\u003b
                updateQualityCapUI\u0028\u0029\u003b
            \u007d\u0029\u003b

            hlsInstance.attachMedia\u0028videoElement\u0029\u003b
            hlsInstance.loadSource\u0028url\u0029\u003b
            return\u003b
        \u007d

        \u002f\u002f Safari \u002f native HLS support
        videoElement.src \u003d url\u003b
        updateQualityCapUI\u0028\u0029\u003b
        return\u003b
    \u007d

    if \u0028type \u003d\u003d\u003d \u0027dash\u0027\u0029 \u007b
        if \u0028window.dashjs \u0026\u0026 dashjs.MediaPlayer\u0029 \u007b
            dashInstance \u003d dashjs.MediaPlayer\u0028\u0029.create\u0028\u0029\u003b

            dashInstance.updateSettings\u0028\u007b
                streaming\u003a \u007b
                    abr\u003a \u007b
                        initialBitrate\u003a \u007b audio\u003a -1\u002c video\u003a 150 \u007d\u002c \u002f\u002f kbps
                        minBitrate\u003a \u007b audio\u003a -1\u002c video\u003a 100 \u007d\u002c
                        maxBitrate\u003a \u007b audio\u003a -1\u002c video\u003a 2500 \u007d \u002f\u002f will be recalculated on init
                    \u007d\u002c
                    buffer\u003a \u007b
                        fastSwitchEnabled\u003a true
                    \u007d
                \u007d
            \u007d\u0029\u003b

            dashInstance.on\u0028dashjs.MediaPlayer.events.STREAM_INITIALIZED\u002c \u0028\u0029 \u003d\u003e \u007b
                applyDashCap\u0028\u0029\u003b
                updateQualityCapUI\u0028\u0029\u003b
            \u007d\u0029\u003b

            dashInstance.initialize\u0028videoElement\u002c url\u002c false\u0029\u003b
            return\u003b
        \u007d

        videoElement.src \u003d url\u003b
        updateQualityCapUI\u0028\u0029\u003b
        return\u003b
    \u007d

    \u002f\u002f Native progressive \u0028mp4\u002fwebm\u002fetc.\u0029
    videoElement.src \u003d url\u003b
    updateQualityCapUI\u0028\u0029\u003b
\u007d
