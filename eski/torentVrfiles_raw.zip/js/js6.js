
        function setCommandSourceSelf\u0028\u0029 \u007b
            if \u0028commandSourceTimeoutId\u0029 \u007b
                clearTimeout\u0028commandSourceTimeoutId\u0029\u003b
            \u007d
            lastCommandSource \u003d \u0027self\u0027\u003b
            commandSourceTimeoutId \u003d setTimeout\u0028\u0028\u0029 \u003d\u003e \u007b
                lastCommandSource \u003d null\u003b
                commandSourceTimeoutId \u003d null\u003b
            \u007d\u002c 2000\u0029\u003b
        \u007d

        function updateVideoState\u0028updates\u0029 \u007b
            if \u0028videoStateUpdateDebounce\u0029 \u007b
                clearTimeout\u0028videoStateUpdateDebounce\u0029\u003b
            \u007d
            
            videoStateUpdateDebounce \u003d setTimeout\u0028\u0028\u0029 \u003d\u003e \u007b
                setCommandSourceSelf\u0028\u0029\u003b
                db.ref\u0028\u0060rooms\u002f\u0024\u007bcurrentRoomId\u007d\u002fvideoState\u0060\u0029.update\u0028updates\u0029\u003b
                videoStateUpdateDebounce \u003d null\u003b
            \u007d\u002c 200\u0029\u003b
        \u007d


function seekBackward\u0028\u0029 \u007b
    if \u0028\u0021isRoomOwner \u007c\u007c \u0021videoElement\u0029 return\u003b

    pendingSeekAmount -\u003d 10\u003b

    if \u0028seekDebounceTimer\u0029 \u007b
        clearTimeout\u0028seekDebounceTimer\u0029\u003b
    \u007d

    seekDebounceTimer \u003d setTimeout\u0028\u0028\u0029 \u003d\u003e \u007b
        executeSeek\u0028\u0027backward\u0027\u002c pendingSeekAmount\u0029\u003b
        seekDebounceTimer \u003d null\u003b
        pendingSeekAmount \u003d 0\u003b
    \u007d\u002c 500\u0029\u003b
\u007d

function seekForward\u0028\u0029 \u007b
    if \u0028\u0021isRoomOwner \u007c\u007c \u0021videoElement\u0029 return\u003b

    pendingSeekAmount \u002b\u003d 10\u003b

    if \u0028seekDebounceTimer\u0029 \u007b
        clearTimeout\u0028seekDebounceTimer\u0029\u003b
    \u007d

    seekDebounceTimer \u003d setTimeout\u0028\u0028\u0029 \u003d\u003e \u007b
        executeSeek\u0028\u0027forward\u0027\u002c pendingSeekAmount\u0029\u003b
        seekDebounceTimer \u003d null\u003b
        pendingSeekAmount \u003d 0\u003b
    \u007d\u002c 500\u0029\u003b
\u007d
