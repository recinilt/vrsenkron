
function executeSeek\u0028direction\u002c totalAmount\u0029 \u007b
    if \u0028\u0021videoElement \u007c\u007c isSeeking\u0029 return\u003b

    if \u0028videoElement.readyState \u003c 1\u0029 \u007b
        console.warn\u0028\u0027Video metadata not loaded yet\u0027\u0029\u003b
        return\u003b
    \u007d

    isSeeking \u003d true\u003b

    const targetTime \u003d Math.max\u00280\u002c Math.min\u0028videoElement.duration \u007c\u007c Infinity\u002c videoElement.currentTime \u002b totalAmount\u0029\u0029\u003b

    lastCommandSource \u003d \u0027self\u0027\u003b
    videoElement.pause\u0028\u0029\u003b

    let seekCompleted \u003d false\u003b

    const onSeeked \u003d \u0028\u0029 \u003d\u003e \u007b
        if \u0028seekCompleted\u0029 return\u003b
        seekCompleted \u003d true\u003b
        videoElement.removeEventListener\u0028\u0027seeked\u0027\u002c onSeeked\u0029\u003b

        const newPos \u003d videoElement.currentTime\u003b
        const updates \u003d \u007b
            \u0027videoState\u002fisPlaying\u0027\u003a false\u002c
            \u0027videoState\u002fcurrentTime\u0027\u003a newPos\u002c
            \u0027videoState\u002fstartTimestamp\u0027\u003a getServerTime\u0028\u0029\u002c
            \u0027videoState\u002flastUpdate\u0027\u003a firebase.database.ServerValue.TIMESTAMP\u002c
            \u0027keyframes\u0027\u003a null\u002c
            \u0027syncState\u0027\u003a null
        \u007d\u003b

        db.ref\u0028\u0060rooms\u002f\u0024\u007bcurrentRoomId\u007d\u0060\u0029.update\u0028updates\u0029
            .then\u0028\u0028\u0029 \u003d\u003e \u007b
                debugLog\u0028\u0060Seek \u0024\u007bdirection\u007d complete\u002c paused at\u0060\u002c newPos\u0029\u003b
                isSeeking \u003d false\u003b
            \u007d\u0029
            .catch\u0028err \u003d\u003e \u007b
                console.warn\u0028\u0027Seek update error\u003a\u0027\u002c err\u0029\u003b
                isSeeking \u003d false\u003b
            \u007d\u0029\u003b

        \u002f\u002f \u2705 FIX\u003a Timeout\u0027u track et
        trackTimeout\u0028setTimeout\u0028\u0028\u0029 \u003d\u003e \u007b lastCommandSource \u003d null\u003b \u007d\u002c 2500\u0029\u0029\u003b
    \u007d\u003b

    videoElement.addEventListener\u0028\u0027seeked\u0027\u002c onSeeked\u0029\u003b
    videoElement.currentTime \u003d targetTime\u003b

    \u002f\u002f \u2705 FIX\u003a Timeout\u0027u track et
    trackTimeout\u0028setTimeout\u0028\u0028\u0029 \u003d\u003e \u007b
        if \u0028\u0021seekCompleted\u0029 \u007b
            isSeeking \u003d false\u003b
            debugLog\u0028\u0027Seek timeout - forcing completion\u0027\u0029\u003b
            onSeeked\u0028\u0029\u003b
        \u007d
    \u007d\u002c 2000\u0029\u0029\u003b
\u007d



        \u002f\u002f \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d FIREBASE INIT \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d
        firebase.initializeApp\u0028firebaseConfig\u0029\u003b
        db \u003d firebase.database\u0028\u0029\u003b
        auth \u003d firebase.auth\u0028\u0029\u003b
        
        \u002f\u002f \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d HELPER FUNCTIONS \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d
        function debugLog\u0028...args\u0029 \u007b
            if \u0028DEBUG_MODE\u0029 console.log\u0028...args\u0029\u003b
        \u007d
        

        \u002f\u002f requestAnimationFrame queue limiter
        let rafQueue \u003d \u005b\u005d\u003b
        let rafScheduled \u003d false\u003b
