        
        function queueRAF\u0028callback\u0029 \u007b
            rafQueue.push\u0028callback\u0029\u003b
            if \u0028\u0021rafScheduled\u0029 \u007b
                rafScheduled \u003d true\u003b
                requestAnimationFrame\u0028\u0028\u0029 \u003d\u003e \u007b
                    const callbacks \u003d rafQueue.splice\u00280\u0029\u003b
                    rafScheduled \u003d false\u003b
                    callbacks.forEach\u0028cb \u003d\u003e \u007b
                        try \u007b cb\u0028\u0029\u003b \u007d catch\u0028e\u0029 \u007b console.warn\u0028\u0027RAF callback error\u003a\u0027\u002c e\u0029\u003b \u007d
                    \u007d\u0029\u003b
                \u007d\u0029\u003b
            \u007d
        \u007d
        
        
        function getServerTime\u0028\u0029 \u007b
            return Date.now\u0028\u0029 \u002b clockOffset\u003b
        \u007d
        
        \u002f\u002f DOM Element Caching
        function getCachedElement\u0028id\u0029 \u007b
            if \u0028\u0021cachedElements\u005bid\u005d\u0029 \u007b
                cachedElements\u005bid\u005d \u003d document.getElementById\u0028id\u0029\u003b
            \u007d
            return cachedElements\u005bid\u005d\u003b
        \u007d
        
        function clearElementCache\u0028\u0029 \u007b
            cachedElements \u003d \u007b\u007d\u003b
        \u007d
        
        \u002f\u002f \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d MEMORY LEAK PREVENTION \u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d\u003d
        function trackInterval\u0028id\u0029 \u007b
            if \u0028id\u0029 activeIntervals.push\u0028id\u0029\u003b
            return id\u003b
        \u007d
        
        function trackTimeout\u0028id\u0029 \u007b
            if \u0028id\u0029 activeTimeouts.push\u0028id\u0029\u003b
            return id\u003b
        \u007d
        
        function trackListener\u0028ref\u0029 \u007b
            if \u0028ref\u0029 firebaseListeners.push\u0028ref\u0029\u003b
            return ref\u003b
        \u007d
        
        \u002f\u002f \u2705 FIX \u00237 \u0026 \u002311\u003a T\u00fcm interval\u0027lar\u0131 temizle
        function clearAllIntervals\u0028\u0029 \u007b
            \u002f\u002f Buffer countdown temizle
            if \u0028bufferCountdownInterval\u0029 \u007b
                clearInterval\u0028bufferCountdownInterval\u0029\u003b
                bufferCountdownInterval \u003d null\u003b
            \u007d
            
            \u002f\u002f Countdown interval temizle
            if \u0028countdownInterval\u0029 \u007b
                clearInterval\u0028countdownInterval\u0029\u003b
                countdownInterval \u003d null\u003b
            \u007d
            
            \u002f\u002f Seek debounce timer temizle
            if \u0028seekDebounceTimer\u0029 \u007b
                clearTimeout\u0028seekDebounceTimer\u0029\u003b
                seekDebounceTimer \u003d null\u003b
            \u007d
            
            \u002f\u002f P2P update interval temizle
            if \u0028p2pUpdateInterval\u0029 \u007b
                clearInterval\u0028p2pUpdateInterval\u0029\u003b
                p2pUpdateInterval \u003d null\u003b
            \u007d
            
            activeIntervals.forEach\u0028id \u003d\u003e clearInterval\u0028id\u0029\u0029\u003b
            activeIntervals.length \u003d 0\u003b
        \u007d
