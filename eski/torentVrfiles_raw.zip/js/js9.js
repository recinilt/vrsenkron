        
        function clearAllTimeouts\u0028\u0029 \u007b
            \u002f\u002f Sync timeout temizle
            if \u0028syncTimeoutId\u0029 \u007b
                clearTimeout\u0028syncTimeoutId\u0029\u003b
                syncTimeoutId \u003d null\u003b
            \u007d
            
            \u002f\u002f Command source timeout temizle
            if \u0028commandSourceTimeoutId\u0029 \u007b
                clearTimeout\u0028commandSourceTimeoutId\u0029\u003b
                commandSourceTimeoutId \u003d null\u003b
            \u007d
            
            \u002f\u002f Video state update debounce temizle
            if \u0028videoStateUpdateDebounce\u0029 \u007b
                clearTimeout\u0028videoStateUpdateDebounce\u0029\u003b
                videoStateUpdateDebounce \u003d null\u003b
            \u007d
            
            \u002f\u002f Firebase batch timeout temizle
            if \u0028firebaseBatchTimeout\u0029 \u007b
                clearTimeout\u0028firebaseBatchTimeout\u0029\u003b
                firebaseBatchTimeout \u003d null\u003b
            \u007d
            
            activeTimeouts.forEach\u0028id \u003d\u003e clearTimeout\u0028id\u0029\u0029\u003b
            activeTimeouts.length \u003d 0\u003b
        \u007d
        
        function clearAllListeners\u0028\u0029 \u007b
            firebaseListeners.forEach\u0028ref \u003d\u003e \u007b
                try \u007b
                    ref.off\u0028\u0029\u003b
                \u007d catch \u0028e\u0029 \u007b
                    console.warn\u0028\u0027Listener cleanup error\u003a\u0027\u002c e\u0029\u003b
                \u007d
            \u007d\u0029\u003b
            firebaseListeners.length \u003d 0\u003b
        \u007d
        
        \u002f\u002f \u2705 FIX \u00231\u003a Video listener\u0027lar\u0131n\u0131 temizle \u0028ayr\u0131 fonksiyon\u0029
        function clearVideoListeners\u0028\u0029 \u007b
            if \u0028\u0021videoElement\u0029 return\u003b
            
            if \u0028videoElement._listeners \u0026\u0026 videoElement._listeners.length \u003e 0\u0029 \u007b
                videoElement._listeners.forEach\u0028\u0028\u007b event\u002c handler \u007d\u0029 \u003d\u003e \u007b
                    videoElement.removeEventListener\u0028event\u002c handler\u0029\u003b
                \u007d\u0029\u003b
                videoElement._listeners \u003d \u005b\u005d\u003b
                debugLog\u0028\u0027\ud83e\uddf9 Video listeners cleared\u003a\u0027\u002c videoElement._listeners.length\u0029\u003b
            \u007d
            
            \u002f\u002f Legacy cleanup
            if \u0028videoElement._eventListeners\u0029 \u007b
                videoElement._eventListeners.forEach\u0028\u0028\u005bevent\u002c listener\u005d\u0029 \u003d\u003e \u007b
                    videoElement.removeEventListener\u0028event\u002c listener\u0029\u003b
                \u007d\u0029\u003b
                videoElement._eventListeners \u003d \u005b\u005d\u003b
            \u007d
        \u007d
