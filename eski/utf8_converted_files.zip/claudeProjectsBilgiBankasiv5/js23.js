        
        function showCreateRoom() {
            getCachedElement('room-list-section').classList.add('hidden');
            getCachedElement('create-room-section').classList.remove('hidden');
        }
