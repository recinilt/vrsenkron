// ============================================
// VR UI PANEL SİSTEMİ (TAMAMEN SOLDA - EKRANDAN UZAK)
// ============================================

function createVRUIPanel() {
    const scene = document.querySelector('a-scene');
    
    // Eski paneli temizle
    const oldPanel = document.getElementById('vr-ui-panel');
    if (oldPanel) {
        oldPanel.parentNode.removeChild(oldPanel);
    }
    
    // ✅ TAMAMEN SOLDA (Ekrandan uzak, başı çevirince görünür)
    vrUIPanel = document.createElement('a-entity');
    vrUIPanel.id = 'vr-ui-panel';
    
    // ✅ Pozisyon: X=-6 (çok solda), Y=1.6 (göz hizası), Z=-3 (hafif arkada)
    vrUIPanel.setAttribute('position', '-6 1.6 -3');
    
    // ✅ Rotasyon: 45° sağa (kullanıcıya dönük ama tamamen solda)
    vrUIPanel.setAttribute('rotation', '0 45 0');
    
    // Panel arka plan
    const panelBg = document.createElement('a-plane');
    panelBg.setAttribute('width', '1.2');
    panelBg.setAttribute('height', '1.8');
    panelBg.setAttribute('color', '#1a1a2e');
    panelBg.setAttribute('opacity', '0.95');
    panelBg.setAttribute('shader', 'flat');
    panelBg.setAttribute('data-raycastable', '');
    vrUIPanel.appendChild(panelBg);
    
    // Başlık
    const title = document.createElement('a-text');
    title.setAttribute('value', 'KONTROLLER');
    title.setAttribute('align', 'center');
    title.setAttribute('width', '1.8');
    title.setAttribute('color', '#00d9ff');
    title.setAttribute('position', '0 0.75 0.01');
    title.setAttribute('font', 'roboto');
    vrUIPanel.appendChild(title);
    
    // OYNAT/DURAKLAT
    const playBtn = document.createElement('a-plane');
    playBtn.setAttribute('id', 'vr-play-btn');
    playBtn.setAttribute('width', '1');
    playBtn.setAttribute('height', '0.15');
    playBtn.setAttribute('color', '#00ff88');
    playBtn.setAttribute('position', '0 0.5 0.01');
    playBtn.setAttribute('class', 'clickable');
    playBtn.setAttribute('data-raycastable', '');
    
    const playIcon = document.createElement('a-text');
    playIcon.setAttribute('id', 'vr-play-icon');
    playIcon.setAttribute('value', '▶️ OYNAT');
    playIcon.setAttribute('align', 'center');
    playIcon.setAttribute('width', '1.6');
    playIcon.setAttribute('color', '#000000');
    playIcon.setAttribute('position', '0 0 0.01');
    playBtn.appendChild(playIcon);
    
    playBtn.addEventListener('click', () => {
        togglePlayPause();
        setTimeout(() => {
            const icon = document.getElementById('vr-play-icon');
            if (icon && videoElement) {
                icon.setAttribute('value', videoElement.paused ? '▶️ OYNAT' : '⏸️ DURAKLAT');
            }
        }, 100);
    });
    
    vrUIPanel.appendChild(playBtn);
    
    // GERİ BUTONU
    const rewindBtn = document.createElement('a-plane');
    rewindBtn.setAttribute('width', '0.45');
    rewindBtn.setAttribute('height', '0.15');
    rewindBtn.setAttribute('color', '#ff6b6b');
    rewindBtn.setAttribute('position', '-0.25 0.3 0.01');
    rewindBtn.setAttribute('class', 'clickable');
    rewindBtn.setAttribute('data-raycastable', '');
    
    const rewindText = document.createElement('a-text');
    rewindText.setAttribute('value', '◀ 10s');
    rewindText.setAttribute('align', 'center');
    rewindText.setAttribute('width', '1.4');
    rewindText.setAttribute('color', '#000000');
    rewindText.setAttribute('position', '0 0 0.01');
    rewindBtn.appendChild(rewindText);
    
    rewindBtn.addEventListener('click', () => {
        seekVideo(-10);
    });
    
    vrUIPanel.appendChild(rewindBtn);
    
    // İLERİ BUTONU
    const forwardBtn = document.createElement('a-plane');
    forwardBtn.setAttribute('width', '0.45');
    forwardBtn.setAttribute('height', '0.15');
    forwardBtn.setAttribute('color', '#4ecdc4');
    forwardBtn.setAttribute('position', '0.25 0.3 0.01');
    forwardBtn.setAttribute('class', 'clickable');
    forwardBtn.setAttribute('data-raycastable', '');
    
    const forwardText = document.createElement('a-text');
    forwardText.setAttribute('value', '10s ▶');
    forwardText.setAttribute('align', 'center');
    forwardText.setAttribute('width', '1.4');
    forwardText.setAttribute('color', '#000000');
    forwardText.setAttribute('position', '0 0 0.01');
    forwardBtn.appendChild(forwardText);
    
    forwardBtn.addEventListener('click', () => {
        seekVideo(10);
    });
    
    vrUIPanel.appendChild(forwardBtn);
    
    // SEEK BAR
    vrSeekBar = document.createElement('a-plane');
    vrSeekBar.setAttribute('width', '1');
    vrSeekBar.setAttribute('height', '0.05');
    vrSeekBar.setAttribute('color', '#555555');
    vrSeekBar.setAttribute('position', '0 0.1 0.01');
    vrSeekBar.setAttribute('class', 'clickable');
    vrSeekBar.setAttribute('data-raycastable', '');
    
    const seekProgress = document.createElement('a-plane');
    seekProgress.id = 'vr-seek-progress';
    seekProgress.setAttribute('width', '0');
    seekProgress.setAttribute('height', '0.05');
    seekProgress.setAttribute('color', '#00ff88');
    seekProgress.setAttribute('position', '-0.5 0 0.01');
    vrSeekBar.appendChild(seekProgress);
    
    vrSeekBar.addEventListener('click', (evt) => {
        if (!videoElement) return;
        
        const intersection = evt.detail.intersection;
        if (!intersection) return;
        
        const localPoint = intersection.point;
        const seekBarEl = vrSeekBar.object3D;
        
        seekBarEl.worldToLocal(localPoint);
        
        const relativeX = localPoint.x;
        const seekBarWidth = 1;
        const percentage = (relativeX + seekBarWidth / 2) / seekBarWidth;
        
        console.log('🎯 Seek bar tıklandı:', {
            relativeX: relativeX.toFixed(2),
            percentage: (percentage * 100).toFixed(1) + '%'
        });
        
        seekToPosition(percentage);
    });
    
    vrUIPanel.appendChild(vrSeekBar);
    
    // Zaman göstergesi
    const timeDisplay = document.createElement('a-text');
    timeDisplay.id = 'vr-time-display';
    timeDisplay.setAttribute('value', '0:00 / 0:00');
    timeDisplay.setAttribute('align', 'center');
    timeDisplay.setAttribute('width', '1.6');
    timeDisplay.setAttribute('color', '#ffffff');
    timeDisplay.setAttribute('position', '0 -0.05 0.01');
    vrUIPanel.appendChild(timeDisplay);
    
    // EKRAN POZİSYONU BAŞLIK
    const screenTitle = document.createElement('a-text');
    screenTitle.setAttribute('value', 'EKRAN');
    screenTitle.setAttribute('align', 'center');
    screenTitle.setAttribute('width', '1.5');
    screenTitle.setAttribute('color', '#00d9ff');
    screenTitle.setAttribute('position', '0 -0.25 0.01');
    vrUIPanel.appendChild(screenTitle);
    
    // YUKARI BUTONU (▲)
    const upBtn = document.createElement('a-plane');
    upBtn.setAttribute('width', '0.25');
    upBtn.setAttribute('height', '0.12');
    upBtn.setAttribute('color', '#ffd93d');
    upBtn.setAttribute('position', '0 -0.38 0.01');
    upBtn.setAttribute('class', 'clickable');
    upBtn.setAttribute('data-raycastable', '');
    
    const upTriangle = document.createElement('a-triangle');
    upTriangle.setAttribute('vertex-a', '0 0.04 0');
    upTriangle.setAttribute('vertex-b', '-0.04 -0.02 0');
    upTriangle.setAttribute('vertex-c', '0.04 -0.02 0');
    upTriangle.setAttribute('color', '#000000');
    upTriangle.setAttribute('position', '0 0 0.01');
    upBtn.appendChild(upTriangle);
    
    upBtn.addEventListener('click', () => {
        moveScreen('up');
    });
    
    vrUIPanel.appendChild(upBtn);
    
    // SOL BUTONU (◀)
    const leftBtn = document.createElement('a-plane');
    leftBtn.setAttribute('width', '0.12');
    leftBtn.setAttribute('height', '0.12');
    leftBtn.setAttribute('color', '#ffd93d');
    leftBtn.setAttribute('position', '-0.17 -0.53 0.01');
    leftBtn.setAttribute('class', 'clickable');
    leftBtn.setAttribute('data-raycastable', '');
    
    const leftTriangle = document.createElement('a-triangle');
    leftTriangle.setAttribute('vertex-a', '-0.04 0 0');
    leftTriangle.setAttribute('vertex-b', '0.02 0.04 0');
    leftTriangle.setAttribute('vertex-c', '0.02 -0.04 0');
    leftTriangle.setAttribute('color', '#000000');
    leftTriangle.setAttribute('position', '0 0 0.01');
    leftBtn.appendChild(leftTriangle);
    
    leftBtn.addEventListener('click', () => {
        moveScreen('left');
    });
    
    vrUIPanel.appendChild(leftBtn);
    
    // AŞAĞI BUTONU (▼)
    const downBtn = document.createElement('a-plane');
    downBtn.setAttribute('width', '0.25');
    downBtn.setAttribute('height', '0.12');
    downBtn.setAttribute('color', '#ffd93d');
    downBtn.setAttribute('position', '0 -0.53 0.01');
    downBtn.setAttribute('class', 'clickable');
    downBtn.setAttribute('data-raycastable', '');
    
    const downTriangle = document.createElement('a-triangle');
    downTriangle.setAttribute('vertex-a', '0 -0.04 0');
    downTriangle.setAttribute('vertex-b', '-0.04 0.02 0');
    downTriangle.setAttribute('vertex-c', '0.04 0.02 0');
    downTriangle.setAttribute('color', '#000000');
    downTriangle.setAttribute('position', '0 0 0.01');
    downBtn.appendChild(downTriangle);
    
    downBtn.addEventListener('click', () => {
        moveScreen('down');
    });
    
    vrUIPanel.appendChild(downBtn);
    
    // SAĞ BUTONU (▶)
    const rightBtn = document.createElement('a-plane');
    rightBtn.setAttribute('width', '0.12');
    rightBtn.setAttribute('height', '0.12');
    rightBtn.setAttribute('color', '#ffd93d');
    rightBtn.setAttribute('position', '0.17 -0.53 0.01');
    rightBtn.setAttribute('class', 'clickable');
    rightBtn.setAttribute('data-raycastable', '');
    
    const rightTriangle = document.createElement('a-triangle');
    rightTriangle.setAttribute('vertex-a', '0.04 0 0');
    rightTriangle.setAttribute('vertex-b', '-0.02 0.04 0');
    rightTriangle.setAttribute('vertex-c', '-0.02 -0.04 0');
    rightTriangle.setAttribute('color', '#000000');
    rightTriangle.setAttribute('position', '0 0 0.01');
    rightBtn.appendChild(rightTriangle);
    
    rightBtn.addEventListener('click', () => {
        moveScreen('right');
    });
    
    vrUIPanel.appendChild(rightBtn);
    
    // SIFIRLA BUTONU
    const resetBtn = document.createElement('a-plane');
    resetBtn.setAttribute('width', '0.35');
    resetBtn.setAttribute('height', '0.1');
    resetBtn.setAttribute('color', '#ff6b6b');
    resetBtn.setAttribute('position', '0.325 -0.38 0.01');
    resetBtn.setAttribute('class', 'clickable');
    resetBtn.setAttribute('data-raycastable', '');
    
    const resetText = document.createElement('a-text');
    resetText.setAttribute('value', '↺ SIFIRLA');
    resetText.setAttribute('align', 'center');
    resetText.setAttribute('width', '1');
    resetText.setAttribute('color', '#000000');
    resetText.setAttribute('position', '0 0 0.01');
    resetBtn.appendChild(resetText);
    
    resetBtn.addEventListener('click', () => {
        moveScreen('reset');
    });
    
    vrUIPanel.appendChild(resetBtn);
    
    // ✅ SAHNEYE EKLE (Tamamen solda, ekrandan uzak)
    scene.appendChild(vrUIPanel);
    
    // Seek bar update interval
    if (vrSeekBarInterval) {
        clearInterval(vrSeekBarInterval);
    }
    
    vrSeekBarInterval = setInterval(() => {
        if (videoElement && videoElement.duration) {
            const progress = (videoElement.currentTime / videoElement.duration);
            const progressWidth = progress;
            
            const seekProgress = document.getElementById('vr-seek-progress');
            if (seekProgress) {
                seekProgress.setAttribute('width', progressWidth);
                seekProgress.setAttribute('position', `${-0.5 + progressWidth / 2} 0 0.01`);
            }
            
            const timeDisplay = document.getElementById('vr-time-display');
            if (timeDisplay) {
                const current = formatTime(videoElement.currentTime);
                const total = formatTime(videoElement.duration);
                timeDisplay.setAttribute('value', `${current} / ${total}`);
            }
            
            const playIcon = document.getElementById('vr-play-icon');
            if (playIcon && videoElement) {
                playIcon.setAttribute('value', videoElement.paused ? '▶️ OYNAT' : '⏸️ DURAKLAT');
            }
        }
    }, 1000);
    
    console.log('✅ VR UI Panel oluşturuldu (TAMAMEN SOLDA - Başı çevirince görünür)');
    console.log('   → Pozisyon: X=-6 (çok solda), Y=1.6 (göz hizası), Z=-3 (hafif arkada)');
    console.log('   → Rotasyon: 45° (kullanıcıya dönük)');
    console.log('   → OK şekilleri eklendi (▲▼◀▶)');
    console.log('   → Normal bakışta GÖRÜNMEZ, başı sola çevirince görünür');
}

function moveScreen(direction) {
    const screen = document.getElementById('video-screen');
    if (!screen) return;
    
    const step = 0.5;
    
    switch(direction) {
        case 'up':
            screenPosition.y += step;
            break;
        case 'down':
            screenPosition.y -= step;
            break;
        case 'left':
            screenPosition.x -= step;
            break;
        case 'right':
            screenPosition.x += step;
            break;
        case 'forward':
            screenPosition.z += step;
            break;
        case 'backward':
            screenPosition.z -= step;
            break;
        case 'reset':
            screenPosition = { x: 0, y: 2, z: -10 };
            break;
    }
    
    screen.setAttribute('position', screenPosition);
    console.log('✅ Ekran pozisyonu:', screenPosition);
}

console.log('✅ VR UI Panel sistemi yüklendi (TAMAMEN SOLDA)');
console.log('   → Seek bar interval cleanup eklendi');
console.log('   → Panel tamamen solda (normal bakışta görünmez)');
console.log('   → Başı sola çevirince görünür');
console.log('   → Ok şekilleri ile yön kontrolü');
console.log('   → Dinamik play/pause ikonu');