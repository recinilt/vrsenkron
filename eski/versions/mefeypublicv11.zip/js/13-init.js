// ============================================
// BAŞLATMA VE İNİTİALİZATİON - HEARTBEAT SİSTEMİ
// ============================================

console.log('🎬 VR Sosyal Sinema - Heartbeat + Polling v8.0');
console.log('📍 Yeni Özellikler:');
console.log('   ✅ Heartbeat sistemi (Master - 15s)');
console.log('   ✅ Polling sistemi (Slave - 15s)');
console.log('   ✅ Optimistic updates (anında feedback)');
console.log('   ✅ Drift tolerance (3 saniye)');
console.log('   ✅ Tek sync kaynağı (videoState)');
console.log('   ✅ Firebase trafiği %80 azaltıldı');
console.log('   ✅ Keyframe sistemi kaldırıldı');
console.log('   ✅ Urgent update kaldırıldı');
console.log('   ✅ HLS.js adaptive streaming');
console.log('   ✅ Buffer monitoring');
console.log('⚙️ Özellikler:');
console.log('   • 5 Hafif Sinema Ortamı');
console.log('   • Oda Sahipliği Transferi');
console.log('   • 3 Saniye Tam Senkronizasyon');
console.log('   • Kontrol Modu Seçimi');
console.log('   • Şifreli Oda Desteği');
console.log('   • 4K Video Desteği (HLS)');
console.log('Firebase:', firebase.app().name ? 'Bağlı ✓' : 'Bağlı Değil ✗');

document.addEventListener('DOMContentLoaded', () => {
    console.log('✓ DOM yüklendi');
    
    startClockSync();
    console.log('✓ Clock sync başlatıldı');
    
    uiOverlay = document.getElementById('ui-overlay');
    vrControls = document.getElementById('vr-controls');
    roomInfoDisplay = document.getElementById('room-info-display');
    
    const scene = document.querySelector('a-scene');
    if (scene) {
        scene.addEventListener('loaded', () => {
            console.log('✓ VR sahnesi yüklendi');
        });
        
        scene.addEventListener('enter-vr', () => {
            console.log('✓ VR moduna girildi');
            hideVRControls();
        });
        
        scene.addEventListener('exit-vr', () => {
            console.log('✓ VR modundan çıkıldı');
            if (currentRoomId) {
                showVRControls();
            }
        });
    }
    
    const roomsListElement = document.getElementById('rooms-list');
    if (roomsListElement) {
        listRooms();
        console.log('✓ Manuel refresh aktif');
    }
    
    document.addEventListener('keydown', (e) => {
        if (!currentRoomId || !videoElement) return;
        
        if (e.code === 'Space' && e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') {
            e.preventDefault();
            togglePlayPause();
        }
        
        if (e.code === 'ArrowRight') {
            e.preventDefault();
            seekVideo(10);
        }
        
        if (e.code === 'ArrowLeft') {
            e.preventDefault();
            seekVideo(-10);
        }
        
        if (e.code === 'ArrowUp') {
            e.preventDefault();
            moveScreen('up');
        }
        
        if (e.code === 'ArrowDown') {
            e.preventDefault();
            moveScreen('down');
        }
        
        if (e.code === 'KeyW') moveScreen('up');
        if (e.code === 'KeyS') moveScreen('down');
        if (e.code === 'KeyA') moveScreen('left');
        if (e.code === 'KeyD') moveScreen('right');
        if (e.code === 'KeyQ') moveScreen('backward');
        if (e.code === 'KeyE') moveScreen('forward');
        
        if (e.code === 'KeyR') {
            moveScreen('reset');
        }
        
        if (e.code === 'KeyM') {
            e.preventDefault();
            videoElement.muted = !videoElement.muted;
            console.log('🔇 Sessiz:', videoElement.muted);
        }
        
        if (e.code === 'KeyF') {
            e.preventDefault();
            const sceneEl = document.querySelector('a-scene');
            if (sceneEl) {
                if (document.fullscreenElement) {
                    document.exitFullscreen();
                } else {
                    sceneEl.requestFullscreen();
                }
            }
        }
        
        if (e.code === 'KeyC') {
            e.preventDefault();
            if (subtitleElement) {
                const isVisible = subtitleElement.getAttribute('visible') === 'true';
                subtitleElement.setAttribute('visible', !isVisible);
                console.log('📝 Altyazı:', !isVisible ? 'Açık' : 'Kapalı');
            }
        }
    });
    
    console.log('✓ Tüm event listener\'lar kuruldu');
    console.log('🎮 Klavye Kısayolları:');
    console.log('   Space: Oynat/Duraklat');
    console.log('   ←/→: 10sn Geri/İleri');
    console.log('   ↑/↓ veya W/S: Ekran Yukarı/Aşağı');
    console.log('   A/D: Ekran Sol/Sağ');
    console.log('   Q/E: Ekran İleri/Geri');
    console.log('   R: Ekran Pozisyonu Sıfırla');
    console.log('   C: Altyazı Aç/Kapa');
    console.log('   M: Sessiz');
    console.log('   F: Tam Ekran');
});

window.addEventListener('beforeunload', () => {
    console.log('👋 Sayfa kapatılıyor, tam temizlik yapılıyor...');
    
    if (clockSyncInterval) {
        clearInterval(clockSyncInterval);
        clockSyncInterval = null;
        console.log('✅ Clock sync interval temizlendi');
    }
    
    cleanupListeners();
    
    // ✅ Heartbeat/Polling temizle
    stopHeartbeat();
    stopPolling();
    
    if (hlsInstance) {
        hlsInstance.destroy();
        hlsInstance = null;
        console.log('✅ HLS instance temizlendi');
    }
    
    if (bufferCheckInterval) {
        clearInterval(bufferCheckInterval);
        bufferCheckInterval = null;
        console.log('✅ Buffer check interval temizlendi');
    }
    
    if (viewerPresenceRef) {
        viewerPresenceRef.off();
        viewerPresenceRef = null;
    }
    
    if (roomRef) {
        roomRef.off();
        roomRef = null;
    }
    
    if (videoElement) {
        videoElement.pause();
        videoElement.src = '';
        videoElement = null;
    }
    
    if (vrSeekBarInterval) {
        clearInterval(vrSeekBarInterval);
        vrSeekBarInterval = null;
        console.log('✅ VR seek bar interval temizlendi');
    }
    
    if (subtitleUpdateInterval) {
        clearInterval(subtitleUpdateInterval);
        subtitleUpdateInterval = null;
        console.log('✅ Subtitle interval temizlendi');
    }
    
    removeSubtitle();
    
    console.log('✅ Tam temizlik tamamlandı');
});

window.addEventListener('error', (e) => {
    console.error('❌ Global hata:', e.message, e.filename, e.lineno);
});

window.addEventListener('unhandledrejection', (e) => {
    console.error('❌ Promise hatası:', e.reason);
});

console.log('✅ Uygulama başlatıldı - Heartbeat + Polling v8.0 - Hazır! 🚀');
console.log('✅ Tüm optimizasyonlar aktif!');
console.log('✅ Firebase trafiği %80 azaltıldı!');
console.log('✅ Heartbeat + Polling sistemi aktif!');