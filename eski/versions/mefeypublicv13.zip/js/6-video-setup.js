// ============================================
// VIDEO KURULUM FONKSIYONLARI - FORCE DOWNLOAD
// ============================================

function setupVideo(videoUrl, screenSize) {
    console.log('🎬 Video ayarlanıyor:', videoUrl);
    
    const originalUrl = videoUrl;
    const processedUrl = getVideoUrl(videoUrl);
    
    if (!processedUrl) {
        showVideoError('invalid', null, originalUrl);
        return;
    }
    
    setupVideoTexture(processedUrl, screenSize, originalUrl);
    
    const scene = document.querySelector('a-scene');
    const environment = scene.querySelector('[environment]');
    
    if (environment) {
        environment.setAttribute('environment', {
            preset: currentEnvironment,
            lighting: 'distant',
            lightPosition: { x: 0, y: 1, z: 0 }
        });
    }
    
    console.log('✓ Ortam değiştirildi:', currentEnvironment);
}

function setupVideoTexture(videoUrl, screenSize, originalUrl) {
    const scene = document.querySelector('a-scene');
    const screen = document.getElementById('video-screen');
    
    if (!screen) {
        console.error('❌ Ekran elementi bulunamadı!');
        return;
    }
    
    const size = {
        'flat': { width: 16, height: 9 },
        '360': { width: 100, height: 100 },
        '180': { width: 50, height: 50 }
    }[screenSize] || { width: 16, height: 9 };
    
    if (screenSize === '360') {
        screen.setAttribute('geometry', {
            primitive: 'sphere',
            radius: 50,
            segmentsWidth: 64,
            segmentsHeight: 64
        });
        screen.setAttribute('material', 'side: back');
        screen.setAttribute('scale', '-1 1 1');
    } else if (screenSize === '180') {
        screen.setAttribute('geometry', {
            primitive: 'sphere',
            radius: 25,
            segmentsWidth: 64,
            segmentsHeight: 32,
            thetaStart: 0,
            thetaLength: 180
        });
        screen.setAttribute('material', 'side: back');
        screen.setAttribute('scale', '-1 1 1');
    } else {
        screen.setAttribute('geometry', {
            primitive: 'plane',
            width: size.width,
            height: size.height
        });
        screen.removeAttribute('scale');
    }
    
    screen.setAttribute('width', size.width);
    screen.setAttribute('height', size.height);
    
    let assets = document.querySelector('a-assets');
    if (!assets) {
        assets = document.createElement('a-assets');
        scene.appendChild(assets);
    }
    
    const oldVideo = document.getElementById('video-src');
    if (oldVideo) {
        oldVideo.pause();
        oldVideo.src = '';
        oldVideo.remove();
    }
    
    if (hlsInstance) {
        hlsInstance.destroy();
        hlsInstance = null;
        console.log('✓ Eski HLS instance temizlendi');
    }
    
    const videoAsset = document.createElement('video');
    videoAsset.id = 'video-src';
    videoAsset.crossOrigin = 'anonymous';
    
    videoAsset.preload = 'auto';
    videoAsset.autoplay = false;
    videoAsset.loop = false;
    videoAsset.playsInline = true;
    videoAsset.muted = true;
    
    videoAsset.setAttribute('webkit-playsinline', 'true');
    videoAsset.setAttribute('playsinline', 'true');
    
    assets.appendChild(videoAsset);
    videoElement = videoAsset;
    
    const isHLS = videoUrl.includes('.m3u8');
    
    if (isHLS && typeof Hls !== 'undefined') {
        if (Hls.isSupported()) {
            console.log('🎬 HLS.js kullanılıyor (Adaptive Streaming)');
            
            hlsInstance = new Hls({
                maxBufferLength: 30,
                maxBufferSize: 60 * 1000 * 1000,
                maxBufferHole: 0.5,
                startLevel: -1,
                abrEwmaDefaultEstimate: 500000,
                manifestLoadingTimeOut: 10000,
                manifestLoadingMaxRetry: 3,
                levelLoadingTimeOut: 10000,
                levelLoadingMaxRetry: 3,
                fragLoadingTimeOut: 20000,
                fragLoadingMaxRetry: 6,
                debug: false
            });
            
            hlsInstance.loadSource(videoUrl);
            hlsInstance.attachMedia(videoElement);
            
            hlsInstance.on(Hls.Events.MANIFEST_PARSED, (event, data) => {
                console.log('✓ HLS manifest yüklendi:', data.levels.length, 'kalite seviyesi');
                data.levels.forEach((level, index) => {
                    console.log(`  → Seviye ${index}: ${level.width}x${level.height} @ ${Math.round(level.bitrate/1000)}kbps`);
                });
            });
            
            hlsInstance.on(Hls.Events.LEVEL_SWITCHED, (event, data) => {
                const level = hlsInstance.levels[data.level];
                console.log('📊 Kalite değişti:', level.width + 'x' + level.height, '@', Math.round(level.bitrate/1000) + 'kbps');
            });
            
            hlsInstance.on(Hls.Events.ERROR, (event, data) => {
                console.error('❌ HLS hatası:', data.type, data.details);
                
                if (data.fatal) {
                    switch (data.type) {
                        case Hls.ErrorTypes.NETWORK_ERROR:
                            console.log('🔄 Network hatası, yeniden deneniyor...');
                            hlsInstance.startLoad();
                            break;
                        case Hls.ErrorTypes.MEDIA_ERROR:
                            console.log('🔄 Media hatası, kurtarılıyor...');
                            hlsInstance.recoverMediaError();
                            break;
                        default:
                            console.error('❌ Kurtarılamaz HLS hatası');
                            hlsInstance.destroy();
                            break;
                    }
                }
            });
            
        } else if (videoElement.canPlayType('application/vnd.apple.mpegurl')) {
            console.log('🎬 Native HLS kullanılıyor (Safari)');
            videoElement.src = videoUrl;
            videoElement.load();
        } else {
            console.error('❌ HLS desteklenmiyor!');
            showVideoError('hls', null, originalUrl);
            return;
        }
    } else {
        console.log('🎬 Standart video kullanılıyor');
        
        if (videoUrl.includes('.ts')) {
            videoAsset.type = 'video/mp2t';
        } else if (videoUrl.includes('.m3u8')) {
            videoAsset.type = 'application/x-mpegURL';
        }
        
        videoElement.src = videoUrl;
        videoElement.load();
    }
    
    screen.setAttribute('visible', 'true');
    console.log('✅ Ekran hemen gösterildi (video yüklenirken)');
    
    videoElement.addEventListener('loadedmetadata', () => {
        console.log('✓ Video metadata yüklendi:', videoElement.duration, 'saniye');
        console.log('✓ Video boyutları:', videoElement.videoWidth, 'x', videoElement.videoHeight);
        forceVideoDownload();
    });
    
    videoElement.addEventListener('loadeddata', () => {
        console.log('✓ Video data yüklendi');
    });
    
    videoElement.addEventListener('canplay', () => {
        console.log('✓ Video oynatmaya hazır');
    });
    
    videoElement.addEventListener('canplaythrough', () => {
        console.log('✓ Video tamamı yüklenebilir');
    });
    
    videoElement.addEventListener('waiting', () => {
        isBuffering = true;
        console.log('🔄 Buffering başladı...');
        showSyncStatus('🔄 Video yükleniyor...');
    });
    
    videoElement.addEventListener('playing', () => {
        if (isBuffering) {
            isBuffering = false;
            console.log('✓ Buffering bitti');
            showSyncStatus('');
        }
    });
    
    videoElement.addEventListener('stalled', () => {
        console.log('⚠️ Video yükleme durdu (stalled)');
    });
    
    videoElement.addEventListener('suspend', () => {
        // ✅ IGNORE - Normal tarayıcı davranışı
    });
    
    videoElement.addEventListener('progress', () => {
        if (videoElement.buffered.length > 0) {
            const bufferedEnd = videoElement.buffered.end(videoElement.buffered.length - 1);
            const duration = videoElement.duration;
            const bufferedPercent = (bufferedEnd / duration * 100).toFixed(1);
            
            const currentTen = Math.floor(bufferedPercent / 10);
            const lastTen = Math.floor((bufferedPercent - 0.1) / 10);
            
            if (currentTen !== lastTen) {
                console.log('📊 Buffer:', bufferedPercent + '%', '(' + bufferedEnd.toFixed(0) + 's / ' + duration.toFixed(0) + 's)');
            }
            
            if (bufferedPercent >= 99.9) {
                console.log('✅ Video tamamen indirildi! (%100)');
            }
        }
    });
    
    videoElement.addEventListener('error', (e) => {
        console.error('❌ Video yükleme hatası:', e);
        console.error('❌ Video element error code:', videoElement.error?.code);
        console.error('❌ Video element error message:', videoElement.error?.message);
        showVideoError('load', e, originalUrl);
    });
    
    if (bufferCheckInterval) {
        clearInterval(bufferCheckInterval);
    }
    
    bufferCheckInterval = setInterval(() => {
        if (!videoElement || videoElement.paused) return;
        
        if (videoElement.buffered.length > 0) {
            const currentTime = videoElement.currentTime;
            const bufferedEnd = videoElement.buffered.end(videoElement.buffered.length - 1);
            const bufferAhead = bufferedEnd - currentTime;
            
            if (bufferAhead < 2) {
                console.log('⚠️ Buffer düşük:', bufferAhead.toFixed(1) + 's');
                
                if (hlsInstance && hlsInstance.currentLevel > 0) {
                    hlsInstance.currentLevel = hlsInstance.currentLevel - 1;
                    console.log('📉 Kalite düşürüldü (buffer düşük)');
                }
            }
        }
    }, 5000);
    
    screen.setAttribute('src', '#video-src');
    
    console.log('✓ Video elementi oluşturuldu:', videoUrl);
    console.log('✓ Buffer monitoring aktif');
    console.log('✓ Force download trick aktif');
}

function forceVideoDownload() {
    if (!videoElement) return;
    
    console.log('🔄 Force download başlatılıyor...');
    
    videoElement.play().then(() => {
        console.log('✅ Force download: Play başarılı');
        
        setTimeout(() => {
            videoElement.pause();
            videoElement.currentTime = 0;
            videoElement.muted = false;
            console.log('✅ Force download tamamlandı (video başa sarıldı, unmuted)');
        }, 100);
        
    }).catch(err => {
        console.log('⚠️ Force download play hatası:', err);
        videoElement.muted = false;
    });
}

function disposeEnvironment() {
    const scene = document.querySelector('a-scene');
    const environment = scene.querySelector('[environment]');
    
    if (environment) {
        environment.parentNode.removeChild(environment);
        console.log('✓ Önceki ortam temizlendi (dispose)');
    }
    
    const newEnv = document.createElement('a-entity');
    newEnv.setAttribute('environment', '');
    scene.appendChild(newEnv);
    
    return newEnv;
}

function showVideoError(type, error, url) {
    const service = detectVideoService(url);
    let message = '❌ <strong>Video Yüklenemedi!</strong><br><br>';
    
    if (type === 'load') {
        message += '<strong>Sebep:</strong><br>';
        message += '• URL yanlış veya erişilemiyor<br>';
        message += '• Video formatı desteklenmiyor<br>';
        message += '• CORS sorunu<br><br>';
    } else if (type === 'hls') {
        message += '<strong>Sebep:</strong><br>';
        message += '• HLS/M3U8 desteği yok<br>';
        message += '• Tarayıcı desteklemiyor<br><br>';
    }
    
    message += '<strong>Çözüm Önerileri:</strong><br>';
    
    if (service === 'unknown' || service === 'cors-proxy') {
        message += '1. <strong>Cloudinary</strong> kullanın (Ücretsiz):<br>';
        message += '   • https://cloudinary.com adresine kaydolun<br>';
        message += '   • Videoyu yükleyin<br>';
        message += '   • URL formatı: res.cloudinary.com/[name]/video/upload/...<br><br>';
        
        message += '2. <strong>Zerostorage.net</strong> kullanın (Ücretsiz):<br>';
        message += '   • https://zerostorage.net adresine gidin<br>';
        message += '   • Videoyu yükleyin<br>';
        message += '   • Embed veya direkt linki kopyalayın<br><br>';
        
        message += '3. <strong>Catbox.moe</strong> kullanın (Ücretsiz):<br>';
        message += '   • https://catbox.moe adresine gidin<br>';
        message += '   • Videoyu yükleyin<br>';
        message += '   • Direkt linki kopyalayın<br><br>';
        
        message += '4. <strong>Bunny.net</strong> kullanın ($1/ay):<br>';
        message += '   • https://bunny.net adresine kaydolun<br>';
        message += '   • Storage Zone oluşturun<br>';
        message += '   • CDN linkini kullanın<br><br>';
        
        message += '5. <strong>Direkt video linki</strong> (.mp4, .webm, .ts, .m3u8)<br>';
        message += '   • Link video formatı ile bitmelidir<br>';
        message += '   • CORS izni olmalıdır<br>';
    } else {
        message += '• Linkin doğru olduğundan emin olun<br>';
        message += '• Başka bir video deneyin<br>';
        message += '• Tarayıcı konsolunu kontrol edin (F12)<br>';
    }
    
    const overlay = document.getElementById('ui-overlay');
    overlay.classList.remove('hidden');
    overlay.querySelector('.ui-container').innerHTML = `
        <h1>🎬 VR Sosyal Sinema</h1>
        <div class="error-box">${message}</div>
        <button onclick="location.reload()">◀ Ana Menüye Dön</button>
    `;
}

console.log('✓ Video kurulum fonksiyonları yüklendi (Force Download)');
console.log('   → HLS.js adaptive streaming');
console.log('   → Buffer monitoring');
console.log('   → Quality auto-switching');
console.log('   → Network error recovery');
console.log('   → Force download trick: Aktif');
console.log('   → Ekran hemen gösterilir');
console.log('   → Suspend event: IGNORE (spam önleme)');