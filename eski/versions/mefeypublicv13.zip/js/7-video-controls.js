// ============================================
// VİDEO KONTROL FONKSİYONLARI - HEARTBEAT SİSTEMİ (FIXED)
// ============================================

let lastSeekTime = 0;
let seekDebounceTimeout = null;
const SEEK_DEBOUNCE_DELAY = 2000;

function canControlVideo() {
    if (!currentRoomData) return false;
    
    if (currentRoomData.controlMode === 'everyone') {
        return true;
    }
    
    return isRoomOwner;
}

// ============================================
// MASTER ACTION (Basitleştirilmiş - Sadece Firebase'e Yaz)
// ============================================

async function masterAction(actionType, actionData) {
    if (!isRoomOwner) {
        console.error('❌ Sadece oda sahibi masterAction çağırabilir!');
        return;
    }
    
    if (actionLock) {
        console.log('⏳ Aksiyon kuyruğa eklendi:', actionType);
        actionQueue = actionQueue.filter(a => a.type !== actionType);
        actionQueue.push({ type: actionType, data: actionData });
        return;
    }
    
    actionLock = true;
    
    try {
        // ✅ Sadece videoState'e yaz (tek kaynak)
        await roomRef.child('videoState').update(actionData);
        console.log('✅ Master aksiyon:', actionType, actionData.currentTime?.toFixed(1) + 's');
        
    } catch (error) {
        console.error('❌ Master aksiyon hatası:', error);
    } finally {
        actionLock = false;
        
        if (actionQueue.length > 0) {
            const nextAction = actionQueue.shift();
            await masterAction(nextAction.type, nextAction.data);
        }
    }
}

// ============================================
// SLAVE ACTION (Optimistic Update + Firebase Request)
// ============================================

function slaveAction(actionType, actionData) {
    if (isRoomOwner) {
        console.error('❌ Oda sahibi slaveAction çağıramaz!');
        return;
    }
    
    console.log('📤 Slave aksiyon:', actionType, actionData.currentTime?.toFixed(1) + 's');
    
    // ✅ Optimistic update (anında feedback)
    applyLocalAction(actionType, actionData);
    
    // Firebase'e request gönder
    roomRef.child('pendingActions').push({
        type: actionType,
        userId: auth.currentUser?.uid,
        timestamp: Date.now(),
        ...actionData
    });
}

// ============================================
// LOCAL ACTION (Optimistic Update)
// ============================================

function applyLocalAction(actionType, actionData) {
    if (!videoElement) return;
    
    switch (actionType) {
        case 'play':
            videoElement.play().catch(err => console.log('Play hatası:', err));
            showSyncStatus('▶️ Oynatılıyor...');
            break;
            
        case 'pause':
            videoElement.pause();
            showSyncStatus('⏸️ Duraklatıldı');
            break;
            
        case 'seek':
            videoElement.currentTime = actionData.currentTime;
            showSyncStatus(`⏩ ${formatTime(actionData.currentTime)}`);
            break;
    }
}

// ============================================
// SEEK (Basitleştirilmiş)
// ============================================

function performSeek(getTargetTime) {
    if (!canControlVideo()) {
        alert('⚠️ Bu odada sadece oda sahibi video kontrolü yapabilir!');
        return;
    }
    
    if (!videoElement) {
        alert('Video henüz yüklenmedi!');
        return;
    }
    
    const now = Date.now();
    
    if (now - lastSeekTime < SEEK_DEBOUNCE_DELAY) {
        clearTimeout(seekDebounceTimeout);
        console.log('⏱️ Seek debounce sıfırlandı');
    }
    
    lastSeekTime = now;
    
    const targetTime = getTargetTime();
    
    // Local update (anında feedback)
    videoElement.currentTime = targetTime;
    console.log(`⏩ Seek: ${targetTime.toFixed(1)}s`);
    showSyncStatus(`⏩ ${formatTime(targetTime)} (2sn bekleniyor...)`);
    
    seekDebounceTimeout = setTimeout(() => {
        const finalTime = videoElement.currentTime;
        const rewindTime = Math.max(0, finalTime - SEEK_REWIND_SECONDS);
        const wasPlaying = !videoElement.paused;
        
        videoElement.pause();
        videoElement.currentTime = rewindTime;
        
        const actionData = {
            isPlaying: wasPlaying,
            currentTime: rewindTime,
            startTimestamp: wasPlaying ? (Date.now() + SYNC_DELAY) : null,
            lastUpdate: Date.now()
        };
        
        if (isRoomOwner) {
            masterAction('seek', actionData);
        } else {
            slaveAction('seek', actionData);
        }
        
        showSyncStatus(wasPlaying ? `⏱️ 3sn sonra ${formatTime(rewindTime)} başlıyor` : '');
    }, SEEK_DEBOUNCE_DELAY);
}

function seekVideo(seconds) {
    performSeek(() => {
        return Math.max(0, Math.min(videoElement.duration, videoElement.currentTime + seconds));
    });
}

function seekToPosition(percentage) {
    performSeek(() => {
        return videoElement.duration * percentage;
    });
}

// ============================================
// PLAY/PAUSE (FIXED - Lokal Play Eklendi)
// ============================================

function togglePlayPause() {
    if (!canControlVideo()) {
        alert('⚠️ Bu odada sadece oda sahibi video kontrolü yapabilir!');
        return;
    }
    
    if (!videoElement) {
        alert('Video henüz yüklenmedi!');
        return;
    }
    
    const willPlay = videoElement.paused;
    
    if (willPlay) {
        // ✅ FIX: Scheduled play için lokal video da oynatılmalı
        const startTimestamp = Date.now() + SYNC_DELAY;
        
        const actionData = {
            isPlaying: true,
            currentTime: videoElement.currentTime,
            startTimestamp: startTimestamp,
            lastUpdate: Date.now()
        };
        
        showSyncStatus('⏱️ 3 saniye sonra başlıyor...');
        console.log('▶️ Play:', videoElement.currentTime.toFixed(1) + 's', '(3sn sonra)');
        
        // ✅ MASTER: Lokal video da oynatılmalı
        if (isRoomOwner) {
            // Firebase'e yaz
            masterAction('play', actionData);
            
            // ✅ Lokal video da oynat (scheduled)
            setTimeout(() => {
                if (videoElement && videoElement.paused) {
                    videoElement.play().then(() => {
                        console.log('✅ Master: Lokal video oynatıldı');
                        showSyncStatus('');
                    }).catch(err => {
                        console.log('❌ Master play hatası:', err);
                    });
                }
            }, SYNC_DELAY);
        } else {
            // Slave: Optimistic update
            slaveAction('play', actionData);
        }
    } else {
        // Pause
        videoElement.pause();
        
        const actionData = {
            isPlaying: false,
            currentTime: videoElement.currentTime,
            startTimestamp: null,
            lastUpdate: Date.now()
        };
        
        console.log('⏸️ Pause:', videoElement.currentTime.toFixed(1) + 's');
        
        if (isRoomOwner) {
            masterAction('pause', actionData);
        } else {
            slaveAction('pause', actionData);
        }
    }
}

function stopVideo() {
    if (!canControlVideo()) {
        alert('⚠️ Bu odada sadece oda sahibi video kontrolü yapabilir!');
        return;
    }
    
    if (!videoElement) {
        alert('Video henüz yüklenmedi!');
        return;
    }
    
    videoElement.pause();
    videoElement.currentTime = 0;
    
    const actionData = {
        isPlaying: false,
        currentTime: 0,
        startTimestamp: null,
        lastUpdate: Date.now()
    };
    
    console.log('⏹ Stop');
    showSyncStatus('⏹ Video başa sarıldı');
    
    if (isRoomOwner) {
        masterAction('stop', actionData);
    } else {
        slaveAction('stop', actionData);
    }
}

function setPlaybackRate(rate) {
    if (!videoElement) {
        alert('Video henüz yüklenmedi!');
        return;
    }
    
    videoElement.playbackRate = rate;
    console.log('🎚️ Oynatma hızı:', rate);
}

function formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}

console.log('✓ Video kontrol fonksiyonları yüklendi (Heartbeat Sistemi - FIXED)');
console.log('   → Basitleştirilmiş: Tek kaynak (videoState)');
console.log('   → Optimistic updates: Aktif');
console.log('   → Master: Direkt Firebase yazma + Lokal play');
console.log('   → Slave: Optimistic + request');
console.log('   → Master lokal play fix: Aktif');