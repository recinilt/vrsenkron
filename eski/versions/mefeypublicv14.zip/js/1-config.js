// ============================================
// YAPILANDIRMA VE SABİTLER - SETTINGS İLE ENTEGRE
// ============================================

// Firebase'i başlat
firebase.initializeApp(firebaseConfig);

// ============================================
// SETTINGS'DEN DEĞERLERİ AL
// ============================================

// Cloudflare Worker Proxy
const CLOUDFLARE_WORKER = getSetting('network.cloudflareWorker');

// Senkronizasyon Sabitleri
const SYNC_DELAY = getSetting('video.syncDelay');
const DRIFT_TOLERANCE = getSetting('video.driftTolerance');
const SEEK_REWIND_SECONDS = getSetting('video.seekRewindSeconds');
const HEARTBEAT_INTERVAL = getSetting('video.heartbeatInterval');
const POLLING_INTERVAL = getSetting('video.pollingInterval');

// Desteklenen Video Formatları
const SUPPORTED_VIDEO_FORMATS = [
    'mp4', 'webm', 'ogg', 'mov', 'avi', 'mkv',
    'm4v', 'flv', '3gp', 'wmv', 'ts', 'm3u8'
];

// Desteklenen Altyazı Formatları
const SUPPORTED_SUBTITLE_FORMATS = [
    'srt', 'vtt', 'ass', 'ssa', 'sub'
];

// Ortam Tanımlamaları
const ENVIRONMENTS = getEnvironments();

// Video Servisi Yapılandırmaları
const VIDEO_SERVICES = {
    youtube: {
        pattern: /(youtu\.be\/|youtube\.com\/(watch\?v=|embed\/|v\/|shorts\/))([\w-]{11})/,
        transform: (match) => {
            const videoId = match[3];
            return `https://www.youtube.com/embed/${videoId}?autoplay=1&controls=1&enablejsapi=1`;
        }
    },
    vimeo: {
        pattern: /vimeo\.com\/(\d+)/,
        transform: (match) => {
            return `https://player.vimeo.com/video/${match[1]}?autoplay=1`;
        }
    },
    dailymotion: {
        pattern: /dailymotion\.com\/video\/([a-zA-Z0-9]+)/,
        transform: (match) => {
            return `https://www.dailymotion.com/embed/video/${match[1]}?autoplay=1`;
        }
    },
    googledrive: {
        pattern: /drive\.google\.com\/(?:file\/d\/|open\?id=|uc\?id=)([a-zA-Z0-9_-]+)/,
        transform: (match) => {
            const fileId = match[1];
            const directUrl = `https://drive.google.com/uc?export=download&id=${fileId}`;
            return `${CLOUDFLARE_WORKER}?url=${encodeURIComponent(directUrl)}`;
        }
    },
    zerostorage: {
        pattern: /zerostorage\.net\/(?:embed\/|file\/)([a-zA-Z0-9-]+)/,
        transform: (match) => {
            const fileId = match[1];
            return `https://zerostorage.net/file/${fileId}`;
        }
    },
    cloudinary: {
        pattern: /res\.cloudinary\.com\/([^\/]+)\/video\/upload\//,
        transform: (url) => {
            return url;
        }
    },
    bunny: {
        pattern: /(bunnycdn|b-cdn)\.net/,
        transform: (url) => url
    },
    catbox: {
        pattern: /catbox\.moe/,
        transform: (url) => url
    }
};

// ============================================
// CLOCK SYNC SİSTEMİ
// ============================================

async function syncClock() {
    const t1 = Date.now();
    
    try {
        await roomsRef.child('_clockSync').set(firebase.database.ServerValue.TIMESTAMP);
        
        const snapshot = await roomsRef.child('_clockSync').once('value');
        const t4 = Date.now();
        const serverTime = snapshot.val();
        
        const roundTrip = t4 - t1;
        const oneWay = roundTrip / 2;
        
        clockOffset = (serverTime + oneWay) - t4;
        
        console.log('⏰ Clock offset:', clockOffset, 'ms (round-trip:', roundTrip, 'ms)');
        
        // Temizle
        await roomsRef.child('_clockSync').remove();
    } catch (error) {
        console.error('❌ Clock sync hatası:', error);
    }
}

function getAdjustedTime() {
    return Date.now() + clockOffset;
}

function startClockSync() {
    // İlk sync
    syncClock();
    
    // Her 30 saniyede bir sync
    if (clockSyncInterval) {
        clearInterval(clockSyncInterval);
    }
    clockSyncInterval = setInterval(syncClock, 30000);
    
    console.log('⏰ Clock sync başlatıldı (her 30 saniye)');
}

console.log('✅ Yapılandırma yüklendi (Settings entegre)');
console.log('✅ Video formatları:', SUPPORTED_VIDEO_FORMATS.length);
console.log('✅ Altyazı formatları:', SUPPORTED_SUBTITLE_FORMATS.length);
console.log('✅ Cloudflare Worker:', CLOUDFLARE_WORKER);
console.log('✅ Heartbeat interval:', HEARTBEAT_INTERVAL, 'ms');
console.log('✅ Polling interval:', POLLING_INTERVAL, 'ms');
console.log('✅ Drift tolerance:', DRIFT_TOLERANCE, 'saniye');
console.log('✅ Sync delay:', SYNC_DELAY, 'ms');
