// ============================================
// VR UI PANEL SİSTEMİ - SETTINGS İLE ENTEGRE (3X DAHA BÜYÜK)
// ============================================

function createVRUIPanel() {
    const scene = document.querySelector('a-scene');
    
    // Eski paneli temizle
    const oldPanel = document.getElementById('vr-ui-panel');
    if (oldPanel) {
        oldPanel.parentNode.removeChild(oldPanel);
    }
    
    // Settings'den ayarları al
    const settings = getVRUISettings();
    const pos = settings.position;
    const rot = settings.rotation;
    const colors = settings.colors;
    
    // Panel oluştur
    vrUIPanel = document.createElement('a-entity');
    vrUIPanel.id = 'vr-ui-panel';
    
    // Pozisyon ve rotasyon (Settings'den)
    vrUIPanel.setAttribute('position', `${pos.x} ${pos.y} ${pos.z}`);
    vrUIPanel.setAttribute('rotation', `${rot.x} ${rot.y} ${rot.z}`);
    
    // Panel arka plan
    const panelBg = document.createElement('a-plane');
    panelBg.setAttribute('width', settings.panelWidth);
    panelBg.setAttribute('height', settings.panelHeight);
    panelBg.setAttribute('color', colors.background);
    panelBg.setAttribute('opacity', '0.95');
    panelBg.setAttribute('shader', 'flat');
    panelBg.setAttribute('data-raycastable', '');
    vrUIPanel.appendChild(panelBg);
    
    // Başlık
    const title = document.createElement('a-text');
    title.setAttribute('value', 'KONTROLLER');
    title.setAttribute('align', 'center');
    title.setAttribute('width', settings.titleTextWidth);
    title.setAttribute('color', colors.title);
    title.setAttribute('position', `0 ${settings.panelHeight / 2 - 0.3} 0.01`);
    title.setAttribute('font', 'roboto');
    vrUIPanel.appendChild(title);
    
    // ============================================
    // OYNAT/DURAKLAT BUTONU (3X BÜYÜK)
    // ============================================
    const playBtn = document.createElement('a-plane');
    playBtn.setAttribute('id', 'vr-play-btn');
    playBtn.setAttribute('width', settings.buttonWidth);
    playBtn.setAttribute('height', settings.buttonHeight);
    playBtn.setAttribute('color', colors.playButton);
    playBtn.setAttribute('position', `0 ${settings.panelHeight / 2 - 0.8} 0.01`);
    playBtn.setAttribute('class', 'clickable');
    playBtn.setAttribute('data-raycastable', '');
    
    const playIcon = document.createElement('a-text');
    playIcon.setAttribute('id', 'vr-play-icon');
    playIcon.setAttribute('value', '▶️ OYNAT');
    playIcon.setAttribute('align', 'center');
    playIcon.setAttribute('width', settings.buttonTextWidth);
    playIcon.setAttribute('color', colors.text);
    playIcon.setAttribute('position', '0 0 0.01');
    playBtn.appendChild(playIcon);
    
    playBtn.addEventListener('click', () => {
        togglePlayPause();
        setTimeout(() => {
            const icon = document.getElementById('vr-play-icon');
            if (icon && videoElement) {
                icon.setAttribute('value', videoElement.paused ? '▶️ OYNAT' : '⏸️ DURAKLAT');
            }
        }, 100);
    });
    
    vrUIPanel.appendChild(playBtn);
    
    // ============================================
    // GERİ VE İLERİ BUTONLARI (3X BÜYÜK)
    // ============================================
    const buttonY = settings.panelHeight / 2 - 1.3;
    const buttonSpacing = settings.buttonWidth / 2 + 0.15;
    
    // GERİ BUTONU
    const rewindBtn = document.createElement('a-plane');
    rewindBtn.setAttribute('width', settings.buttonWidth / 2.2);
    rewindBtn.setAttribute('height', settings.buttonHeight);
    rewindBtn.setAttribute('color', colors.rewindButton);
    rewindBtn.setAttribute('position', `-${buttonSpacing} ${buttonY} 0.01`);
    rewindBtn.setAttribute('class', 'clickable');
    rewindBtn.setAttribute('data-raycastable', '');
    
    const rewindText = document.createElement('a-text');
    rewindText.setAttribute('value', '◀ 10s');
    rewindText.setAttribute('align', 'center');
    rewindText.setAttribute('width', settings.buttonTextWidth / 1.5);
    rewindText.setAttribute('color', colors.text);
    rewindText.setAttribute('position', '0 0 0.01');
    rewindBtn.appendChild(rewindText);
    
    rewindBtn.addEventListener('click', () => {
        seekVideo(-10);
    });
    
    vrUIPanel.appendChild(rewindBtn);
    
    // İLERİ BUTONU
    const forwardBtn = document.createElement('a-plane');
    forwardBtn.setAttribute('width', settings.buttonWidth / 2.2);
    forwardBtn.setAttribute('height', settings.buttonHeight);
    forwardBtn.setAttribute('color', colors.forwardButton);
    forwardBtn.setAttribute('position', `${buttonSpacing} ${buttonY} 0.01`);
    forwardBtn.setAttribute('class', 'clickable');
    forwardBtn.setAttribute('data-raycastable', '');
    
    const forwardText = document.createElement('a-text');
    forwardText.setAttribute('value', '10s ▶');
    forwardText.setAttribute('align', 'center');
    forwardText.setAttribute('width', settings.buttonTextWidth / 1.5);
    forwardText.setAttribute('color', colors.text);
    forwardText.setAttribute('position', '0 0 0.01');
    forwardBtn.appendChild(forwardText);
    
    forwardBtn.addEventListener('click', () => {
        seekVideo(10);
    });
    
    vrUIPanel.appendChild(forwardBtn);
    
    // ============================================
    // SEEK BAR (3X BÜYÜK)
    // ============================================
    const seekBarY = buttonY - 0.5;
    
    vrSeekBar = document.createElement('a-plane');
    vrSeekBar.setAttribute('width', settings.seekBarWidth);
    vrSeekBar.setAttribute('height', settings.seekBarHeight);
    vrSeekBar.setAttribute('color', colors.seekBar);
    vrSeekBar.setAttribute('position', `0 ${seekBarY} 0.01`);
    vrSeekBar.setAttribute('class', 'clickable');
    vrSeekBar.setAttribute('data-raycastable', '');
    
    const seekProgress = document.createElement('a-plane');
    seekProgress.id = 'vr-seek-progress';
    seekProgress.setAttribute('width', '0');
    seekProgress.setAttribute('height', settings.seekBarHeight);
    seekProgress.setAttribute('color', colors.seekProgress);
    seekProgress.setAttribute('position', `-${settings.seekBarWidth / 2} 0 0.01`);
    vrSeekBar.appendChild(seekProgress);
    
    vrSeekBar.addEventListener('click', (evt) => {
        if (!videoElement) return;
        
        const intersection = evt.detail.intersection;
        if (!intersection) return;
        
        const localPoint = intersection.point;
        const seekBarEl = vrSeekBar.object3D;
        
        seekBarEl.worldToLocal(localPoint);
        
        const relativeX = localPoint.x;
        const seekBarWidth = settings.seekBarWidth;
        const percentage = (relativeX + seekBarWidth / 2) / seekBarWidth;
        
        console.log('🎯 Seek bar tıklandı:', {
            relativeX: relativeX.toFixed(2),
            percentage: (percentage * 100).toFixed(1) + '%'
        });
        
        seekToPosition(percentage);
    });
    
    vrUIPanel.appendChild(vrSeekBar);
    
    // Zaman göstergesi
    const timeDisplay = document.createElement('a-text');
    timeDisplay.id = 'vr-time-display';
    timeDisplay.setAttribute('value', '0:00 / 0:00');
    timeDisplay.setAttribute('align', 'center');
    timeDisplay.setAttribute('width', settings.timeTextWidth);
    timeDisplay.setAttribute('color', colors.timeText);
    timeDisplay.setAttribute('position', `0 ${seekBarY - 0.25} 0.01`);
    vrUIPanel.appendChild(timeDisplay);
    
    // ============================================
    // EKRAN POZİSYONU KONTROLLERI
    // ============================================
    const screenControlY = seekBarY - 0.7;
    
    // Başlık
    const screenTitle = document.createElement('a-text');
    screenTitle.setAttribute('value', 'EKRAN');
    screenTitle.setAttribute('align', 'center');
    screenTitle.setAttribute('width', settings.titleTextWidth);
    screenTitle.setAttribute('color', colors.title);
    screenTitle.setAttribute('position', `0 ${screenControlY} 0.01`);
    vrUIPanel.appendChild(screenTitle);
    
    // OK tuşları (3x büyük)
    const arrowSize = settings.smallButtonSize * 2.5;
    const arrowY = screenControlY - 0.35;
    const arrowSpacingH = 0.4;
    const arrowSpacingV = 0.35;
    
    // YUKARI (▲)
    const upBtn = document.createElement('a-plane');
    upBtn.setAttribute('width', arrowSize);
    upBtn.setAttribute('height', arrowSize);
    upBtn.setAttribute('color', colors.arrowButtons);
    upBtn.setAttribute('position', `0 ${arrowY} 0.01`);
    upBtn.setAttribute('class', 'clickable');
    upBtn.setAttribute('data-raycastable', '');
    
    const upTriangle = document.createElement('a-triangle');
    upTriangle.setAttribute('vertex-a', '0 0.08 0');
    upTriangle.setAttribute('vertex-b', '-0.08 -0.04 0');
    upTriangle.setAttribute('vertex-c', '0.08 -0.04 0');
    upTriangle.setAttribute('color', colors.text);
    upTriangle.setAttribute('position', '0 0 0.01');
    upBtn.appendChild(upTriangle);
    
    upBtn.addEventListener('click', () => {
        moveScreen('up');
    });
    
    vrUIPanel.appendChild(upBtn);
    
    // SOL (◀)
    const leftBtn = document.createElement('a-plane');
    leftBtn.setAttribute('width', arrowSize);
    leftBtn.setAttribute('height', arrowSize);
    leftBtn.setAttribute('color', colors.arrowButtons);
    leftBtn.setAttribute('position', `-${arrowSpacingH} ${arrowY - arrowSpacingV} 0.01`);
    leftBtn.setAttribute('class', 'clickable');
    leftBtn.setAttribute('data-raycastable', '');
    
    const leftTriangle = document.createElement('a-triangle');
    leftTriangle.setAttribute('vertex-a', '-0.08 0 0');
    leftTriangle.setAttribute('vertex-b', '0.04 0.08 0');
    leftTriangle.setAttribute('vertex-c', '0.04 -0.08 0');
    leftTriangle.setAttribute('color', colors.text);
    leftTriangle.setAttribute('position', '0 0 0.01');
    leftBtn.appendChild(leftTriangle);
    
    leftBtn.addEventListener('click', () => {
        moveScreen('left');
    });
    
    vrUIPanel.appendChild(leftBtn);
    
    // AŞAĞI (▼)
    const downBtn = document.createElement('a-plane');
    downBtn.setAttribute('width', arrowSize);
    downBtn.setAttribute('height', arrowSize);
    downBtn.setAttribute('color', colors.arrowButtons);
    downBtn.setAttribute('position', `0 ${arrowY - arrowSpacingV} 0.01`);
    downBtn.setAttribute('class', 'clickable');
    downBtn.setAttribute('data-raycastable', '');
    
    const downTriangle = document.createElement('a-triangle');
    downTriangle.setAttribute('vertex-a', '0 -0.08 0');
    downTriangle.setAttribute('vertex-b', '-0.08 0.04 0');
    downTriangle.setAttribute('vertex-c', '0.08 0.04 0');
    downTriangle.setAttribute('color', colors.text);
    downTriangle.setAttribute('position', '0 0 0.01');
    downBtn.appendChild(downTriangle);
    
    downBtn.addEventListener('click', () => {
        moveScreen('down');
    });
    
    vrUIPanel.appendChild(downBtn);
    
    // SAĞ (▶)
    const rightBtn = document.createElement('a-plane');
    rightBtn.setAttribute('width', arrowSize);
    rightBtn.setAttribute('height', arrowSize);
    rightBtn.setAttribute('color', colors.arrowButtons);
    rightBtn.setAttribute('position', `${arrowSpacingH} ${arrowY - arrowSpacingV} 0.01`);
    rightBtn.setAttribute('class', 'clickable');
    rightBtn.setAttribute('data-raycastable', '');
    
    const rightTriangle = document.createElement('a-triangle');
    rightTriangle.setAttribute('vertex-a', '0.08 0 0');
    rightTriangle.setAttribute('vertex-b', '-0.04 0.08 0');
    rightTriangle.setAttribute('vertex-c', '-0.04 -0.08 0');
    rightTriangle.setAttribute('color', colors.text);
    rightTriangle.setAttribute('position', '0 0 0.01');
    rightBtn.appendChild(rightTriangle);
    
    rightBtn.addEventListener('click', () => {
        moveScreen('right');
    });
    
    vrUIPanel.appendChild(rightBtn);
    
    // SIFIRLA BUTONU
    const resetBtn = document.createElement('a-plane');
    resetBtn.setAttribute('width', arrowSize * 1.5);
    resetBtn.setAttribute('height', arrowSize * 0.8);
    resetBtn.setAttribute('color', colors.resetButton);
    resetBtn.setAttribute('position', `0 ${arrowY - arrowSpacingV * 2.2} 0.01`);
    resetBtn.setAttribute('class', 'clickable');
    resetBtn.setAttribute('data-raycastable', '');
    
    const resetText = document.createElement('a-text');
    resetText.setAttribute('value', '↺ SIFIRLA');
    resetText.setAttribute('align', 'center');
    resetText.setAttribute('width', settings.buttonTextWidth);
    resetText.setAttribute('color', colors.text);
    resetText.setAttribute('position', '0 0 0.01');
    resetBtn.appendChild(resetText);
    
    resetBtn.addEventListener('click', () => {
        moveScreen('reset');
    });
    
    vrUIPanel.appendChild(resetBtn);
    
    // Sahneye ekle
    scene.appendChild(vrUIPanel);
    
    // Seek bar update interval
    if (vrSeekBarInterval) {
        clearInterval(vrSeekBarInterval);
    }
    
    vrSeekBarInterval = setInterval(() => {
        if (videoElement && videoElement.duration) {
            const progress = (videoElement.currentTime / videoElement.duration);
            const progressWidth = progress * settings.seekBarWidth;
            
            const seekProgress = document.getElementById('vr-seek-progress');
            if (seekProgress) {
                seekProgress.setAttribute('width', progressWidth);
                seekProgress.setAttribute('position', `${-settings.seekBarWidth / 2 + progressWidth / 2} 0 0.01`);
            }
            
            const timeDisplay = document.getElementById('vr-time-display');
            if (timeDisplay) {
                const current = formatTime(videoElement.currentTime);
                const total = formatTime(videoElement.duration);
                timeDisplay.setAttribute('value', `${current} / ${total}`);
            }
            
            const playIcon = document.getElementById('vr-play-icon');
            if (playIcon && videoElement) {
                playIcon.setAttribute('value', videoElement.paused ? '▶️ OYNAT' : '⏸️ DURAKLAT');
            }
        }
    }, 1000);
    
    console.log('✅ VR UI Panel oluşturuldu (3X BÜYÜK - Settings entegre)');
    console.log('   ↗ Panel:', settings.panelWidth, 'x', settings.panelHeight);
    console.log('   ↗ Buton:', settings.buttonWidth, 'x', settings.buttonHeight);
    console.log('   ↗ Seek bar:', settings.seekBarWidth, 'x', settings.seekBarHeight);
    console.log('   ↗ Pozisyon:', `(${pos.x}, ${pos.y}, ${pos.z})`);
    console.log('   ↗ Rotasyon:', `(${rot.x}°, ${rot.y}°, ${rot.z}°)`);
}

function moveScreen(direction) {
    const screen = document.getElementById('video-screen');
    if (!screen) return;
    
    const step = getSetting('screen.moveStep');
    
    switch(direction) {
        case 'up':
            screenPosition.y += step;
            break;
        case 'down':
            screenPosition.y -= step;
            break;
        case 'left':
            screenPosition.x -= step;
            break;
        case 'right':
            screenPosition.x += step;
            break;
        case 'forward':
            screenPosition.z += step;
            break;
        case 'backward':
            screenPosition.z -= step;
            break;
        case 'reset':
            const defaultPos = getSetting('screen.defaultPosition');
            screenPosition = { ...defaultPos };
            break;
    }
    
    screen.setAttribute('position', screenPosition);
    console.log('✅ Ekran pozisyonu:', screenPosition);
}

console.log('✅ VR UI Panel sistemi yüklendi (3X BÜYÜK - Settings entegre)');
