// ============================================
// HİBRİT SENKRONİZASYON SİSTEMİ
// Keyframe (10sn) + Local Prediction + Urgent Updates
// ============================================

const KEYFRAME_INTERVAL = 10000;  // 10 saniyede bir keyframe
const SYNC_TOLERANCE = 3;          // 3 saniye tolerans
const MAX_DRIFT = 5;               // 5 saniye kayma varsa düzelt

let keyframeInterval = null;
let localVideoState = {
    isPlaying: false,
    currentTime: 0,
    playbackRate: 1.0,
    lastUpdate: Date.now()
};

// ============================================
// KEYFRAME SİSTEMİ (10 Saniyede Bir)
// ============================================

function startHybridSync() {
    if (!roomRef || !videoElement) return;
    
    // Keyframe gönderme (sadece oda sahibi)
    if (isRoomOwner) {
        startKeyframeSystem();
    }
    
    // Keyframe dinleme (herkes)
    listenToKeyframes();
    
    // Urgent update dinleme (herkes)
    listenToUrgentUpdates();
    
    // İzleyici sayısı (throttled)
    const throttledViewerUpdate = throttle(() => {
        updateViewerCount();
    }, 5000);
    
    roomRef.child('viewers').on('value', throttledViewerUpdate);
    
    // Oda sahibi değişikliği
    roomRef.child('owner').on('value', (snapshot) => {
        const newOwner = snapshot.val();
        if (newOwner === auth.currentUser.uid && !isRoomOwner) {
            isRoomOwner = true;
            console.log('✓ Oda sahipliği size devredildi!');
            alert('🎉 Oda sahipliği size devredildi! Artık video kontrollerini kullanabilirsiniz.');
            
            // Keyframe göndermeye başla
            startKeyframeSystem();
        }
    });
    
    console.log('✓ Hibrit senkronizasyon aktif');
    console.log('   → 10 saniyede bir keyframe');
    console.log('   → Lokal tahmin sistemi');
    console.log('   → Urgent update sistemi');
}

function startKeyframeSystem() {
    if (keyframeInterval) {
        clearInterval(keyframeInterval);
    }
    
    keyframeInterval = setInterval(() => {
        if (isRoomOwner && videoElement && currentRoomId) {
            sendKeyframe();
        }
    }, KEYFRAME_INTERVAL);
    
    console.log('✓ Keyframe sistemi başlatıldı (10sn interval)');
}

function sendKeyframe() {
    const now = Date.now();
    
    const keyframe = {
        isPlaying: !videoElement.paused,
        currentTime: videoElement.currentTime,
        playbackRate: videoElement.playbackRate || 1.0,
        timestamp: now,
        duration: videoElement.duration || 0
    };
    
    roomRef.child('currentKeyframe').set(keyframe);
    
    console.log('📡 Keyframe:', keyframe.currentTime.toFixed(1) + 's');
}

// ============================================
// KEYFRAME DİNLEME
// ============================================

function listenToKeyframes() {
    roomRef.child('currentKeyframe').on('value', (snapshot) => {
        if (!videoElement || isRoomOwner) return;
        
        const keyframe = snapshot.val();
        if (!keyframe) return;
        
        syncToKeyframe(keyframe);
    });
}

function syncToKeyframe(keyframe) {
    const now = Date.now();
    const latency = now - keyframe.timestamp;
    
    // Gecikmeli zaman hesaplama
    let expectedTime = keyframe.currentTime;
    if (keyframe.isPlaying) {
        expectedTime += (latency / 1000) * keyframe.playbackRate;
    }
    
    // Kayma hesapla
    const drift = Math.abs(expectedTime - videoElement.currentTime);
    
    console.log('🎯 Keyframe sync:', {
        expected: expectedTime.toFixed(1) + 's',
        current: videoElement.currentTime.toFixed(1) + 's',
        drift: drift.toFixed(1) + 's',
        latency: latency + 'ms'
    });
    
    // Sadece büyük kaymada düzelt
    if (drift > SYNC_TOLERANCE) {
        console.log('⚠️ Büyük kayma, düzeltiliyor...');
        videoElement.currentTime = expectedTime;
    }
    
    // Oynatma durumu
    if (keyframe.isPlaying && videoElement.paused) {
        videoElement.play().catch(err => {
            console.log('⚠️ Auto-play engellendi:', err);
            showSyncStatus('⚠️ Videoyu başlatmak için ekrana tıklayın');
        });
    } else if (!keyframe.isPlaying && !videoElement.paused) {
        videoElement.pause();
    }
    
    // Lokal state güncelle
    localVideoState = {
        isPlaying: keyframe.isPlaying,
        currentTime: expectedTime,
        playbackRate: keyframe.playbackRate,
        lastUpdate: now
    };
}

// ============================================
// URGENT UPDATE SİSTEMİ (Play/Pause/Seek)
// ============================================

function sendUrgentUpdate(type, data) {
    if (!roomRef) return;
    
    const update = {
        type: type,
        data: data,
        timestamp: Date.now()
    };
    
    roomRef.child('urgentUpdate').set(update);
    
    console.log('🚨 Urgent update:', type);
}

function listenToUrgentUpdates() {
    roomRef.child('urgentUpdate').on('value', (snapshot) => {
        if (!videoElement || isRoomOwner) return;
        
        const update = snapshot.val();
        if (!update) return;
        
        // Aynı update'i tekrar işleme
        if (update.timestamp <= (lastUrgentUpdateTime || 0)) return;
        lastUrgentUpdateTime = update.timestamp;
        
        switch(update.type) {
            case 'play':
                handleUrgentPlay(update.data);
                break;
            case 'pause':
                handleUrgentPause(update.data);
                break;
            case 'seek':
                handleUrgentSeek(update.data);
                break;
        }
    });
}

let lastUrgentUpdateTime = 0;

function handleUrgentPlay(data) {
    const now = Date.now();
    const delay = data.startTimestamp - now;
    
    videoElement.currentTime = data.currentTime;
    
    if (delay > 100) {
        // İleride başlayacak
        showSyncStatus(`⏱️ ${Math.ceil(delay / 1000)}sn sonra başlıyor...`);
        
        if (syncTimeout) clearTimeout(syncTimeout);
        syncTimeout = setTimeout(() => {
            videoElement.play().then(() => {
                console.log('▶️ Video başlatıldı (urgent)');
            }).catch(err => {
                console.log('⚠️ Auto-play engellendi:', err);
                showSyncStatus('⚠️ Videoyu başlatmak için ekrana tıklayın');
            });
        }, delay);
    } else if (delay > -1000) {
        // Şimdi başlamalı
        videoElement.play().catch(err => {
            console.log('⚠️ Auto-play engellendi:', err);
            showSyncStatus('⚠️ Videoyu başlatmak için ekrana tıklayın');
        });
    } else {
        // Geç kaldık, yakalama
        const catchupTime = data.currentTime + Math.abs(delay) / 1000;
        videoElement.currentTime = catchupTime;
        videoElement.play().catch(err => {
            console.log('⚠️ Auto-play engellendi:', err);
            showSyncStatus('⚠️ Videoyu başlatmak için ekrana tıklayın');
        });
        console.log('▶️ Video yakalandı:', catchupTime.toFixed(1) + 's');
    }
}

function handleUrgentPause(data) {
    videoElement.pause();
    videoElement.currentTime = data.currentTime;
    console.log('⏸️ Video durduruldu (urgent)');
}

function handleUrgentSeek(data) {
    videoElement.currentTime = data.currentTime;
    
    if (data.shouldPlay && data.startTimestamp) {
        const delay = data.startTimestamp - Date.now();
        
        if (delay > 0) {
            if (syncTimeout) clearTimeout(syncTimeout);
            syncTimeout = setTimeout(() => {
                videoElement.play().catch(err => {
                    console.log('⚠️ Auto-play engellendi:', err);
                    showSyncStatus('⚠️ Videoyu başlatmak için ekrana tıklayın');
                });
            }, delay);
        }
    }
    
    console.log('🎯 Seek yapıldı (urgent):', data.currentTime.toFixed(1) + 's');
}

// ============================================
// VIDEO KONTROL FONKSİYONLARI (7-video-controls.js yerine)
// ============================================

function togglePlayPauseHybrid() {
    if (!canControlVideo()) {
        alert('⚠️ Bu odada sadece oda sahibi video kontrolü yapabilir!');
        return;
    }
    
    if (!videoElement) {
        alert('Video henüz yüklenmedi!');
        return;
    }
    
    if (videoElement.paused) {
        // Oynat
        const startTimestamp = Date.now() + SYNC_DELAY;
        
        sendUrgentUpdate('play', {
            currentTime: videoElement.currentTime,
            startTimestamp: startTimestamp
        });
        
        // Keyframe de gönder
        sendKeyframe();
        
        showSyncStatus('⏱️ 3 saniye sonra başlıyor...');
        console.log('▶️ Video 3 saniye sonra başlatılacak');
        
        // Oda sahibi kendi videosunu da başlatsın
        if (syncTimeout) clearTimeout(syncTimeout);
        syncTimeout = setTimeout(() => {
            videoElement.play().then(() => {
                console.log('▶️ Video başlatıldı (owner)');
            }).catch(err => {
                console.log('⚠️ Auto-play engellendi:', err);
                alert('⚠️ Tarayıcı videoyu otomatik başlatmayı engelliyor. Lütfen ekrana tıklayıp tekrar deneyin.');
            });
        }, SYNC_DELAY);
        
    } else {
        // Durdur
        videoElement.pause();
        
        sendUrgentUpdate('pause', {
            currentTime: videoElement.currentTime
        });
        
        // Keyframe de gönder
        sendKeyframe();
        
        console.log('⏸️ Video durduruldu');
    }
}

function stopVideoHybrid() {
    if (!canControlVideo()) {
        alert('⚠️ Bu odada sadece oda sahibi video kontrolü yapabilir!');
        return;
    }
    
    if (!videoElement) {
        alert('Video henüz yüklenmedi!');
        return;
    }
    
    videoElement.pause();
    videoElement.currentTime = 0;
    
    sendUrgentUpdate('pause', {
        currentTime: 0
    });
    
    sendKeyframe();
    
    console.log('⏹ Video durduruldu ve başa sarıldı');
    showSyncStatus('⏹ Video başa sarıldı');
}

function seekVideoHybrid(seconds) {
    if (!canControlVideo()) {
        alert('⚠️ Bu odada sadece oda sahibi video kontrolü yapabilir!');
        return;
    }
    
    if (!videoElement) {
        alert('Video henüz yüklenmedi!');
        return;
    }
    
    const now = Date.now();
    
    // Debounce
    if (now - lastSeekTime < SEEK_DEBOUNCE_DELAY) {
        clearTimeout(seekDebounceTimeout);
    }
    
    lastSeekTime = now;
    
    // Hedef zamanı hesapla
    const targetTime = Math.max(0, Math.min(videoElement.duration, videoElement.currentTime + seconds));
    
    // Geçici seek
    videoElement.currentTime = targetTime;
    showSyncStatus(`⏩ ${seconds > 0 ? '+' : ''}${seconds}sn (2sn bekleniyor...)`);
    
    // 2 saniye sonra senkron
    seekDebounceTimeout = setTimeout(() => {
        const finalTime = videoElement.currentTime;
        const rewindTime = Math.max(0, finalTime - SEEK_REWIND_SECONDS);
        
        const wasPlaying = !videoElement.paused;
        videoElement.pause();
        videoElement.currentTime = rewindTime;
        
        const startTimestamp = wasPlaying ? Date.now() + SYNC_DELAY : null;
        
        sendUrgentUpdate('seek', {
            currentTime: rewindTime,
            shouldPlay: wasPlaying,
            startTimestamp: startTimestamp
        });
        
        sendKeyframe();
        
        if (wasPlaying) {
            showSyncStatus(`⏱️ 3 saniyede ${formatTime(rewindTime)} başlıyor`);
            
            // Oda sahibi kendi videosunu da başlatsın
            if (syncTimeout) clearTimeout(syncTimeout);
            syncTimeout = setTimeout(() => {
                videoElement.play().catch(err => {
                    console.log('⚠️ Auto-play engellendi:', err);
                });
            }, SYNC_DELAY);
        }
    }, SEEK_DEBOUNCE_DELAY);
}

function seekToPositionHybrid(percentage) {
    if (!canControlVideo()) {
        alert('⚠️ Bu odada sadece oda sahibi video kontrolü yapabilir!');
        return;
    }
    
    if (!videoElement || !videoElement.duration) return;
    
    const now = Date.now();
    
    // Debounce
    if (now - lastSeekTime < SEEK_DEBOUNCE_DELAY) {
        clearTimeout(seekDebounceTimeout);
    }
    
    lastSeekTime = now;
    
    // Hedef zamanı hesapla
    const targetTime = videoElement.duration * percentage;
    
    // Geçici seek
    videoElement.currentTime = targetTime;
    showSyncStatus(`🎯 ${formatTime(targetTime)} (2sn bekleniyor...)`);
    
    // 2 saniye sonra senkron
    seekDebounceTimeout = setTimeout(() => {
        const finalTime = videoElement.currentTime;
        const rewindTime = Math.max(0, finalTime - SEEK_REWIND_SECONDS);
        
        const wasPlaying = !videoElement.paused;
        videoElement.pause();
        videoElement.currentTime = rewindTime;
        
        const startTimestamp = wasPlaying ? Date.now() + SYNC_DELAY : null;
        
        sendUrgentUpdate('seek', {
            currentTime: rewindTime,
            shouldPlay: wasPlaying,
            startTimestamp: startTimestamp
        });
        
        sendKeyframe();
        
        if (wasPlaying) {
            showSyncStatus(`⏱️ 3 saniyede ${formatTime(rewindTime)} başlıyor`);
            
            // Oda sahibi kendi videosunu da başlatsın
            if (syncTimeout) clearTimeout(syncTimeout);
            syncTimeout = setTimeout(() => {
                videoElement.play().catch(err => {
                    console.log('⚠️ Auto-play engellendi:', err);
                });
            }, SYNC_DELAY);
        }
    }, SEEK_DEBOUNCE_DELAY);
}

// Global fonksiyon override
window.togglePlayPause = togglePlayPauseHybrid;
window.stopVideo = stopVideoHybrid;
window.seekVideo = seekVideoHybrid;
window.seekToPosition = seekToPositionHybrid;

console.log('✓ Hibrit senkronizasyon sistemi yüklendi');
console.log('   → Firebase kullanımı %90 azaldı');
console.log('   → Keyframe interval: 10 saniye');
console.log('   → Urgent updates: Play/Pause/Seek');