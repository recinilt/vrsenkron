// ============================================
// HİBRİT SENKRONİZASYON SİSTEMİ (UPGRADED)
// ============================================

// YENİ: 10sn → 5sn
const KEYFRAME_INTERVAL = 5000;
const MAX_DRIFT = 2.0;

let lastKeyframeTime = 0;
let keyframeSendInterval = null;

// ============================================
// YENİ: PREDİCTİVE SYNC + ADAPTİVE CORRECTİON
// ============================================

function syncToKeyframe(keyframe) {
    if (!videoElement || !keyframe) return;
    
    const now = getAdjustedTime();
    const latency = now - keyframe.timestamp;
    
    // TAHMİNİ ZAMAN (Extrapolation)
    let expectedTime = keyframe.currentTime;
    
    if (keyframe.isPlaying) {
        const playbackRate = keyframe.playbackRate || 1.0;
        expectedTime += (latency / 1000) * playbackRate;
        
        console.log('🎯 Predictive sync:', {
            keyframeTime: keyframe.currentTime.toFixed(2),
            latency: latency + 'ms',
            expectedTime: expectedTime.toFixed(2)
        });
    }
    
    // KAYMA HESAPLAMA
    const drift = Math.abs(expectedTime - videoElement.currentTime);
    
    console.log('📊 Drift:', drift.toFixed(2), 'saniye');
    
    // ADAPTİF DÜZELTME
    if (drift > 5) {
        // BÜYÜK KAYMA - Anında düzelt
        console.log('⚡ Büyük kayma, anında düzelt');
        videoElement.currentTime = expectedTime;
        
        if (keyframe.isPlaying && videoElement.paused) {
            videoElement.play().catch(err => console.log('Auto-play engellendi:', err));
        } else if (!keyframe.isPlaying && !videoElement.paused) {
            videoElement.pause();
        }
        
    } else if (drift > 1) {
        // ORTA KAYMA - Playback rate ile yumuşak düzelt
        console.log('🎚️ Orta kayma, playback rate düzelt');
        
        const baseRate = keyframe.playbackRate || 1.0;
        
        if (expectedTime > videoElement.currentTime) {
            // Gerideyiz - Hızlandır
            videoElement.playbackRate = baseRate * 1.05;
            console.log('   → Hızlandırma: x1.05');
        } else {
            // Öndeyiz - Yavaşlat
            videoElement.playbackRate = baseRate * 0.95;
            console.log('   → Yavaşlatma: x0.95');
        }
        
        // 2 saniye sonra normal hıza dön
        setTimeout(() => {
            videoElement.playbackRate = baseRate;
            console.log('✅ Normal playback rate geri yüklendi');
        }, 2000);
        
        if (keyframe.isPlaying && videoElement.paused) {
            videoElement.play().catch(err => console.log('Auto-play engellendi:', err));
        }
        
    } else if (drift > 0.5) {
        // KÜÇÜK KAYMA - Sadece play/pause kontrol et
        console.log('✓ Küçük kayma, play/pause kontrol');
        
        if (keyframe.isPlaying && videoElement.paused) {
            videoElement.play().catch(err => console.log('Auto-play engellendi:', err));
        } else if (!keyframe.isPlaying && !videoElement.paused) {
            videoElement.pause();
        }
    }
    // drift < 0.5 saniye: Hiçbir şey yapma (tolere et)
    
    lastKeyframeTime = keyframe.timestamp;
}

function sendKeyframe() {
    if (!isRoomOwner || !videoElement || !roomRef) return;
    
    const keyframe = {
        isPlaying: !videoElement.paused,
        currentTime: videoElement.currentTime,
        playbackRate: videoElement.playbackRate,
        timestamp: getAdjustedTime(),
        duration: videoElement.duration
    };
    
    roomRef.child('currentKeyframe').set(keyframe);
    console.log('📤 Keyframe gönderildi:', keyframe.currentTime.toFixed(1) + 's');
}

function startKeyframeSystem() {
    if (!isRoomOwner) {
        console.log('📡 Keyframe listener başlatıldı (izleyici modu)');
        
        keyframeListener = roomRef.child('currentKeyframe').on('value', (snapshot) => {
            const keyframe = snapshot.val();
            if (keyframe) {
                syncToKeyframe(keyframe);
            }
        });
        return;
    }
    
    console.log('📡 Keyframe sender başlatıldı (oda sahibi modu)');
    
    if (keyframeSendInterval) {
        clearInterval(keyframeSendInterval);
    }
    
    sendKeyframe();
    keyframeSendInterval = setInterval(sendKeyframe, KEYFRAME_INTERVAL);
}

function stopKeyframeSystem() {
    if (keyframeSendInterval) {
        clearInterval(keyframeSendInterval);
        keyframeSendInterval = null;
        console.log('⏹️ Keyframe sender durduruldu');
    }
    
    if (keyframeListener && roomRef) {
        roomRef.child('currentKeyframe').off('value', keyframeListener);
        keyframeListener = null;
        console.log('⏹️ Keyframe listener durduruldu');
    }
}

console.log('✅ Hibrit senkronizasyon sistemi yüklendi (UPGRADED)');
console.log('   → Keyframe interval: 5 saniye');
console.log('   → Predictive sync (extrapolation)');
console.log('   → Adaptive correction (playback rate)');
console.log('   → Clock drift compensation');