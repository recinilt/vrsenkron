// ============================================
// FİREBASE SENKRONİZASYON SİSTEMİ - TAM SENKRON (UPGRADED)
// ============================================

// ============================================
// YENİ: LISTENER TEMİZLEME FONKSİYONU
// ============================================

function cleanupListeners() {
    if (!roomRef) return;
    
    if (videoStateListener) {
        roomRef.child('videoState').off('value', videoStateListener);
        videoStateListener = null;
        console.log('✅ videoState listener temizlendi');
    }
    
    if (viewersListener) {
        roomRef.child('viewers').off('value', viewersListener);
        viewersListener = null;
        console.log('✅ viewers listener temizlendi');
    }
    
    if (ownerListener) {
        roomRef.child('owner').off('value', ownerListener);
        ownerListener = null;
        console.log('✅ owner listener temizlendi');
    }
    
    if (urgentUpdateListener) {
        roomRef.child('urgentUpdate').off('value', urgentUpdateListener);
        urgentUpdateListener = null;
        console.log('✅ urgentUpdate listener temizlendi');
    }
    
    console.log('✅ Tüm listener\'lar temizlendi');
}

// ============================================
// YENİ: ADAPTIVE BUFFERING (Pre-buffer)
// ============================================

function handleUrgentPlay(data) {
    if (!videoElement) return;
    
    const now = getAdjustedTime();
    const delay = data.startTimestamp - now;
    
    console.log('▶️ Urgent play:', {
        delay: delay + 'ms',
        targetTime: data.currentTime.toFixed(2)
    });
    
    // PRE-BUFFER (1 saniyeden fazla bekleme varsa)
    if (delay > 1000) {
        videoElement.currentTime = data.currentTime;
        
        videoElement.play().then(() => {
            // Buffer doldur ama durdur
            videoElement.pause();
            
            let countdown = Math.ceil(delay / 1000);
            const countdownInterval = setInterval(() => {
                countdown--;
                if (countdown > 0) {
                    showSyncStatus(`⏳ ${countdown}sn sonra başlıyor...`);
                } else {
                    clearInterval(countdownInterval);
                }
            }, 1000);
            
            // Asıl başlatma
            setTimeout(() => {
                videoElement.currentTime = data.currentTime;  // Tekrar ayarla
                videoElement.play().then(() => {
                    console.log('✅ Pre-buffered play başladı');
                    showSyncStatus('');
                }).catch(err => {
                    console.log('Play hatası:', err);
                });
            }, delay);
        }).catch(err => {
            console.log('Pre-buffer başarısız:', err);
            // Fallback: Normal başlatma
            setTimeout(() => {
                videoElement.currentTime = data.currentTime;
                videoElement.play().catch(e => console.log('Fallback play hatası:', e));
            }, Math.max(0, delay));
        });
        
    } else if (delay > 0) {
        // Normal başlatma (kısa gecikme)
        setTimeout(() => {
            videoElement.currentTime = data.currentTime;
            videoElement.play().catch(err => console.log('Play hatası:', err));
        }, delay);
    } else {
        // Geç kaldık, hemen başlat
        const catchupTime = data.currentTime + Math.abs(delay) / 1000;
        videoElement.currentTime = catchupTime;
        videoElement.play().catch(err => console.log('Catch-up play hatası:', err));
        console.log('⚡ Catch-up play:', catchupTime.toFixed(2));
    }
}

// ============================================
// GÜNCELLENMİŞ: LISTENER'LARI KURMA
// ============================================

function listenToRoomUpdates() {
    if (!roomRef) return;
    
    // Önceki listener'ları temizle
    cleanupListeners();
    
    // Video durumu değişikliklerini dinle
    videoStateListener = (snapshot) => {
        if (!videoElement) return;
        
        const state = snapshot.val();
        if (!state) return;
        
        // ESKİ UPDATE'İ GÖZ ARDI ET
        if (state.lastUpdate && state.lastUpdate <= lastActionTimestamp) {
            console.log('⏭️ Eski update göz ardı edildi');
            return;
        }
        
        if (state.lastUpdate) {
            lastActionTimestamp = state.lastUpdate;
        }
        
        const now = getAdjustedTime();
        
        // Video durduruldu veya seek yapıldı (oynatma yok)
        if (!state.isPlaying) {
            if (!videoElement.paused) {
                videoElement.pause();
                console.log('⏸️ Video durduruldu (sync)');
            }
            
            // Seek değişikliği varsa güncelle
            if (Math.abs(videoElement.currentTime - state.currentTime) > 0.5) {
                videoElement.currentTime = state.currentTime;
                console.log(`🎯 Pozisyon senkronize: ${state.currentTime.toFixed(1)}s`);
            }
            return;
        }
        
        // Video başlatılacak (SENKRON)
        if (state.isPlaying && state.startTimestamp) {
            const waitTime = state.startTimestamp - now;
            
            if (waitTime > 100) {
                // Henüz başlama zamanı gelmedi - BEKLENİYOR
                console.log(`⏱️ ${(waitTime/1000).toFixed(1)}s sonra başlayacak`);
                showSyncStatus(`⏱️ ${Math.ceil(waitTime/1000)}s sonra başlıyor...`);
                
                // Pozisyonu hemen ayarla
                if (Math.abs(videoElement.currentTime - state.currentTime) > 0.5) {
                    videoElement.currentTime = state.currentTime;
                }
                
                // Videoyu durdur (henüz başlamadı)
                if (!videoElement.paused) {
                    videoElement.pause();
                }
                
                // Timer kur
                if (syncTimeout) clearTimeout(syncTimeout);
                syncTimeout = setTimeout(() => {
                    videoElement.currentTime = state.currentTime;
                    videoElement.play().then(() => {
                        console.log('▶️ Video başlatıldı (SENKRON)');
                        showSyncStatus('');
                    }).catch(err => {
                        console.log('Auto-play engellendi:', err);
                    });
                }, waitTime);
                
            } else if (waitTime > -1000) {
                // Tam şimdi başlamalı (±1 saniye tolerans)
                videoElement.currentTime = state.currentTime;
                videoElement.play().then(() => {
                    console.log('▶️ Video başlatıldı (ANINDA SENKRON)');
                    showSyncStatus('');
                }).catch(err => {
                    console.log('Auto-play engellendi:', err);
                });
                
            } else {
                // Geç kalındı - Gecikmeli başlatma
                const elapsedSeconds = Math.abs(waitTime) / 1000;
                const catchupTime = state.currentTime + elapsedSeconds;
                
                videoElement.currentTime = catchupTime;
                videoElement.play().then(() => {
                    console.log(`▶️ Video başlatıldı (${elapsedSeconds.toFixed(1)}s GECİKMELİ)`);
                    console.log(`   → Hedef: ${state.currentTime.toFixed(1)}s`);
                    console.log(`   → Gerçek: ${catchupTime.toFixed(1)}s`);
                }).catch(err => {
                    console.log('Auto-play engellendi:', err);
                });
            }
        }
    };
    
    roomRef.child('videoState').on('value', videoStateListener);
    
    // İzleyici sayısı değişikliklerini dinle (throttled)
    const throttledViewerUpdate = throttle(() => {
        updateViewerCount();
    }, 5000);
    
    viewersListener = throttledViewerUpdate;
    roomRef.child('viewers').on('value', viewersListener);
    
    // Oda sahibi değişikliklerini dinle
    ownerListener = (snapshot) => {
        const newOwner = snapshot.val();
        if (newOwner === auth.currentUser.uid && !isRoomOwner) {
            isRoomOwner = true;
            console.log('✅ Oda sahipliği size devredildi!');
            alert('🎉 Oda sahipliği size devredildi! Artık video kontrollerini kullanabilirsiniz.');
        }
    };
    
    roomRef.child('owner').on('value', ownerListener);
    
    // YENİ: Urgent update listener (play/pause/seek için)
    urgentUpdateListener = (snapshot) => {
        const update = snapshot.val();
        if (!update) return;
        
        // Eski update'i göz ardı et
        if (update.timestamp <= lastActionTimestamp) {
            console.log('⏭️ Eski urgent update göz ardı edildi');
            return;
        }
        
        lastActionTimestamp = update.timestamp;
        
        console.log('⚡ Urgent update alındı:', update.type);
        
        switch (update.type) {
            case 'play':
                handleUrgentPlay(update.data);
                break;
            case 'pause':
                if (!videoElement.paused) {
                    videoElement.pause();
                }
                if (update.data.currentTime !== undefined) {
                    videoElement.currentTime = update.data.currentTime;
                }
                console.log('⏸️ Urgent pause');
                break;
            case 'seek':
                videoElement.currentTime = update.data.currentTime;
                if (update.data.shouldPlay) {
                    handleUrgentPlay(update.data);
                }
                console.log('⏩ Urgent seek');
                break;
        }
    };
    
    roomRef.child('urgentUpdate').on('value', urgentUpdateListener);
    
    console.log('✅ Tam senkron sistem aktif (UPGRADED)');
    console.log('   → Tüm dünya aynı anda başlar');
    console.log('   → Clock drift compensation');
    console.log('   → Urgent update desteği');
    console.log('   → Adaptive buffering');
}

// Throttled versiyon
const updateViewerCount = throttle(function() {
    if (roomRef) {
        roomRef.child('viewers').once('value', (snapshot) => {
            const count = snapshot.val() || 0;
            const viewersCountElement = document.getElementById('viewers-count');
            if (viewersCountElement) {
                viewersCountElement.textContent = count;
            }
        });
    }
}, 5000);

function syncVideoState() {
    if (!roomRef || !videoElement) return;
    
    roomRef.child('videoState').once('value', (snapshot) => {
        const state = snapshot.val();
        if (!state) return;
        
        videoElement.currentTime = state.currentTime;
        
        if (state.isPlaying && videoElement.paused) {
            videoElement.play().catch(err => console.log('Auto-play engellendi:', err));
        } else if (!state.isPlaying && !videoElement.paused) {
            videoElement.pause();
        }
        
        console.log('✅ Video durumu senkronize edildi');
    });
}

console.log('✅ Firebase senkronizasyon sistemi yüklendi (UPGRADED)');
console.log('   → Clock drift compensation');
console.log('   → Listener cleanup sistemi');
console.log('   → Urgent update sistemi');
console.log('   → Adaptive buffering');