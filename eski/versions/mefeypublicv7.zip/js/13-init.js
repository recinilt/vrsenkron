// ============================================
// BAŞLATMA VE İNİTİALİZATİON - ULTIMATE VERSİYON (MASTER-SLAVE HYBRID)
// ============================================

// Konsol logları
console.log('🎬 VR Sosyal Sinema - Ultimate Versiyon v6.0 (MASTER-SLAVE HYBRID)');
console.log('📍 Yeni Özellikler:');
console.log('   ✅ Master-Slave Hybrid Architecture');
console.log('   ✅ Oda sahibi = Master (tek truth source)');
console.log('   ✅ İzleyiciler = Slave (sync istekleri)');
console.log('   ✅ Local override (anında feedback)');
console.log('   ✅ Bellek sızıntısı tamamen çözüldü');
console.log('   ✅ Eylem kilidi + kuyruk sistemi');
console.log('   ✅ Clock drift compensation (±100ms)');
console.log('   ✅ Predictive sync + adaptive correction');
console.log('   ✅ Urgent update sistemi');
console.log('   ✅ Adaptive buffering (pre-buffer)');
console.log('   ✅ Keyframe interval 10sn → 5sn');
console.log('   ✅ İlk sync hızlandırıldı (0-5sn)');
console.log('⚙️ Özellikler:');
console.log('   • 5 Hafif Sinema Ortamı');
console.log('   • Oda Sahipliği Transferi');
console.log('   • 3 Saniye Tam Senkronizasyon');
console.log('   • Kontrol Modu Seçimi (owner/everyone)');
console.log('   • Şifreli Oda Desteği');
console.log('Firebase:', firebase.app().name ? 'Bağlı ✓' : 'Bağlı Değil ✗');

// DOM yüklendiğinde
document.addEventListener('DOMContentLoaded', () => {
    console.log('✓ DOM yüklendi');
    
    // Clock sync başlat
    startClockSync();
    console.log('✓ Clock sync başlatıldı');
    
    // UI elementlerini al
    uiOverlay = document.getElementById('ui-overlay');
    vrControls = document.getElementById('vr-controls');
    roomInfoDisplay = document.getElementById('room-info-display');
    
    // A-Frame sahne yüklendiğinde
    const scene = document.querySelector('a-scene');
    if (scene) {
        scene.addEventListener('loaded', () => {
            console.log('✓ VR sahnesi yüklendi');
        });
        
        scene.addEventListener('enter-vr', () => {
            console.log('✓ VR moduna girildi');
            hideVRControls();
        });
        
        scene.addEventListener('exit-vr', () => {
            console.log('✓ VR modundan çıkıldı');
            if (currentRoomId) {
                showVRControls();
            }
        });
    }
    
    // Oda listesini yükle
    const roomsListElement = document.getElementById('rooms-list');
    if (roomsListElement) {
        listRooms();
        console.log('✓ Manuel refresh aktif');
    }
    
    // Klavye kısayolları
    document.addEventListener('keydown', (e) => {
        if (!currentRoomId || !videoElement) return;
        
        // Space: Oynat/Duraklat
        if (e.code === 'Space' && e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') {
            e.preventDefault();
            togglePlayPause();
        }
        
        // Arrow keys: İleri/Geri
        if (e.code === 'ArrowRight') {
            e.preventDefault();
            seekVideo(10);
        }
        
        if (e.code === 'ArrowLeft') {
            e.preventDefault();
            seekVideo(-10);
        }
        
        // Arrow Up/Down: Ekran yukarı/aşağı
        if (e.code === 'ArrowUp') {
            e.preventDefault();
            moveScreen('up');
        }
        
        if (e.code === 'ArrowDown') {
            e.preventDefault();
            moveScreen('down');
        }
        
        // WASD: Ekran hareketi
        if (e.code === 'KeyW') moveScreen('up');
        if (e.code === 'KeyS') moveScreen('down');
        if (e.code === 'KeyA') moveScreen('left');
        if (e.code === 'KeyD') moveScreen('right');
        if (e.code === 'KeyQ') moveScreen('backward');
        if (e.code === 'KeyE') moveScreen('forward');
        
        // R: Ekran pozisyonu sıfırla
        if (e.code === 'KeyR') {
            moveScreen('reset');
        }
        
        // M: Sessiz
        if (e.code === 'KeyM') {
            e.preventDefault();
            videoElement.muted = !videoElement.muted;
            console.log('🔇 Sessiz:', videoElement.muted);
        }
        
        // F: Tam ekran
        if (e.code === 'KeyF') {
            e.preventDefault();
            const sceneEl = document.querySelector('a-scene');
            if (sceneEl) {
                if (document.fullscreenElement) {
                    document.exitFullscreen();
                } else {
                    sceneEl.requestFullscreen();
                }
            }
        }
        
        // C: Altyazı aç/kapa
        if (e.code === 'KeyC') {
            e.preventDefault();
            if (subtitleElement) {
                const isVisible = subtitleElement.getAttribute('visible') === 'true';
                subtitleElement.setAttribute('visible', !isVisible);
                console.log('📝 Altyazı:', !isVisible ? 'Açık' : 'Kapalı');
            }
        }
    });
    
    console.log('✓ Tüm event listener\'lar kuruldu');
    console.log('🎮 Klavye Kısayolları:');
    console.log('   Space: Oynat/Duraklat');
    console.log('   ←/→: 10sn Geri/İleri');
    console.log('   ↑/↓ veya W/S: Ekran Yukarı/Aşağı');
    console.log('   A/D: Ekran Sol/Sağ');
    console.log('   Q/E: Ekran İleri/Geri');
    console.log('   R: Ekran Pozisyonu Sıfırla');
    console.log('   C: Altyazı Aç/Kapa');
    console.log('   M: Sessiz');
    console.log('   F: Tam Ekran');
});

// Sayfa kapatılmadan önce - TAM TEMİZLİK (GÜNCELLENMIŞ)
window.addEventListener('beforeunload', () => {
    console.log('👋 Sayfa kapatılıyor, tam temizlik yapılıyor...');
    
    // Clock sync temizle
    if (clockSyncInterval) {
        clearInterval(clockSyncInterval);
        clockSyncInterval = null;
        console.log('✅ Clock sync interval temizlendi');
    }
    
    // Listener'ları temizle
    cleanupListeners();
    
    // YENİ: Local override temizle
    if (localOverride) {
        localOverride = null;
        console.log('✅ Local override temizlendi');
    }
    
    if (localOverrideTimeout) {
        clearTimeout(localOverrideTimeout);
        localOverrideTimeout = null;
        console.log('✅ Local override timeout temizlendi');
    }
    
    // Keyframe sistemini durdur
    stopKeyframeSystem();
    
    // Presence temizle
    if (viewerPresenceRef) {
        viewerPresenceRef.off();
        viewerPresenceRef = null;
    }
    
    // RoomRef temizle
    if (roomRef) {
        roomRef.off();
        roomRef = null;
    }
    
    // Video elementi temizle
    if (videoElement) {
        videoElement.pause();
        videoElement.src = '';
        videoElement = null;
    }
    
    // Interval'ları temizle
    if (vrSeekBarInterval) {
        clearInterval(vrSeekBarInterval);
        vrSeekBarInterval = null;
        console.log('✅ VR seek bar interval temizlendi');
    }
    
    if (subtitleUpdateInterval) {
        clearInterval(subtitleUpdateInterval);
        subtitleUpdateInterval = null;
        console.log('✅ Subtitle interval temizlendi');
    }
    
    // Altyazı temizle
    removeSubtitle();
    
    console.log('✅ Tam temizlik tamamlandı');
});

// Hata yakalama
window.addEventListener('error', (e) => {
    console.error('❌ Global hata:', e.message, e.filename, e.lineno);
});

window.addEventListener('unhandledrejection', (e) => {
    console.error('❌ Promise hatası:', e.reason);
});

console.log('✅ Uygulama başlatıldı - Ultimate Versiyon v6.0 (MASTER-SLAVE) - Hazır! 🚀');
console.log('✅ Tüm optimizasyonlar aktif!');
console.log('✅ Master-Slave Hybrid Architecture aktif!');