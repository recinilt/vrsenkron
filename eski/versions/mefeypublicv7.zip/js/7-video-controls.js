// ============================================
// VİDEO KONTROL FONKSİYONLARI - MASTER-SLAVE HYBRID
// ============================================

// Debounce için son tıklama zamanı
let lastSeekTime = 0;
let seekDebounceTimeout = null;
const SEEK_DEBOUNCE_DELAY = 2000;
const SEEK_REWIND_SECONDS = 4;

function canControlVideo() {
    if (!currentRoomData) return false;
    
    if (currentRoomData.controlMode === 'everyone') {
        return true;
    }
    
    return isRoomOwner;
}

// ============================================
// YENİ: MASTER EXECUTE (Sadece Oda Sahibi Firebase'e Yazar)
// ============================================

async function masterExecuteAction(actionType, actionData) {
    if (!isRoomOwner) {
        console.error('❌ Sadece oda sahibi masterExecuteAction çağırabilir!');
        return;
    }
    
    if (actionLock) {
        console.log('⏳ Master aksiyon kuyruğa eklendi:', actionType);
        actionQueue = actionQueue.filter(a => a.type !== actionType);
        actionQueue.push({ type: actionType, data: actionData });
        return;
    }
    
    actionLock = true;
    lastActionTimestamp = getAdjustedTime();
    
    try {
        await roomRef.child('videoState').update(actionData);
        console.log('✅ Master aksiyon tamamlandı:', actionType);
        
        await new Promise(resolve => setTimeout(resolve, 100));
        
    } catch (error) {
        console.error('❌ Master aksiyon hatası:', error);
    } finally {
        actionLock = false;
        
        if (actionQueue.length > 0) {
            const nextAction = actionQueue.shift();
            await masterExecuteAction(nextAction.type, nextAction.data);
        }
    }
}

// ============================================
// YENİ: SLAVE REQUEST (İzleyici Sync İsteği Gönderir)
// ============================================

function slaveRequestSync(requestType, requestData) {
    if (isRoomOwner) {
        console.error('❌ Oda sahibi slaveRequestSync çağıramaz!');
        return;
    }
    
    console.log('📤 Sync isteği gönderiliyor:', requestType, requestData);
    
    roomRef.child('syncRequests').push({
        type: requestType,
        userId: auth.currentUser.uid,
        timestamp: getAdjustedTime(),
        ...requestData
    });
}

// ============================================
// YENİ: BİRLEŞTİRİLMİŞ SEEK FONKSİYONU (MASTER-SLAVE)
// ============================================

function performSeek(getTargetTime) {
    if (!canControlVideo()) {
        alert('⚠️ Bu odada sadece oda sahibi video kontrolü yapabilir!');
        return;
    }
    
    if (!videoElement) {
        alert('Video henüz yüklenmedi!');
        return;
    }
    
    const now = getAdjustedTime();
    
    if (now - lastSeekTime < SEEK_DEBOUNCE_DELAY) {
        clearTimeout(seekDebounceTimeout);
        console.log('⏱️ Seek debounce sıfırlandı');
    }
    
    lastSeekTime = now;
    
    const targetTime = getTargetTime();
    
    if (isRoomOwner) {
        // ============================================
        // ODA SAHİBİ (MASTER): Normal seek + Firebase'e yaz
        // ============================================
        
        videoElement.currentTime = targetTime;
        console.log(`⏩ Master seek (geçici): ${targetTime.toFixed(1)}s`);
        showSyncStatus(`⏩ ${formatTime(targetTime)} (2sn bekleniyor...)`);
        
        seekDebounceTimeout = setTimeout(() => {
            const finalTime = videoElement.currentTime;
            const rewindTime = Math.max(0, finalTime - SEEK_REWIND_SECONDS);
            const startTimestamp = getAdjustedTime() + SYNC_DELAY;
            const wasPlaying = !videoElement.paused;
            
            videoElement.pause();
            videoElement.currentTime = rewindTime;
            
            const actionData = {
                isPlaying: wasPlaying,
                currentTime: rewindTime,
                startTimestamp: wasPlaying ? startTimestamp : null,
                lastUpdate: getAdjustedTime()
            };
            
            masterExecuteAction('seek', actionData).then(() => {
                console.log(`✅ Master seek tamamlandı: ${rewindTime.toFixed(1)}s`);
                
                if (wasPlaying) {
                    showSyncStatus(`⏱️ 3 saniyede ${formatTime(rewindTime)} başlıyor`);
                    
                    // Urgent update gönder
                    roomRef.child('urgentUpdate').set({
                        type: 'seek',
                        data: {
                            currentTime: rewindTime,
                            startTimestamp: startTimestamp,
                            shouldPlay: true
                        },
                        timestamp: getAdjustedTime()
                    });
                } else {
                    showSyncStatus(`✅ Senkronize: ${formatTime(rewindTime)}`);
                }
            });
        }, SEEK_DEBOUNCE_DELAY);
        
    } else {
        // ============================================
        // İZLEYİCİ (SLAVE): Local seek + sync isteği gönder
        // ============================================
        
        // Local override kaydet
        if (localOverrideTimeout) {
            clearTimeout(localOverrideTimeout);
        }
        
        localOverride = {
            type: 'seek',
            targetTime: targetTime,
            timestamp: getAdjustedTime()
        };
        
        videoElement.currentTime = targetTime;
        console.log(`⏩ Slave seek (local): ${targetTime.toFixed(1)}s`);
        showSyncStatus(`⏩ ${formatTime(targetTime)} (senkronize ediliyor...)`);
        
        seekDebounceTimeout = setTimeout(() => {
            const finalTime = videoElement.currentTime;
            
            // Sync isteği gönder
            slaveRequestSync('seek', {
                targetTime: finalTime
            });
            
            console.log(`📤 Slave sync isteği gönderildi: ${finalTime.toFixed(1)}s`);
            
            // 5 saniye sonra local override'ı temizle
            localOverrideTimeout = setTimeout(() => {
                if (localOverride && localOverride.type === 'seek') {
                    console.log('⏱️ Local override timeout (5sn)');
                    localOverride = null;
                }
            }, 5000);
        }, SEEK_DEBOUNCE_DELAY);
    }
}

function seekVideo(seconds) {
    performSeek(() => {
        return Math.max(0, Math.min(videoElement.duration, videoElement.currentTime + seconds));
    });
}

function seekToPosition(percentage) {
    performSeek(() => {
        return videoElement.duration * percentage;
    });
}

// ============================================
// GÜNCELLENMÄ°Åž: PLAY/PAUSE (MASTER-SLAVE)
// ============================================

function togglePlayPause() {
    if (!canControlVideo()) {
        alert('⚠️ Bu odada sadece oda sahibi video kontrolü yapabilir!');
        return;
    }
    
    if (!videoElement) {
        alert('Video henüz yüklenmedi!');
        return;
    }
    
    const willPlay = videoElement.paused;
    
    if (isRoomOwner) {
        // ============================================
        // ODA SAHİBİ (MASTER)
        // ============================================
        
        if (willPlay) {
            const startTimestamp = getAdjustedTime() + SYNC_DELAY;
            
            const actionData = {
                isPlaying: true,
                currentTime: videoElement.currentTime,
                startTimestamp: startTimestamp,
                lastUpdate: getAdjustedTime()
            };
            
            showSyncStatus('⏱️ 3 saniye sonra başlıyor...');
            console.log('▶️ Master play: 3 saniye sonra başlatılacak');
            
            // Urgent update gönder
            roomRef.child('urgentUpdate').set({
                type: 'play',
                data: {
                    currentTime: videoElement.currentTime,
                    startTimestamp: startTimestamp
                },
                timestamp: getAdjustedTime()
            });
            
            masterExecuteAction('play', actionData);
        } else {
            videoElement.pause();
            
            const actionData = {
                isPlaying: false,
                currentTime: videoElement.currentTime,
                startTimestamp: null,
                lastUpdate: getAdjustedTime()
            };
            
            console.log('⏸️ Master pause');
            
            // Urgent update gönder
            roomRef.child('urgentUpdate').set({
                type: 'pause',
                data: {
                    currentTime: videoElement.currentTime
                },
                timestamp: getAdjustedTime()
            });
            
            masterExecuteAction('pause', actionData);
        }
        
    } else {
        // ============================================
        // İZLEYİCİ (SLAVE)
        // ============================================
        
        // Local override
        if (localOverrideTimeout) {
            clearTimeout(localOverrideTimeout);
        }
        
        localOverride = {
            type: willPlay ? 'play' : 'pause',
            timestamp: getAdjustedTime()
        };
        
        if (willPlay) {
            console.log('▶️ Slave play (local)');
            showSyncStatus('⏱️ Senkronize ediliyor...');
        } else {
            videoElement.pause();
            console.log('⏸️ Slave pause (local)');
            showSyncStatus('⏸️ Senkronize ediliyor...');
        }
        
        // Sync isteği gönder
        slaveRequestSync(willPlay ? 'play' : 'pause', {
            currentTime: videoElement.currentTime
        });
        
        // 5 saniye sonra local override temizle
        localOverrideTimeout = setTimeout(() => {
            if (localOverride) {
                console.log('⏱️ Local override timeout (5sn)');
                localOverride = null;
            }
        }, 5000);
    }
}

function stopVideo() {
    if (!canControlVideo()) {
        alert('⚠️ Bu odada sadece oda sahibi video kontrolü yapabilir!');
        return;
    }
    
    if (!videoElement) {
        alert('Video henüz yüklenmedi!');
        return;
    }
    
    if (isRoomOwner) {
        // ODA SAHİBİ (MASTER)
        videoElement.pause();
        videoElement.currentTime = 0;
        
        const actionData = {
            isPlaying: false,
            currentTime: 0,
            startTimestamp: null,
            lastUpdate: getAdjustedTime()
        };
        
        console.log('⏹ Master stop');
        showSyncStatus('⏹ Video başa sarıldı');
        
        masterExecuteAction('stop', actionData);
        
    } else {
        // İZLEYİCİ (SLAVE)
        videoElement.pause();
        videoElement.currentTime = 0;
        
        localOverride = {
            type: 'stop',
            timestamp: getAdjustedTime()
        };
        
        console.log('⏹ Slave stop (local)');
        showSyncStatus('⏹ Senkronize ediliyor...');
        
        slaveRequestSync('stop', { currentTime: 0 });
        
        if (localOverrideTimeout) {
            clearTimeout(localOverrideTimeout);
        }
        
        localOverrideTimeout = setTimeout(() => {
            localOverride = null;
        }, 5000);
    }
}

function setPlaybackRate(rate) {
    if (!videoElement) {
        alert('Video henüz yüklenmedi!');
        return;
    }
    
    videoElement.playbackRate = rate;
    console.log('🎚️ Oynatma hızı:', rate);
}

function formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}

console.log('✓ Video kontrol fonksiyonları yüklendi (Master-Slave Hybrid)');
console.log('   → Master: Oda sahibi Firebase\'e yazar');
console.log('   → Slave: İzleyiciler local + sync isteği');
console.log('   → Local override: 5sn timeout');
console.log('   → Tek truth source: Oda sahibi');