// ============================================
// HİBRİT SENKRONİZASYON SİSTEMİ (UPGRADED + FIXED + THROTTLE)
// ============================================

const KEYFRAME_INTERVAL = 5000;
const MAX_DRIFT = 2.0;

let lastKeyframeTime = 0;
let keyframeSendInterval = null;

// YENİ: Agresif throttle
let lastKeyframeSent = 0;
const KEYFRAME_THROTTLE = 1000;  // 1 saniyede max 1 keyframe

// ============================================
// PREDİCTİVE SYNC + ADAPTİVE CORRECTİON
// ============================================

function syncToKeyframe(keyframe) {
    if (!videoElement || !keyframe) return;
    
    const now = getAdjustedTime();
    const latency = now - keyframe.timestamp;
    
    // TAHMİNİ ZAMAN (Extrapolation)
    let expectedTime = keyframe.currentTime;
    
    if (keyframe.isPlaying) {
        const playbackRate = keyframe.playbackRate || 1.0;
        expectedTime += (latency / 1000) * playbackRate;
        
        console.log('🎯 Predictive sync:', {
            keyframeTime: keyframe.currentTime.toFixed(2),
            latency: latency + 'ms',
            expectedTime: expectedTime.toFixed(2)
        });
    }
    
    // KAYMA HESAPLAMA
    const drift = Math.abs(expectedTime - videoElement.currentTime);
    
    console.log('📊 Drift:', drift.toFixed(2), 'saniye');
    
    // ADAPTİF DÜZELTME
    if (drift > 5) {
        // BÜYÜK KAYMA - Anında düzelt
        console.log('⚡ Büyük kayma, anında düzelt');
        videoElement.currentTime = expectedTime;
        
        if (keyframe.isPlaying && videoElement.paused) {
            videoElement.play().catch(err => console.log('Auto-play engellendi:', err));
        } else if (!keyframe.isPlaying && !videoElement.paused) {
            videoElement.pause();
        }
        
    } else if (drift > 1) {
        // ORTA KAYMA - Playback rate ile yumuşak düzelt
        console.log('🎚️ Orta kayma, playback rate düzelt');
        
        const baseRate = keyframe.playbackRate || 1.0;
        
        if (expectedTime > videoElement.currentTime) {
            videoElement.playbackRate = baseRate * 1.05;
            console.log('   → Hızlandırma: x1.05');
        } else {
            videoElement.playbackRate = baseRate * 0.95;
            console.log('   → Yavaşlatma: x0.95');
        }
        
        setTimeout(() => {
            videoElement.playbackRate = baseRate;
            console.log('✅ Normal playback rate geri yüklendi');
        }, 2000);
        
        if (keyframe.isPlaying && videoElement.paused) {
            videoElement.play().catch(err => console.log('Auto-play engellendi:', err));
        }
        
    } else if (drift > 0.5) {
        console.log('✓ Küçük kayma, play/pause kontrol');
        
        if (keyframe.isPlaying && videoElement.paused) {
            videoElement.play().catch(err => console.log('Auto-play engellendi:', err));
        } else if (!keyframe.isPlaying && !videoElement.paused) {
            videoElement.pause();
        }
    }
    
    lastKeyframeTime = keyframe.timestamp;
}

// ============================================
// FIXED: KEYFRAME GÖNDERME (Agresif Throttle)
// ============================================

function sendKeyframe() {
    if (!isRoomOwner || !videoElement || !roomRef) return;
    
    // Video metadata hazır değilse bekle
    if (!videoElement.duration || isNaN(videoElement.duration)) {
        console.log('⏳ Video metadata henüz hazır değil, keyframe atlanıyor');
        return;
    }
    
    // ✅ YENİ: Agresif throttle (1 saniyede max 1 keyframe)
    const now = Date.now();
    if (now - lastKeyframeSent < KEYFRAME_THROTTLE) {
        console.log('⏭️ Keyframe throttle (1sn dolmadı)');
        return;
    }
    
    lastKeyframeSent = now;
    
    const keyframe = {
        isPlaying: !videoElement.paused,
        currentTime: videoElement.currentTime,
        playbackRate: videoElement.playbackRate,
        timestamp: getAdjustedTime(),
        duration: videoElement.duration
    };
    
    roomRef.child('currentKeyframe').set(keyframe);
    console.log('📤 Keyframe gönderildi:', keyframe.currentTime.toFixed(1) + 's');
}

function startKeyframeSystem() {
    if (!isRoomOwner) {
        console.log('📡 Keyframe listener başlatıldı (izleyici modu)');
        
        keyframeListener = roomRef.child('currentKeyframe').on('value', (snapshot) => {
            const keyframe = snapshot.val();
            if (keyframe) {
                syncToKeyframe(keyframe);
            }
        });
        return;
    }
    
    console.log('📡 Keyframe sender başlatıldı (oda sahibi modu)');
    
    if (keyframeSendInterval) {
        clearInterval(keyframeSendInterval);
    }
    
    keyframeSendInterval = setInterval(sendKeyframe, KEYFRAME_INTERVAL);
    
    console.log('⏱️ İlk keyframe 5 saniye sonra gönderilecek (metadata bekleniyor)');
}

function stopKeyframeSystem() {
    if (keyframeSendInterval) {
        clearInterval(keyframeSendInterval);
        keyframeSendInterval = null;
        console.log('⏹️ Keyframe sender durduruldu');
    }
    
    if (keyframeListener && roomRef) {
        roomRef.child('currentKeyframe').off('value', keyframeListener);
        keyframeListener = null;
        console.log('⏹️ Keyframe listener durduruldu');
    }
}

console.log('✅ Hibrit senkronizasyon sistemi yüklendi (UPGRADED + FIXED + THROTTLE)');
console.log('   → Keyframe interval: 5 saniye');
console.log('   → Keyframe throttle: 1 saniye (agresif)');
console.log('   → İlk keyframe: Metadata hazır olunca');
console.log('   → NaN koruması: Aktif');
console.log('   → Predictive sync (extrapolation)');
console.log('   → Adaptive correction (playback rate)');
console.log('   → Clock drift compensation');