// ============================================
// VİDEO KONTROL FONKSİYONLARI - MASTER-SLAVE HYBRID (FIXED)
// ============================================

let lastSeekTime = 0;
let seekDebounceTimeout = null;
const SEEK_DEBOUNCE_DELAY = 2000;
const SEEK_REWIND_SECONDS = 4;

function canControlVideo() {
    if (!currentRoomData) return false;
    
    if (currentRoomData.controlMode === 'everyone') {
        return true;
    }
    
    return isRoomOwner;
}

// ============================================
// MASTER EXECUTE (Source Tracking ile)
// ============================================

async function masterExecuteAction(actionType, actionData) {
    if (!isRoomOwner) {
        console.error('❌ Sadece oda sahibi masterExecuteAction çağırabilir!');
        return;
    }
    
    if (actionLock) {
        console.log('⏳ Master aksiyon kuyruğa eklendi:', actionType);
        actionQueue = actionQueue.filter(a => a.type !== actionType);
        actionQueue.push({ type: actionType, data: actionData });
        return;
    }
    
    actionLock = true;
    lastActionTimestamp = getAdjustedTime();
    
    try {
        // ✅ YENİ: Kendi update'imizi ignore et
        ignoreNextVideoStateUpdate = true;
        
        await roomRef.child('videoState').update(actionData);
        console.log('✅ Master aksiyon tamamlandı:', actionType);
        
        await new Promise(resolve => setTimeout(resolve, 200));
        
    } catch (error) {
        console.error('❌ Master aksiyon hatası:', error);
    } finally {
        ignoreNextVideoStateUpdate = false;
        actionLock = false;
        
        if (actionQueue.length > 0) {
            const nextAction = actionQueue.shift();
            await masterExecuteAction(nextAction.type, nextAction.data);
        }
    }
}

// ============================================
// SLAVE REQUEST
// ============================================

function slaveRequestSync(requestType, requestData) {
    if (isRoomOwner) {
        console.error('❌ Oda sahibi slaveRequestSync çağıramaz!');
        return;
    }
    
    console.log('📤 Sync isteği gönderiliyor:', requestType, requestData);
    
    roomRef.child('syncRequests').push({
        type: requestType,
        userId: auth.currentUser.uid,
        timestamp: getAdjustedTime(),
        ...requestData
    });
}

// ============================================
// SEEK FONKSİYONU (Urgent Update Kaldırıldı)
// ============================================

function performSeek(getTargetTime) {
    if (!canControlVideo()) {
        alert('⚠️ Bu odada sadece oda sahibi video kontrolü yapabilir!');
        return;
    }
    
    if (!videoElement) {
        alert('Video henüz yüklenmedi!');
        return;
    }
    
    const now = getAdjustedTime();
    
    if (now - lastSeekTime < SEEK_DEBOUNCE_DELAY) {
        clearTimeout(seekDebounceTimeout);
        console.log('⏱️ Seek debounce sıfırlandı');
    }
    
    lastSeekTime = now;
    
    const targetTime = getTargetTime();
    
    if (isRoomOwner) {
        // ODA SAHİBİ (MASTER)
        videoElement.currentTime = targetTime;
        console.log(`⏩ Master seek (geçici): ${targetTime.toFixed(1)}s`);
        showSyncStatus(`⏩ ${formatTime(targetTime)} (2sn bekleniyor...)`);
        
        seekDebounceTimeout = setTimeout(() => {
            const finalTime = videoElement.currentTime;
            const rewindTime = Math.max(0, finalTime - SEEK_REWIND_SECONDS);
            const startTimestamp = getAdjustedTime() + SYNC_DELAY;
            const wasPlaying = !videoElement.paused;
            
            videoElement.pause();
            videoElement.currentTime = rewindTime;
            
            const actionData = {
                isPlaying: wasPlaying,
                currentTime: rewindTime,
                startTimestamp: wasPlaying ? startTimestamp : null,
                lastUpdate: getAdjustedTime()
            };
            
            masterExecuteAction('seek', actionData).then(() => {
                console.log(`✅ Master seek tamamlandı: ${rewindTime.toFixed(1)}s`);
                
                if (wasPlaying) {
                    showSyncStatus(`⏱️ 3 saniyede ${formatTime(rewindTime)} başlıyor`);
                } else {
                    showSyncStatus(`✅ Senkronize: ${formatTime(rewindTime)}`);
                }
                
                // ❌ KALDIRILDI: Urgent update (gereksiz çift update)
            });
        }, SEEK_DEBOUNCE_DELAY);
        
    } else {
        // İZLEYİCİ (SLAVE)
        if (localOverrideTimeout) {
            clearTimeout(localOverrideTimeout);
        }
        
        localOverride = {
            type: 'seek',
            targetTime: targetTime,
            timestamp: getAdjustedTime()
        };
        
        videoElement.currentTime = targetTime;
        console.log(`⏩ Slave seek (local): ${targetTime.toFixed(1)}s`);
        showSyncStatus(`⏩ ${formatTime(targetTime)} (senkronize ediliyor...)`);
        
        seekDebounceTimeout = setTimeout(() => {
            const finalTime = videoElement.currentTime;
            
            slaveRequestSync('seek', {
                targetTime: finalTime
            });
            
            console.log(`📤 Slave sync isteği gönderildi: ${finalTime.toFixed(1)}s`);
            
            localOverrideTimeout = setTimeout(() => {
                if (localOverride && localOverride.type === 'seek') {
                    console.log('⏱️ Local override timeout (5sn)');
                    localOverride = null;
                }
            }, 5000);
        }, SEEK_DEBOUNCE_DELAY);
    }
}

function seekVideo(seconds) {
    performSeek(() => {
        return Math.max(0, Math.min(videoElement.duration, videoElement.currentTime + seconds));
    });
}

function seekToPosition(percentage) {
    performSeek(() => {
        return videoElement.duration * percentage;
    });
}

// ============================================
// PLAY/PAUSE (Urgent Update Kaldırıldı)
// ============================================

function togglePlayPause() {
    if (!canControlVideo()) {
        alert('⚠️ Bu odada sadece oda sahibi video kontrolü yapabilir!');
        return;
    }
    
    if (!videoElement) {
        alert('Video henüz yüklenmedi!');
        return;
    }
    
    const willPlay = videoElement.paused;
    
    if (isRoomOwner) {
        // ODA SAHİBİ (MASTER)
        if (willPlay) {
            const startTimestamp = getAdjustedTime() + SYNC_DELAY;
            
            const actionData = {
                isPlaying: true,
                currentTime: videoElement.currentTime,
                startTimestamp: startTimestamp,
                lastUpdate: getAdjustedTime()
            };
            
            showSyncStatus('⏱️ 3 saniye sonra başlıyor...');
            console.log('▶️ Master play: 3 saniye sonra başlatılacak');
            
            // ❌ KALDIRILDI: Urgent update (gereksiz çift update)
            
            masterExecuteAction('play', actionData);
        } else {
            videoElement.pause();
            
            const actionData = {
                isPlaying: false,
                currentTime: videoElement.currentTime,
                startTimestamp: null,
                lastUpdate: getAdjustedTime()
            };
            
            console.log('⏸️ Master pause');
            
            // ❌ KALDIRILDI: Urgent update (gereksiz çift update)
            
            masterExecuteAction('pause', actionData);
        }
        
    } else {
        // İZLEYİCİ (SLAVE)
        if (localOverrideTimeout) {
            clearTimeout(localOverrideTimeout);
        }
        
        localOverride = {
            type: willPlay ? 'play' : 'pause',
            timestamp: getAdjustedTime()
        };
        
        if (willPlay) {
            console.log('▶️ Slave play (local)');
            showSyncStatus('⏱️ Senkronize ediliyor...');
        } else {
            videoElement.pause();
            console.log('⏸️ Slave pause (local)');
            showSyncStatus('⏸️ Senkronize ediliyor...');
        }
        
        slaveRequestSync(willPlay ? 'play' : 'pause', {
            currentTime: videoElement.currentTime
        });
        
        localOverrideTimeout = setTimeout(() => {
            if (localOverride) {
                console.log('⏱️ Local override timeout (5sn)');
                localOverride = null;
            }
        }, 5000);
    }
}

function stopVideo() {
    if (!canControlVideo()) {
        alert('⚠️ Bu odada sadece oda sahibi video kontrolü yapabilir!');
        return;
    }
    
    if (!videoElement) {
        alert('Video henüz yüklenmedi!');
        return;
    }
    
    if (isRoomOwner) {
        videoElement.pause();
        videoElement.currentTime = 0;
        
        const actionData = {
            isPlaying: false,
            currentTime: 0,
            startTimestamp: null,
            lastUpdate: getAdjustedTime()
        };
        
        console.log('⏹ Master stop');
        showSyncStatus('⏹ Video başa sarıldı');
        
        masterExecuteAction('stop', actionData);
        
    } else {
        videoElement.pause();
        videoElement.currentTime = 0;
        
        localOverride = {
            type: 'stop',
            timestamp: getAdjustedTime()
        };
        
        console.log('⏹ Slave stop (local)');
        showSyncStatus('⏹ Senkronize ediliyor...');
        
        slaveRequestSync('stop', { currentTime: 0 });
        
        if (localOverrideTimeout) {
            clearTimeout(localOverrideTimeout);
        }
        
        localOverrideTimeout = setTimeout(() => {
            localOverride = null;
        }, 5000);
    }
}

function setPlaybackRate(rate) {
    if (!videoElement) {
        alert('Video henüz yüklenmedi!');
        return;
    }
    
    videoElement.playbackRate = rate;
    console.log('🎚️ Oynatma hızı:', rate);
}

function formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}

console.log('✓ Video kontrol fonksiyonları yüklendi (Master-Slave Hybrid + Fixed)');
console.log('   → Master: Oda sahibi Firebase\'e yazar');
console.log('   → Slave: İzleyiciler local + sync isteği');
console.log('   → Urgent update: Kaldırıldı (gereksiz çift update)');
console.log('   → Source tracking: Aktif (loop önleme)');
console.log('   → Tek truth source: Oda sahibi');