// ============================================
// FİREBASE SENKRONİZASYON SİSTEMİ - MASTER-SLAVE HYBRID (FIXED v2)
// ============================================

// ============================================
// LISTENER TEMİZLEME
// ============================================

function cleanupListeners() {
    if (!roomRef) return;
    
    if (videoStateListener) {
        roomRef.child('videoState').off('value', videoStateListener);
        videoStateListener = null;
        console.log('✅ videoState listener temizlendi');
    }
    
    if (viewersListener) {
        roomRef.child('viewers').off('value', viewersListener);
        viewersListener = null;
        console.log('✅ viewers listener temizlendi');
    }
    
    if (ownerListener) {
        roomRef.child('owner').off('value', ownerListener);
        ownerListener = null;
        console.log('✅ owner listener temizlendi');
    }
    
    if (syncRequestsListener) {
        roomRef.child('syncRequests').off('child_added', syncRequestsListener);
        syncRequestsListener = null;
        console.log('✅ syncRequests listener temizlendi');
    }
    
    console.log('✅ Tüm listener\'lar temizlendi');
}

// ============================================
// ADAPTIVE BUFFERING
// ============================================

function handleScheduledPlay(currentTime, startTimestamp) {
    if (!videoElement) return;
    
    const now = getAdjustedTime();
    const delay = startTimestamp - now;
    
    console.log('▶️ Scheduled play:', {
        delay: delay + 'ms',
        targetTime: currentTime.toFixed(2)
    });
    
    if (delay > 1000) {
        // Pre-buffer
        videoElement.currentTime = currentTime;
        
        videoElement.play().then(() => {
            videoElement.pause();
            
            let countdown = Math.ceil(delay / 1000);
            const countdownInterval = setInterval(() => {
                countdown--;
                if (countdown > 0) {
                    showSyncStatus(`⏳ ${countdown}sn sonra başlıyor...`);
                } else {
                    clearInterval(countdownInterval);
                }
            }, 1000);
            
            setTimeout(() => {
                videoElement.currentTime = currentTime;
                videoElement.play().then(() => {
                    console.log('✅ Pre-buffered play başladı');
                    showSyncStatus('');
                }).catch(err => {
                    console.log('Play hatası:', err);
                });
            }, delay);
        }).catch(err => {
            console.log('Pre-buffer başarısız:', err);
            setTimeout(() => {
                videoElement.currentTime = currentTime;
                videoElement.play().catch(e => console.log('Fallback play hatası:', e));
            }, Math.max(0, delay));
        });
        
    } else if (delay > 0) {
        setTimeout(() => {
            videoElement.currentTime = currentTime;
            videoElement.play().catch(err => console.log('Play hatası:', err));
        }, delay);
    } else {
        const catchupTime = currentTime + Math.abs(delay) / 1000;
        videoElement.currentTime = catchupTime;
        videoElement.play().catch(err => console.log('Catch-up play hatası:', err));
        console.log('⚡ Catch-up play:', catchupTime.toFixed(2));
    }
}

// ============================================
// MASTER - SYNC REQUEST HANDLER
// ============================================

function handleSyncRequest(requestData) {
    if (!isRoomOwner) {
        console.error('❌ Sadece oda sahibi sync isteklerini işleyebilir!');
        return;
    }
    
    if (!videoElement) return;
    
    console.log('📨 Sync isteği işleniyor:', requestData.type, 'from user:', requestData.userId);
    
    switch (requestData.type) {
        case 'seek':
            const targetTime = requestData.targetTime;
            videoElement.currentTime = targetTime;
            
            setTimeout(() => {
                const finalTime = videoElement.currentTime;
                const rewindTime = Math.max(0, finalTime - SEEK_REWIND_SECONDS);
                const startTimestamp = getAdjustedTime() + SYNC_DELAY;
                const wasPlaying = !videoElement.paused;
                
                videoElement.pause();
                videoElement.currentTime = rewindTime;
                
                const actionData = {
                    isPlaying: wasPlaying,
                    currentTime: rewindTime,
                    startTimestamp: wasPlaying ? startTimestamp : null,
                    lastUpdate: getAdjustedTime()
                };
                
                masterExecuteAction('seek', actionData).then(() => {
                    console.log('✅ Master sync isteği tamamlandı (seek)');
                });
            }, 100);
            break;
            
        case 'play':
            const playStartTimestamp = getAdjustedTime() + SYNC_DELAY;
            
            const playActionData = {
                isPlaying: true,
                currentTime: requestData.currentTime || videoElement.currentTime,
                startTimestamp: playStartTimestamp,
                lastUpdate: getAdjustedTime()
            };
            
            masterExecuteAction('play', playActionData).then(() => {
                console.log('✅ Master sync isteği tamamlandı (play)');
            });
            break;
            
        case 'pause':
            videoElement.pause();
            
            const pauseActionData = {
                isPlaying: false,
                currentTime: requestData.currentTime || videoElement.currentTime,
                startTimestamp: null,
                lastUpdate: getAdjustedTime()
            };
            
            masterExecuteAction('pause', pauseActionData).then(() => {
                console.log('✅ Master sync isteği tamamlandı (pause)');
            });
            break;
            
        case 'stop':
            videoElement.pause();
            videoElement.currentTime = 0;
            
            const stopActionData = {
                isPlaying: false,
                currentTime: 0,
                startTimestamp: null,
                lastUpdate: getAdjustedTime()
            };
            
            masterExecuteAction('stop', stopActionData).then(() => {
                console.log('✅ Master sync isteği tamamlandı (stop)');
            });
            break;
    }
}

// ============================================
// LISTENER'LARI KURMA (FIXED v2 - Master Play Fix)
// ============================================

function listenToRoomUpdates() {
    if (!roomRef) return;
    
    cleanupListeners();
    
    // MASTER - Sync Requests Listener
    if (isRoomOwner) {
        syncRequestsListener = roomRef.child('syncRequests').on('child_added', (snapshot) => {
            const request = snapshot.val();
            if (!request) return;
            
            handleSyncRequest(request);
            
            snapshot.ref.remove().catch(err => {
                console.error('Sync request silme hatası:', err);
            });
        });
        
        console.log('✅ Master: Sync requests listener aktif');
    }
    
    // Video State Listener (Tüm Kullanıcılar + Source Tracking)
    videoStateListener = (snapshot) => {
        if (!videoElement) return;
        
        const state = snapshot.val();
        if (!state) return;
        
        // ✅ FIX: Master sadece timestamp kontrolü yapar, play logic'i çalıştırır
        if (isRoomOwner && ignoreNextVideoStateUpdate) {
            console.log('⏭️ Kendi update\'im, timestamp kontrolü atlanıyor (master)');
            ignoreNextVideoStateUpdate = false;
            // ❌ RETURN YAPMA! Play logic'i çalışmalı
        }
        
        // Local override varsa ve yeni update gelirse temizle
        if (localOverride && state.lastUpdate > localOverride.timestamp) {
            console.log('✅ Local override temizlendi (master sync alındı)');
            localOverride = null;
            
            if (localOverrideTimeout) {
                clearTimeout(localOverrideTimeout);
                localOverrideTimeout = null;
            }
        }
        
        // Eski update kontrolü (sadece slave için)
        if (!isRoomOwner && state.lastUpdate && state.lastUpdate <= lastActionTimestamp) {
            console.log('⏭️ Eski update göz ardı edildi (slave)');
            return;
        }
        
        if (state.lastUpdate) {
            lastActionTimestamp = state.lastUpdate;
        }
        
        const now = getAdjustedTime();
        
        // Video durduruldu
        if (!state.isPlaying) {
            if (!videoElement.paused) {
                videoElement.pause();
                console.log('⏸️ Video durduruldu (sync)');
            }
            
            if (Math.abs(videoElement.currentTime - state.currentTime) > 0.5) {
                videoElement.currentTime = state.currentTime;
                console.log(`🎯 Pozisyon senkronize: ${state.currentTime.toFixed(1)}s`);
            }
            return;
        }
        
        // Video başlatılacak
        if (state.isPlaying && state.startTimestamp) {
            const waitTime = state.startTimestamp - now;
            
            if (waitTime > 100) {
                console.log(`⏱️ ${(waitTime/1000).toFixed(1)}s sonra başlayacak`);
                showSyncStatus(`⏱️ ${Math.ceil(waitTime/1000)}s sonra başlıyor...`);
                
                if (Math.abs(videoElement.currentTime - state.currentTime) > 0.5) {
                    videoElement.currentTime = state.currentTime;
                }
                
                if (!videoElement.paused) {
                    videoElement.pause();
                }
                
                if (syncTimeout) clearTimeout(syncTimeout);
                syncTimeout = setTimeout(() => {
                    videoElement.currentTime = state.currentTime;
                    videoElement.play().then(() => {
                        console.log('▶️ Video başlatıldı (SENKRON)');
                        showSyncStatus('');
                    }).catch(err => {
                        console.log('Auto-play engellendi:', err);
                    });
                }, waitTime);
                
            } else if (waitTime > -1000) {
                videoElement.currentTime = state.currentTime;
                videoElement.play().then(() => {
                    console.log('▶️ Video başlatıldı (ANINDA SENKRON)');
                    showSyncStatus('');
                }).catch(err => {
                    console.log('Auto-play engellendi:', err);
                });
                
            } else {
                const elapsedSeconds = Math.abs(waitTime) / 1000;
                const catchupTime = state.currentTime + elapsedSeconds;
                
                videoElement.currentTime = catchupTime;
                videoElement.play().then(() => {
                    console.log(`▶️ Video başlatıldı (${elapsedSeconds.toFixed(1)}s GECİKMELİ)`);
                }).catch(err => {
                    console.log('Auto-play engellendi:', err);
                });
            }
        }
    };
    
    roomRef.child('videoState').on('value', videoStateListener);
    
    // İzleyici sayısı
    const throttledViewerUpdate = throttle(() => {
        updateViewerCount();
    }, 5000);
    
    viewersListener = throttledViewerUpdate;
    roomRef.child('viewers').on('value', viewersListener);
    
    // Oda sahibi değişiklikleri
    ownerListener = (snapshot) => {
        const newOwner = snapshot.val();
        if (newOwner === auth.currentUser.uid && !isRoomOwner) {
            isRoomOwner = true;
            console.log('✅ Oda sahipliği size devredildi!');
            alert('🎉 Oda sahipliği size devredildi! Artık Master olarak video kontrollerini kullanabilirsiniz.');
            
            if (syncRequestsListener) {
                roomRef.child('syncRequests').off('child_added', syncRequestsListener);
            }
            
            syncRequestsListener = roomRef.child('syncRequests').on('child_added', (snapshot) => {
                const request = snapshot.val();
                if (!request) return;
                
                handleSyncRequest(request);
                snapshot.ref.remove().catch(err => {
                    console.error('Sync request silme hatası:', err);
                });
            });
            
            console.log('✅ Master: Sync requests listener aktif (yeni sahip)');
        }
    };
    
    roomRef.child('owner').on('value', ownerListener);
    
    console.log('✅ Master-Slave Hybrid sistem aktif (Fixed v2)');
    console.log(isRoomOwner ? '   → MASTER MODE (Firebase yazma yetkisi)' : '   → SLAVE MODE (Sync istekleri gönderir)');
}

const updateViewerCount = throttle(function() {
    if (roomRef) {
        roomRef.child('viewers').once('value', (snapshot) => {
            const count = snapshot.val() || 0;
            const viewersCountElement = document.getElementById('viewers-count');
            if (viewersCountElement) {
                viewersCountElement.textContent = count;
            }
        });
    }
}, 5000);

function syncVideoState() {
    if (!roomRef || !videoElement) return;
    
    roomRef.child('videoState').once('value', (snapshot) => {
        const state = snapshot.val();
        if (!state) return;
        
        videoElement.currentTime = state.currentTime;
        
        if (state.isPlaying && videoElement.paused) {
            videoElement.play().catch(err => console.log('Auto-play engellendi:', err));
        } else if (!state.isPlaying && !videoElement.paused) {
            videoElement.pause();
        }
        
        console.log('✅ Video durumu senkronize edildi');
    });
}

console.log('✅ Firebase senkronizasyon sistemi yüklendi (Master-Slave Hybrid + Fixed v2)');
console.log('   → Master: Sync requests listener');
console.log('   → Slave: Local override + sync request');
console.log('   → Urgent update: Kaldırıldı (gereksiz çift update)');
console.log('   → Source tracking: Aktif (loop önleme)');
console.log('   → Master play fix: Aktif');
console.log('   → Adaptive buffering');