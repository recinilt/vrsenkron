// ============================================
// CONFIG - OPTİMİZE EDİLMİŞ VERSİYON
// Öneri 3 + Performance İyileştirmeleri
// ============================================

const firebaseConfig = {
    apiKey: "AIzaSyC60idSLdAiqAjPWAOMaM3g8LAKPGEUwH8",
    authDomain: "vr-sinema.firebaseapp.com",
    databaseURL: "https://vr-sinema-default-rtdb.firebaseio.com",
    projectId: "vr-sinema",
    storageBucket: "vr-sinema.firebasestorage.app",
    messagingSenderId: "724648238300",
    appId: "1:724648238300:web:dceba8c536e8a5ffd96819"
};

firebase.initializeApp(firebaseConfig);

// ============================================
// DEBUG MODU
// ============================================
const DEBUG_MODE = false; // Production: false, Development: true

function debugLog(...args) {
    if (DEBUG_MODE) console.log(...args);
}

// ============================================
// TEMEL SABİTLER
// ============================================
const SYNC_DELAY = 5000; // 5 SANİYE (play başlama gecikmesi)
const KEYFRAME_INTERVAL = 7000; // 7 SANİYE (snapshot aralığı)
const CLOCK_SYNC_INTERVAL = 60000; // 60 SANİYE (saat senkron)
const SEEK_DEBOUNCE_DELAY = 2000; // 2 SANİYE (seek debounce)
const SEEK_REWIND_SECONDS = 2; // 2 SANİYE (4→2 daha az agresif)

// ============================================
// ÖNERİ 3: ADAPTIVE TIER SİSTEMİ
// ============================================
// Tier Eşikleri (milisaniye)
const TIER_1_THRESHOLD = 3000; // 0-3sn: Normal (müdahale yok)
const TIER_2_THRESHOLD = 7000; // 3-7sn: Hafif catch-up
const TIER_3_THRESHOLD = 15000; // 7-15sn: Grup yavaşlama
const TIER_CRITICAL_THRESHOLD = 20000; // 15sn+: Yeniden katıl

// Hız Ayarları
const TIER_2_LAGGING_SPEED = 1.1; // Tier 2: Hafif hızlanma
const TIER_3_GROUP_SPEED = 0.88; // Tier 3: Grup yavaşlama (0.85→0.88 daha yumuşak)
const TIER_3_LAGGING_SPEED = 1.25; // Tier 3: Geride kalan hızlanma (1.3→1.25 daha yumuşak)

// Grup Kontrol
const GROUP_LAGGING_MIN_COUNT = 3; // En az 3 kişi gerideyse grup yavaşlar

// Drift Güncelleme (OPTİMİZE EDİLDİ)
const DRIFT_UPDATE_INTERVAL = 2000; // 2 SANİYE (Firebase'e drift yazma)
const DRIFT_TOLERANCE_MS = 1000; // 500→1000ms (daha az Firebase write)
const DRIFT_TOLERANCE_RATE = 0.1; // 0.05→0.1 (daha az Firebase write)

// ============================================
// ORTAMLAR
// ============================================
const ENVIRONMENTS = {
    'none': { name: 'Ortamsız', preset: null },
    'default': { name: 'Klasik', preset: 'default' },
    'forest': { name: 'Orman', preset: 'forest' },
    'starry': { name: 'Yıldız', preset: 'starry' }
};

// ============================================
// VİDEO SERVİSLERİ
// ============================================
const VIDEO_SERVICES = {
    youtube: {
        pattern: /(youtu\.be\/|youtube\.com\/(watch\?v=|embed\/|v\/|shorts\/))([\w-]{11})/,
        transform: (m) => `https://www.youtube.com/embed/${m[3]}?autoplay=1&controls=1`
    },
    googledrive: {
        pattern: /drive\.google\.com\/(?:file\/d\/|open\?id=)([a-zA-Z0-9_-]+)/,
        transform: (m) => `https://mefeypublicv2.recepyeni.workers.dev/?url=${encodeURIComponent('https://drive.google.com/uc?export=download&id=' + m[1])}`
    },
    direct: {
        pattern: /\.(mp4|webm|ogg|mov|mkv|m3u8|ts)(\?|$)/i,
        transform: (url) => url
    }
};

// ============================================
// VR UI AYARLARI
// ============================================
const VR_UI_CONFIG = {
    position: { x: -5, y: 1.6, z: -3 },
    rotation: { x: 0, y: 90, z: 0 },
    scale: 0.7,
    buttonSize: 0.28,
    seekBarWidth: 1.8
};

// ============================================
// GLOBAL DEĞİŞKENLER
// ============================================
let database = firebase.database();
let auth = firebase.auth();
let roomsRef = database.ref('rooms');
let roomRef = null;
let videoElement = null;
let currentRoomId = null;
let currentRoomData = null;
let isRoomOwner = false;
let currentEnvironment = 'default';

// SYNC
let clockOffset = 0;
let clockSyncReady = false;
let keyframeInterval = null;
let lastKeyframeTimestamp = 0;
let syncTimeout = null;
let lastSeekTime = 0;
let seekDebounceTimeout = null;

// ÖNERİ 3: Drift Tracking
let driftUpdateInterval = null;
let lastDrift = 0;
let lastPlaybackRate = 1.0;

// UI
let subtitleElement = null;
let subtitleData = null;
let screenPosition = { x: 0, y: 2, z: -10 };

// ============================================
// LISTENER REFERANSLARI (CLEANUP İÇİN)
// ============================================
let clockSyncInterval = null;
let videoStateListener = null;
let urgentUpdatesListener = null;
let keyframesListener = null;
let requestsListener = null;
let presenceListener = null;
let seekBarUpdateInterval = null;
let lastSyncDisableTime = 0;


debugLog('✅ Config yüklendi: Optimize Edilmiş Versiyon');
debugLog('📊 Tier 1: 0-3sn | Tier 2: 3-7sn | Tier 3: 7-15sn | Critical: 15sn+');
debugLog('🔧 DEBUG_MODE:', DEBUG_MODE);
