// ============================================
// BAŞLATMA VE İNİTİALİZATİON - ULTIMATE VERSİYON
// ============================================

// Konsol logları
console.log('🎬 VR Sosyal Sinema - Ultimate Versiyon v4.0');
console.log('📍 Yeni Özellikler:');
console.log('   ✅ Çok formatlı video desteği (mp4, webm, ogg, mkv, avi, vb.)');
console.log('   ✅ Altyazı desteği (SRT, VTT, ASS, SSA)');
console.log('   ✅ VR\'da sol tarafta kontrol paneli');
console.log('   ✅ Ekranı hareket ettirme butonları');
console.log('   ✅ VR\'da seek bar ve video kontrolleri');
console.log('   ✅ YouTube API entegrasyonu');
console.log('   ✅ Google Drive video desteği');
console.log('⚙️ Özellikler:');
console.log('   • 5 Hafif Sinema Ortamı');
console.log('   • Oda Sahipliği Transferi');
console.log('   • 1 Saniye Tam Senkronizasyon');
console.log('   • Kontrol Modu Seçimi');
console.log('   • Şifreli Oda Desteği');
console.log('Firebase:', firebase.app().name ? 'Bağlı ✓' : 'Bağlı Değil ✗');

// DOM yüklendiğinde
document.addEventListener('DOMContentLoaded', () => {
    console.log('✓ DOM yüklendi');
    
    // UI elementlerini al
    uiOverlay = document.getElementById('ui-overlay');
    vrControls = document.getElementById('vr-controls');
    roomInfoDisplay = document.getElementById('room-info-display');
    
    // A-Frame sahne yüklendiğinde
    const scene = document.querySelector('a-scene');
    if (scene) {
        scene.addEventListener('loaded', () => {
            console.log('✓ VR sahnesi yüklendi');
        });
        
        scene.addEventListener('enter-vr', () => {
            console.log('✓ VR moduna girildi');
            hideVRControls();
            // VR UI Panel zaten görünür
        });
        
        scene.addEventListener('exit-vr', () => {
            console.log('✓ VR modundan çıkıldı');
            if (currentRoomId) {
                showVRControls();
            }
        });
    }
    
    // Oda listesini yükle
    const roomsListElement = document.getElementById('rooms-list');
    if (roomsListElement) {
        listRooms();
        console.log('✓ Manuel refresh aktif');
    }
    
    console.log('✓ Tüm event listener\'lar kuruldu');
});

// Sayfa kapatılmadan önce
window.addEventListener('beforeunload', () => {
    if (viewerPresenceRef) {
        viewerPresenceRef.off();
    }
    
    if (roomRef) {
        roomRef.off();
    }
    
    // Video elementi temizle
    if (videoElement) {
        videoElement.pause();
        videoElement.src = '';
    }
    
    // Altyazı temizle
    removeSubtitle();
    
    console.log('👋 Bağlantı kesiliyor...');
});

// Hata yakalama
window.addEventListener('error', (e) => {
    console.error('❌ Global hata:', e.message, e.filename, e.lineno);
});

window.addEventListener('unhandledrejection', (e) => {
    console.error('❌ Promise hatası:', e.reason);
});

// ============================================
// OTOMATİK TEMİZLEME SİSTEMİ
// ============================================
let consoleLogCount = 0;
const originalConsoleLog = console.log;
const MAX_CONSOLE_LOGS = 1000;

// Console.log sayacı
console.log = function(...args) {
    consoleLogCount++;
    originalConsoleLog.apply(console, args);
};

// Her 2 dakikada bir temizlik
setInterval(() => {
    // Console temizleme
    if (consoleLogCount > MAX_CONSOLE_LOGS) {
        console.clear();
        consoleLogCount = 0;
        console.log('🧹 Console temizlendi (2 dakika geçti)');
    }
    
    // Firebase eski verileri temizle (sadece oda sahibi)
    if (isRoomOwner && roomRef) {
        // Eski urgent updates temizle (10 saniyeden eski)
        const tenSecondsAgo = Date.now() - 10000;
        roomRef.child('urgentUpdates').once('value', (snapshot) => {
            if (!snapshot.exists()) return;
            
            const updates = snapshot.val();
            Object.keys(updates).forEach(key => {
                if (updates[key].timestamp < tenSecondsAgo) {
                    roomRef.child('urgentUpdates').child(key).remove();
                }
            });
        });
        
        // Eski keyframes temizle (30 saniyeden eski)
        const thirtySecondsAgo = Date.now() - 30000;
        roomRef.child('keyframes').once('value', (snapshot) => {
            if (!snapshot.exists()) return;
            
            const keyframes = snapshot.val();
            Object.keys(keyframes).forEach(key => {
                if (keyframes[key].timestamp < thirtySecondsAgo) {
                    roomRef.child('keyframes').child(key).remove();
                }
            });
        });
        
        console.log('🧹 Firebase eski veriler temizlendi');
    }
}, 120000); // 2 dakika = 120000ms

console.log('✓ Otomatik temizleme sistemi aktif (2 dakikada bir)');
console.log('✓ Uygulama başlatıldı - Ultimate Versiyon - Hazır! 🚀');