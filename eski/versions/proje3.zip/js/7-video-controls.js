// ============================================
// VIDEO KONTROL FONKSİYONLARI - PRO VERSİYON
// 7'nin Basitliği + 15'in Hassasiyeti = Hibrit Sistem
// ============================================

// ============================================
// CLOCK DRIFT COMPENSATION (15'ten)
// ============================================
let clockOffset = 0;  // Server ile local saat farkı (ms)
let lastClockSync = 0;
let clockSyncReady = false;
const CLOCK_SYNC_INTERVAL = 60000; // Her 1 dakikada bir sync

function syncClock() {
    if (!roomRef) return;
    
    const t1 = Date.now();
    
    roomRef.child('serverTimestamp').set(firebase.database.ServerValue.TIMESTAMP);
    
    roomRef.child('serverTimestamp').once('value', (snap) => {
        const t4 = Date.now();
        const t2 = snap.val();
        
        const roundTrip = t4 - t1;
        const oneWay = roundTrip / 2;
        
        // Clock offset hesapla
        const newOffset = (t2 + oneWay) - t4;
        
        // Yumuşak geçiş için eski offset ile ortala
        if (clockOffset === 0) {
            clockOffset = newOffset;
        } else {
            clockOffset = (clockOffset * 0.7) + (newOffset * 0.3);
        }
        
        lastClockSync = Date.now();
        clockSyncReady = true;
        
        console.log('⏰ Clock sync:', {
            roundTrip: roundTrip + 'ms',
            offset: Math.round(clockOffset) + 'ms'
        });
    }, (error) => {
        console.error('❌ Clock sync hatası:', error);
    });
}

// Adjusted timestamp - server ile senkron zaman
function getAdjustedTime() {
    return clockSyncReady ? (Date.now() + clockOffset) : Date.now();
}

// Periyodik clock sync başlat
function startClockSync() {
    // İlk sync
    syncClock();
    
    // Periyodik sync
    setInterval(() => {
        syncClock();
    }, CLOCK_SYNC_INTERVAL);
}

// ============================================
// RATE LIMITING & DEBOUNCE (7'den)
// ============================================
let lastActionTime = 0;
let lastSeekTime = 0;
let seekDebounceTimeout = null;
const ACTION_COOLDOWN = 1000;      // 1 saniye
const SEEK_DEBOUNCE_DELAY = 2000;  // 2 saniye
const SEEK_REWIND_SECONDS = 4;     // 4 saniye geri sar

function canPerformAction() {
    const now = Date.now();
    if (now - lastActionTime < ACTION_COOLDOWN) {
        console.log('⏱️ Çok hızlı! Lütfen 1 saniye bekleyin...');
        showSyncStatus('⏱️ Lütfen 1 saniye bekleyin');
        return false;
    }
    lastActionTime = now;
    return true;
}

function canControlVideo() {
    if (!currentRoomData) return false;
    
    if (currentRoomData.controlMode === 'everyone') {
        return true;
    }
    
    return isRoomOwner;
}

// ============================================
// PRE-BUFFERING (15'ten uyarlandı)
// ============================================
function preBufferAndPlay(startTimestamp, currentTime) {
    if (!videoElement) return;
    
    const now = getAdjustedTime();
    const delay = startTimestamp - now;
    
    videoElement.currentTime = currentTime;
    
    if (delay > 1000) {
        // Pre-buffering aktif
        console.log('📦 Pre-buffering başlatılıyor... ' + Math.ceil(delay/1000) + 's');
        
        videoElement.play().then(() => {
            videoElement.pause(); // Buffer doldur ama durdur
            
            showSyncStatus(`⏳ Hazırlanıyor... ${Math.ceil(delay / 1000)}sn`);
            
            // Gerçek başlatma zamanı
            if (syncTimeout) clearTimeout(syncTimeout);
            syncTimeout = setTimeout(() => {
                videoElement.play().then(() => {
                    console.log('▶️ Video başlatıldı (pre-buffered)');
                }).catch(err => {
                    console.log('⚠️ Auto-play engellendi:', err);
                    showSyncStatus('⚠️ Videoyu başlatmak için ekrana tıklayın');
                });
            }, delay);
        }).catch(err => {
            console.log('⚠️ Pre-buffer başarısız:', err);
            
            // Fallback: Normal başlatma
            if (syncTimeout) clearTimeout(syncTimeout);
            syncTimeout = setTimeout(() => {
                videoElement.play().catch(err => {
                    console.log('⚠️ Auto-play engellendi (fallback):', err);
                    showSyncStatus('⚠️ Videoyu başlatmak için ekrana tıklayın');
                });
            }, delay);
        });
    } else {
        // Hemen başlat (delay yok veya çok kısa)
        if (syncTimeout) clearTimeout(syncTimeout);
        syncTimeout = setTimeout(() => {
            videoElement.play().catch(err => {
                console.log('⚠️ Auto-play engellendi:', err);
                showSyncStatus('⚠️ Videoyu başlatmak için ekrana tıklayın');
            });
        }, Math.max(0, delay));
    }
}

// ============================================
// BATCH UPDATES HELPER (7'den geliştirilmiş)
// ============================================
function sendBatchUpdate(videoState, keyframeData = null) {
    const now = getAdjustedTime();
    
    const updates = {};
    updates[`rooms/${currentRoomId}/videoState`] = videoState;
    
    if (keyframeData) {
        // Firebase key'lerde nokta olamaz - timestamp'i tam sayıya çevir
        const keyframeKey = Math.floor(now);
        updates[`rooms/${currentRoomId}/keyframes/${keyframeKey}`] = {
            timestamp: now,
            ...keyframeData
        };
    }
    
    return database.ref().update(updates);
}

// ============================================
// VIDEO CONTROL FONKSİYONLARI - HİBRİT
// ============================================

// PLAY VIDEO - Ayrı fonksiyon (HTML'den çağrılıyor)
function playVideo() {
    // Rate limiting
    if (!canPerformAction()) return;
    
    if (!canControlVideo()) {
        alert('⚠️ Bu odada sadece oda sahibi video kontrolü yapabilir!');
        return;
    }
    
    if (!videoElement) {
        alert('Video henüz yüklenmedi!');
        return;
    }
    
    // PLAY - Clock drift + Pre-buffering
    const startTimestamp = getAdjustedTime() + SYNC_DELAY;
    const currentTime = videoElement.currentTime;
    
    // Batch update
    sendBatchUpdate({
        isPlaying: true,
        currentTime: currentTime,
        startTimestamp: startTimestamp,
        lastUpdate: getAdjustedTime()
    }, {
        isPlaying: true,
        currentTime: currentTime,
        action: 'play'
    }).then(() => {
        console.log('✓ Play komutu Firebase\'e gönderildi (batch, adjusted time)');
    }).catch((error) => {
        console.error('❌ Firebase update hatası:', error);
        showSyncStatus('❌ Senkronizasyon hatası: ' + error.message);
    });
    
    // Pre-buffering ile başlat
    preBufferAndPlay(startTimestamp, currentTime);
    
    showSyncStatus('⏱️ 3 saniye sonra başlıyor...');
    console.log('▶️ Video 3 saniye sonra başlatılacak (adjusted time)');
}

// PAUSE VIDEO - Ayrı fonksiyon (HTML'den çağrılıyor)
function pauseVideo() {
    // Rate limiting
    if (!canPerformAction()) return;
    
    if (!canControlVideo()) {
        alert('⚠️ Bu odada sadece oda sahibi video kontrolü yapabilir!');
        return;
    }
    
    if (!videoElement) {
        alert('Video henüz yüklenmedi!');
        return;
    }
    
    // PAUSE
    videoElement.pause();
    
    // Batch update
    sendBatchUpdate({
        isPlaying: false,
        currentTime: videoElement.currentTime,
        startTimestamp: null,
        lastUpdate: getAdjustedTime()
    }, {
        isPlaying: false,
        currentTime: videoElement.currentTime,
        action: 'pause'
    }).then(() => {
        console.log('✓ Pause komutu Firebase\'e gönderildi (batch)');
    }).catch((error) => {
        console.error('❌ Firebase update hatası:', error);
        showSyncStatus('❌ Senkronizasyon hatası: ' + error.message);
    });
    
    console.log('⏸️ Video durduruldu');
}

function togglePlayPause() {
    // Rate limiting
    if (!canPerformAction()) return;
    
    if (!canControlVideo()) {
        alert('⚠️ Bu odada sadece oda sahibi video kontrolü yapabilir!');
        return;
    }
    
    if (!videoElement) {
        alert('Video henüz yüklenmedi!');
        return;
    }
    
    if (videoElement.paused) {
        // PLAY - Clock drift + Pre-buffering
        const startTimestamp = getAdjustedTime() + SYNC_DELAY;
        const currentTime = videoElement.currentTime;
        
        // Batch update
        sendBatchUpdate({
            isPlaying: true,
            currentTime: currentTime,
            startTimestamp: startTimestamp,
            lastUpdate: getAdjustedTime()
        }, {
            isPlaying: true,
            currentTime: currentTime,
            action: 'play'
        }).then(() => {
            console.log('✓ Play komutu Firebase\'e gönderildi (batch, adjusted time)');
        }).catch((error) => {
            console.error('❌ Firebase update hatası:', error);
            showSyncStatus('❌ Senkronizasyon hatası: ' + error.message);
        });
        
        // Pre-buffering ile başlat
        preBufferAndPlay(startTimestamp, currentTime);
        
        showSyncStatus('⏱️ 3 saniye sonra başlıyor...');
        console.log('▶️ Video 3 saniye sonra başlatılacak (adjusted time)');
        
    } else {
        // PAUSE
        videoElement.pause();
        
        // Batch update
        sendBatchUpdate({
            isPlaying: false,
            currentTime: videoElement.currentTime,
            startTimestamp: null,
            lastUpdate: getAdjustedTime()
        }, {
            isPlaying: false,
            currentTime: videoElement.currentTime,
            action: 'pause'
        }).then(() => {
            console.log('✓ Pause komutu Firebase\'e gönderildi (batch)');
        }).catch((error) => {
            console.error('❌ Firebase update hatası:', error);
            showSyncStatus('❌ Senkronizasyon hatası: ' + error.message);
        });
        
        console.log('⏸️ Video durduruldu');
    }
}

function stopVideo() {
    // Rate limiting
    if (!canPerformAction()) return;
    
    if (!canControlVideo()) {
        alert('⚠️ Bu odada sadece oda sahibi video kontrolü yapabilir!');
        return;
    }
    
    if (!videoElement) {
        alert('Video henüz yüklenmedi!');
        return;
    }
    
    videoElement.pause();
    videoElement.currentTime = 0;
    
    // Batch update
    sendBatchUpdate({
        isPlaying: false,
        currentTime: 0,
        startTimestamp: null,
        lastUpdate: getAdjustedTime()
    }, {
        isPlaying: false,
        currentTime: 0,
        action: 'stop'
    }).then(() => {
        console.log('✓ Stop komutu Firebase\'e gönderildi (batch)');
        showSyncStatus('⏹ Video başa sarıldı');
    }).catch((error) => {
        console.error('❌ Firebase update hatası:', error);
        showSyncStatus('❌ Senkronizasyon hatası: ' + error.message);
    });
    
    console.log('⏹ Video durduruldu ve başa sarıldı');
}

function seekVideo(seconds) {
    if (!canControlVideo()) {
        alert('⚠️ Bu odada sadece oda sahibi video kontrolü yapabilir!');
        return;
    }
    
    if (!videoElement) {
        alert('Video henüz yüklenmedi!');
        return;
    }
    
    const now = Date.now();
    
    // Debounce
    if (now - lastSeekTime < SEEK_DEBOUNCE_DELAY) {
        clearTimeout(seekDebounceTimeout);
        console.log('⏱️ Seek debounce sıfırlandı (2sn dolmadı)');
    }
    
    lastSeekTime = now;
    
    // Hedef zamanı hesapla
    const targetTime = Math.max(0, Math.min(videoElement.duration, videoElement.currentTime + seconds));
    
    // Geçici seek
    videoElement.currentTime = targetTime;
    console.log(`⏩ Geçici seek: ${seconds > 0 ? 'ileri' : 'geri'} ${Math.abs(seconds)}sn → ${targetTime.toFixed(1)}s`);
    showSyncStatus(`⏩ ${seconds > 0 ? '+' : ''}${seconds}sn (2sn bekleniyor...)`);
    
    // 2 saniye sonra senkron
    seekDebounceTimeout = setTimeout(() => {
        const finalTargetTime = videoElement.currentTime;
        const rewindTime = Math.max(0, finalTargetTime - SEEK_REWIND_SECONDS);
        
        const wasPlaying = !videoElement.paused;
        videoElement.pause();
        videoElement.currentTime = rewindTime;
        
        const startTimestamp = wasPlaying ? (getAdjustedTime() + SYNC_DELAY) : null;
        
        // Batch update
        sendBatchUpdate({
            isPlaying: wasPlaying,
            currentTime: rewindTime,
            startTimestamp: startTimestamp,
            lastUpdate: getAdjustedTime()
        }, {
            isPlaying: wasPlaying,
            currentTime: rewindTime,
            action: 'seek',
            seekType: 'keyboard'
        }).then(() => {
            console.log(`✓ Senkron seek: ${rewindTime.toFixed(1)}s → ${finalTargetTime.toFixed(1)}s (batch)`);
            console.log(`✓ 4 saniye geri sarıldı: ${finalTargetTime.toFixed(1)}s - 4s = ${rewindTime.toFixed(1)}s`);
            
            if (wasPlaying) {
                // Pre-buffering ile başlat
                preBufferAndPlay(startTimestamp, rewindTime);
                showSyncStatus(`⏱️ 3 saniyede ${formatTime(rewindTime)} başlıyor`);
            } else {
                showSyncStatus(`✓ Senkronize: ${formatTime(rewindTime)}`);
            }
        }).catch((error) => {
            console.error('❌ Firebase seek hatası:', error);
            showSyncStatus('❌ Senkronizasyon hatası: ' + error.message);
        });
    }, SEEK_DEBOUNCE_DELAY);
}

function seekToPosition(percentage) {
    if (!canControlVideo()) {
        alert('⚠️ Bu odada sadece oda sahibi video kontrolü yapabilir!');
        return;
    }
    
    if (!videoElement || !videoElement.duration) {
        console.log('❌ Video henüz hazır değil');
        return;
    }
    
    const now = Date.now();
    
    // Debounce
    if (now - lastSeekTime < SEEK_DEBOUNCE_DELAY) {
        clearTimeout(seekDebounceTimeout);
        console.log('⏱️ Seek bar debounce sıfırlandı (2sn dolmadı)');
    }
    
    lastSeekTime = now;
    
    // Hedef zamanı hesapla
    const targetTime = videoElement.duration * percentage;
    
    // Geçici seek
    videoElement.currentTime = targetTime;
    console.log(`🎯 Seek bar: %${(percentage * 100).toFixed(1)} → ${targetTime.toFixed(1)}s`);
    showSyncStatus(`🎯 ${formatTime(targetTime)} (2sn bekleniyor...)`);
    
    // 2 saniye sonra senkron
    seekDebounceTimeout = setTimeout(() => {
        const finalTargetTime = videoElement.currentTime;
        const rewindTime = Math.max(0, finalTargetTime - SEEK_REWIND_SECONDS);
        
        const wasPlaying = !videoElement.paused;
        videoElement.pause();
        videoElement.currentTime = rewindTime;
        
        const startTimestamp = wasPlaying ? (getAdjustedTime() + SYNC_DELAY) : null;
        
        // Batch update
        sendBatchUpdate({
            isPlaying: wasPlaying,
            currentTime: rewindTime,
            startTimestamp: startTimestamp,
            lastUpdate: getAdjustedTime()
        }, {
            isPlaying: wasPlaying,
            currentTime: rewindTime,
            action: 'seek',
            seekType: 'seekbar'
        }).then(() => {
            console.log(`✓ Senkron seek bar: ${rewindTime.toFixed(1)}s → ${finalTargetTime.toFixed(1)}s (batch)`);
            console.log(`✓ 4 saniye geri sarıldı: ${finalTargetTime.toFixed(1)}s - 4s = ${rewindTime.toFixed(1)}s`);
            
            if (wasPlaying) {
                // Pre-buffering ile başlat
                preBufferAndPlay(startTimestamp, rewindTime);
                showSyncStatus(`⏱️ 3 saniyede ${formatTime(rewindTime)} başlıyor`);
            } else {
                showSyncStatus(`✓ Senkronize: ${formatTime(rewindTime)}`);
            }
        }).catch((error) => {
            console.error('❌ Firebase seek bar hatası:', error);
            showSyncStatus('❌ Senkronizasyon hatası: ' + error.message);
        });
    }, SEEK_DEBOUNCE_DELAY);
}

function setPlaybackRate(rate) {
    if (!videoElement) {
        alert('Video henüz yüklenmedi!');
        return;
    }
    
    videoElement.playbackRate = rate;
    console.log('🎚️ Oynatma hızı:', rate);
}

function formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}

// ============================================
// CLEANUP
// ============================================
window.addEventListener('beforeunload', () => {
    if (syncTimeout) clearTimeout(syncTimeout);
    if (seekDebounceTimeout) clearTimeout(seekDebounceTimeout);
});

// ============================================
// BAŞLATMA
// ============================================
console.log('✓ Video kontrol fonksiyonları yüklendi (PRO VERSİYON)');
console.log('   → Clock drift compensation: ±50-100ms hassasiyet');
console.log('   → Pre-buffering: Buffer önceden doluyor');
console.log('   → Batch updates: Firebase çağrıları optimize');
console.log('   → Rate limiting: 1sn cooldown');
console.log('   → Debounce: 2sn seek debounce');
console.log('   → 4 saniye geri sarma');
console.log('   → Firebase error handling');
console.log('   → Global timezone desteği ✓');