# 🚀 VR SİNEMA ULTRA - ÖNERİ 3 VERSİYONU

## 📦 Dosyalar (7 Adet)
```
index.html           (6 KB)    - Ana sayfa + VR sahnesi (DEĞİŞMEDİ)
config.js            (3.2 KB)  - Firebase config + tier parametreleri ✅ YENİ
ui.js                (12.5 KB) - UI yönetimi + drift tracking ✅ GÜNCELLEME
core.js              (18 KB)   - Adaptive tier senkronizasyon ✅ TAMAMEN YENİ
vr-controls.js       (7.6 KB)  - VR panel + seek bar (DEĞİŞMEDİ)
styles.css           (4.8 KB)  - Tüm stiller (DEĞİŞMEDİ)
firebase-rules.json  (8 KB)    - Firebase rules + drift validation ✅ YENİ
```

## ⚙️ Öneri 3: Adaptive Tier Sistemi

### 🎯 Tier Eşikleri

| Tier | Gecikme | Kullanıcı Hızı | Grup Davranışı |
|------|---------|----------------|----------------|
| **Tier 1** | 0-3sn | 1.0x (Normal) | Müdahale yok |
| **Tier 2** | 3-7sn | 1.1x (Hafif hızlanma) | Sadece geride kalan hızlanır |
| **Tier 3** | 7-15sn | 1.25x (Geride kalan)<br>0.88x (Grup) | 3+ kişi gerideyse grup yavaşlar |
| **Critical** | 15sn+ | 1.0x | "Yeniden katıl" mesajı |

### 🔄 Sistem Mantığı

#### Senaryo 1: Tek Kullanıcı Geride (7-15sn)
- **Durum**: Sadece 1 kişi 10sn geride
- **Sonuç**: O kişi 1.25x hızlanır, grup normal devam eder
- **Mantık**: Az sayıda geride kalan için grup yavaşlamaz

#### Senaryo 2: 3+ Kullanıcı Geride (7-15sn)
- **Durum**: 3 veya daha fazla kişi 7sn+ geride
- **Sonuç**: 
  - Geride kalanlar: 1.25x hızlanır
  - İyi durumda olanlar: 0.88x yavaşlar (grup bekliyor)
- **Mantık**: Grup birlikte kalmayı tercih eder

#### Senaryo 3: Kritik Gecikme (15sn+)
- **Durum**: Herhangi bir kullanıcı 15sn+ geride
- **Sonuç**: "❌ Bağlantı sorunu! Lütfen yeniden katılın" mesajı
- **Mantık**: Bu kadar gecikme bağlantı sorunudur, yenileme gerekir

### 📊 Yeni Parametreler (config.js)

```javascript
// Tier Eşikleri
const TIER_1_THRESHOLD = 3000;        // 3 SANİYE
const TIER_2_THRESHOLD = 7000;        // 7 SANİYE
const TIER_3_THRESHOLD = 15000;       // 15 SANİYE
const TIER_CRITICAL_THRESHOLD = 20000; // 20 SANİYE

// Hız Ayarları
const TIER_2_LAGGING_SPEED = 1.1;     // Hafif hızlanma
const TIER_3_GROUP_SPEED = 0.88;      // Grup yavaşlama
const TIER_3_LAGGING_SPEED = 1.25;    // Geride kalan hızlanma

// Grup Kontrolü
const GROUP_LAGGING_MIN_COUNT = 3;    // Min 3 kişi gerideyse grup yavaşlar

// Diğer
const SEEK_REWIND_SECONDS = 2;        // 4→2 (daha az agresif)
const DRIFT_UPDATE_INTERVAL = 2000;   // Firebase'e drift yazma
```

### 🔥 Firebase Schema Değişiklikleri

#### Yeni Alanlar: `activeViewers/{userId}/`
```javascript
{
  timestamp: number,        // ✅ Mevcut
  isOwner: boolean,         // ✅ Mevcut
  currentDrift: number,     // ❌ YENİ (0-30000 ms)
  playbackRate: number      // ❌ YENİ (0.5-2.0)
}
```

## 🚀 Kurulum

### 1. Dosyaları Yerleştir
```bash
web-server/
├── index.html
├── config.js           ✅ YENİ
├── ui.js               ✅ GÜNCELLEME
├── core.js             ✅ TAMAMEN YENİ
├── vr-controls.js
├── styles.css
└── firebase-rules.json ✅ YENİ (Firebase Console'a kopyalanacak)
```

### 2. Firebase Rules Güncelle
1. Firebase Console → Realtime Database → Rules
2. `firebase-rules.json` içeriğini kopyala
3. Yapıştır ve "Publish" (Yayınla)

### 3. Web Server Başlat
```bash
python -m http.server 8000
# VEYA
npx http-server -p 8000
```

### 4. Tarayıcıda Aç
```
http://localhost:8000
```

## 🎮 Kullanım

### Test Senaryoları

#### Test 1: Normal İzleme
1. 2 kullanıcı odaya katıl
2. Play butonuna bas
3. Her iki kullanıcı da 1.0x hızda izler
4. ✅ Tier 1 aktif

#### Test 2: Tek Kullanıcı Geride
1. 3 kullanıcı odaya katıl
2. 1 kullanıcı interneti yavaşlat (veya pause-play ile 10sn geri kal)
3. Geride kalan: 1.25x hızlanır
4. Diğer 2 kullanıcı: 1.0x normal devam eder
5. ✅ Tier 3 - Solo catch-up

#### Test 3: 3+ Kullanıcı Geride
1. 5 kullanıcı odaya katıl
2. 3 kullanıcı interneti yavaşlat (10sn+ geride kal)
3. 3 geride kalan: 1.25x hızlanır
4. 2 iyi durumda: 0.88x yavaşlar
5. Ekranda: "⏳ Grup bekliyor... (3 kişi geride)"
6. ✅ Tier 3 - Grup yavaşlama

#### Test 4: Kritik Gecikme
1. 2 kullanıcı odaya katıl
2. 1 kullanıcı interneti tamamen kes, 20sn bekle
3. Geride kalan kullanıcı: "❌ Bağlantı sorunu! Lütfen yeniden katılın"
4. ✅ Tier Critical

## 📊 Performans ve İyileştirmeler

### Önceki Sistem vs Öneri 3

| Özellik | Önceki | Öneri 3 |
|---------|--------|---------|
| **Drift Tracking** | Yok | ✅ Firebase'e yazılır |
| **Grup Bilinci** | Yok | ✅ Grup durumu analiz edilir |
| **Yavaşlatma** | Yok | ✅ 0.88x grup yavaşlama |
| **Kademeli Yaklaşım** | Tek eşik (5sn) | ✅ 4 tier (3/7/15/20sn) |
| **Firebase Write** | ~30-40/dakika | ~40-50/dakika (+%25) |
| **Hassasiyet** | ±20-50ms | ±20-50ms (aynı) |
| **Kullanıcı Bildirimi** | Minimal | ✅ Detaylı mesajlar |

### Firebase Kullanımı
- **Önceki**: Keyframe (7sn) + urgentUpdate + videoState
- **Yeni**: Önceki + drift tracking (2sn)
- **Artış**: %20-25 daha fazla write
- **Kota**: Ücretsiz plan 100k/gün → 50-60k/gün kullanım (YETER)

## ⚠️ Önemli Notlar

### 1. Firebase Rules Mutlaka Güncellenmeli
`firebase-rules.json` dosyasını Firebase Console'a kopyalamadan sistem çalışmaz!

### 2. Grup Yavaşlama Koşulu
Minimum 3 kullanıcı 7sn+ geride kalmalı. Aksi halde grup yavaşlamaz.

### 3. playbackRate Sınırları
HTML5 Video API genelde 0.25x-4x destekler, ama bazı videolar 0.5x-2x sınırlar. Öneri 3'te:
- En yavaş: 0.88x (güvenli)
- En hızlı: 1.25x (güvenli)

### 4. Drift Güncelleme
Her 2sn'de bir Firebase'e yazılır. Eğer drift değişimi <500ms ise yazma atlanır (Firebase write tasarrufu).

### 5. SMOOTH_THRESHOLD Kaldırıldı
Artık tier sistemi kullanılıyor. Eski `SMOOTH_THRESHOLD = 5000` kaldırıldı.

## 🐛 Sorun Giderme

### "currentDrift is not defined" Hatası
- **Sebep**: Firebase rules güncellenmemiş
- **Çözüm**: `firebase-rules.json` → Firebase Console'a yapıştır

### Grup Yavaşlamıyor
- **Sebep**: 3'ten az kullanıcı geride
- **Kontrol**: Console'da "Grup: X izleyici | Y geride" mesajına bak
- **Çözüm**: 3+ kullanıcı 7sn+ geride kalmalı

### "Yeniden Katıl" Mesajı Çok Erken Çıkıyor
- **Sebep**: Düşük internet hızı
- **Çözüm**: `TIER_CRITICAL_THRESHOLD` değerini 25000 (25sn) yap

### Video Hızı Çok Hızlı/Yavaş
- **Ayar 1**: `TIER_3_LAGGING_SPEED` → 1.25 → 1.15 (daha yumuşak)
- **Ayar 2**: `TIER_3_GROUP_SPEED` → 0.88 → 0.92 (daha az yavaş)

## 🎉 Yeni Özellikler

### ✅ Grup Durumu Takibi
```javascript
const groupStatus = await getGroupSyncStatus();
// {
//   totalViewers: 5,
//   laggingCount: 3,
//   averageDrift: 8500,
//   maxDrift: 12000,
//   laggingUsers: [...]
// }
```

### ✅ Kendi Drift'ini Paylaş
```javascript
updateMyDrift(drift, playbackRate);
// Firebase'e yazar, diğer kullanıcılar görür
```

### ✅ Gelişmiş Bildirimler
- "⚡ Hızlanıyorsunuz... (7.2sn geride)"
- "⏳ Grup bekliyor... (3 kişi geride)"
- "❌ Bağlantı sorunu! Lütfen yeniden katılın (15sn+ gecikme)"

### ✅ Console Logları
```
📊 Drift: 8.45s (8450ms) | Target: 123.5s | Current: 115.1s
👥 Grup: 5 izleyici | 3 geride | Ortalama: 8200ms
🚀 Tier 3: Geride - Hızlanma (1.25x) | Grup: 3 kişi geride
```

## 📝 Değişiklik Özeti

### config.js
- ❌ `SMOOTH_THRESHOLD` kaldırıldı
- ✅ 4 tier eşiği eklendi
- ✅ 3 hız parametresi eklendi
- ✅ Drift tracking interval eklendi
- ✅ `SEEK_REWIND_SECONDS` 4→2

### core.js
- ✅ `getGroupSyncStatus()` fonksiyonu eklendi
- ✅ `updateMyDrift()` fonksiyonu eklendi
- ✅ `startDriftTracking()` fonksiyonu eklendi
- ✅ `applySyncCorrection()` tamamen yeniden yazıldı
- ✅ Tier sistemi entegre edildi

### ui.js
- ✅ `showSyncStatus()` timeout 3→5sn
- ✅ `joinRoom()` içinde `currentDrift` ve `playbackRate` eklendi

### firebase-rules.json
- ✅ `activeViewers/{userId}/currentDrift` validation
- ✅ `activeViewers/{userId}/playbackRate` validation

## 🎯 Sonuç

Öneri 3 başarıyla uygulandı! Sistem artık:
- ✅ Grup durumunu analiz ediyor
- ✅ Kademeli yaklaşım kullanıyor (4 tier)
- ✅ Grup yavaşlatma yapıyor (3+ geride)
- ✅ Kritik gecikmelerde kullanıcıyı uyarıyor
- ✅ Detaylı bildirimler gösteriyor

**İyi seyirler!** 🎬🎉

---

**Versiyon**: ULTRA - Öneri 3  
**Tarih**: Ocak 2025  
**Özellik**: Adaptive Tier Senkronizasyon  
**Hassasiyet**: ±20-50ms  
**Tier Sistemi**: 3/7/15/20sn eşikleri
