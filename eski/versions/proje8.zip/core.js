// ============================================
// CORE - HİBRİT SENKRONIZASYON SİSTEMİ
// ÖNERİ 3: Adaptive Tier Sistemi
// ============================================

// ============================================
// CLOCK SYNC (Saat Senkronizasyonu)
// ============================================

function initClockSync() {
    console.log('⏰ Clock sync başlatılıyor...');
    
    syncServerTime().then(() => {
        clockSyncReady = true;
        console.log(`✅ Clock sync: ${clockOffset}ms offset`);
        
        setInterval(() => {
            syncServerTime();
        }, CLOCK_SYNC_INTERVAL);
    });
}

async function syncServerTime() {
    const samples = [];
    
    for (let i = 0; i < 3; i++) {
        const t0 = Date.now();
        
        await roomRef.child('serverTimestamp').set(firebase.database.ServerValue.TIMESTAMP);
        
        const snapshot = await roomRef.child('serverTimestamp').once('value');
        const serverTime = snapshot.val();
        
        const t1 = Date.now();
        const rtt = t1 - t0;
        const offset = serverTime - (t0 + rtt / 2);
        
        samples.push(offset);
        
        await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    clockOffset = Math.round(samples.reduce((a, b) => a + b) / samples.length);
    console.log(`⏰ Clock offset: ${clockOffset}ms (RTT: ${samples.map(s => Math.abs(s)).join(', ')}ms)`);
}

function getServerTime() {
    return Date.now() + clockOffset;
}

// ============================================
// ÖNERİ 3: GRUP DURUMU TAKİBİ
// ============================================

async function getGroupSyncStatus() {
    try {
        const snapshot = await roomRef.child('activeViewers').once('value');
        const viewers = snapshot.val() || {};
        
        const drifts = Object.entries(viewers)
            .filter(([uid, v]) => !v.isOwner && v.currentDrift !== undefined)
            .map(([uid, v]) => ({
                uid: uid,
                drift: v.currentDrift,
                playbackRate: v.playbackRate || 1.0
            }));
        
        const laggingUsers = drifts.filter(d => d.drift > TIER_3_THRESHOLD);
        const averageDrift = drifts.length > 0 
            ? drifts.reduce((a, b) => a + b.drift, 0) / drifts.length 
            : 0;
        const maxDrift = drifts.length > 0 
            ? Math.max(...drifts.map(d => d.drift)) 
            : 0;
        
        return {
            totalViewers: drifts.length,
            laggingCount: laggingUsers.length,
            averageDrift: averageDrift,
            maxDrift: maxDrift,
            laggingUsers: laggingUsers
        };
    } catch (error) {
        console.error('❌ Grup durumu alınamadı:', error);
        return {
            totalViewers: 0,
            laggingCount: 0,
            averageDrift: 0,
            maxDrift: 0,
            laggingUsers: []
        };
    }
}

function updateMyDrift(drift, playbackRate) {
    if (!auth.currentUser || !roomRef) return;
    
    const userId = auth.currentUser.uid;
    const driftMs = Math.round(drift * 1000);
    
    // Sadece değişiklik varsa güncelle (Firebase write azaltma)
    if (Math.abs(driftMs - lastDrift) < 500 && Math.abs(playbackRate - lastPlaybackRate) < 0.05) {
        return;
    }
    
    lastDrift = driftMs;
    lastPlaybackRate = playbackRate;
    
    roomRef.child(`activeViewers/${userId}`).update({
        currentDrift: driftMs,
        playbackRate: playbackRate,
        timestamp: getServerTime()
    }).catch(err => {
        console.error('❌ Drift güncelleme hatası:', err);
    });
}

function startDriftTracking() {
    if (driftUpdateInterval) {
        clearInterval(driftUpdateInterval);
    }
    
    driftUpdateInterval = setInterval(() => {
        if (!videoElement || !roomRef) return;
        
        // Mevcut drift'i hesapla (listenVideoState'ten gelecek)
        // Bu interval sadece periyodik güncelleme için
        const currentRate = videoElement.playbackRate || 1.0;
        updateMyDrift(lastDrift / 1000, currentRate);
    }, DRIFT_UPDATE_INTERVAL);
    
    console.log('📊 Drift tracking başlatıldı');
}

function stopDriftTracking() {
    if (driftUpdateInterval) {
        clearInterval(driftUpdateInterval);
        driftUpdateInterval = null;
    }
}

// ============================================
// VİDEO KONTROL
// ============================================

function playVideo() {
    if (!videoElement || !roomRef) return;
    
    const canControl = isRoomOwner || currentRoomData?.controlMode === 'everyone';
    
    if (!canControl) {
        requestVideoControl('play');
        return;
    }
    
    console.log('▶️ Play - ' + SYNC_DELAY + 'ms bekleniyor...');
    
    const startTime = getServerTime() + SYNC_DELAY;
    const currentTime = videoElement.currentTime;
    
    roomRef.child('videoState').update({
        isPlaying: false,
        currentTime: currentTime,
        startTimestamp: startTime,
        lastUpdate: getServerTime()
    });
    
    const urgentUpdate = {
        action: 'play',
        timestamp: getServerTime(),
        currentTime: currentTime,
        startTimestamp: startTime,
        processed: false
    };
    
    roomRef.child('urgentUpdates').push(urgentUpdate);
    
    setTimeout(() => {
        if (videoElement) {
            videoElement.play().catch(err => {
                console.error('❌ Play hatası:', err);
                alert('⚠️ Oynatma hatası! Ekrana tıklayın.');
            });
        }
    }, SYNC_DELAY);
}

function pauseVideo() {
    if (!videoElement || !roomRef) return;
    
    const canControl = isRoomOwner || currentRoomData?.controlMode === 'everyone';
    
    if (!canControl) {
        requestVideoControl('pause');
        return;
    }
    
    console.log('⏸️ Pause');
    
    videoElement.pause();
    
    roomRef.child('videoState').update({
        isPlaying: false,
        currentTime: videoElement.currentTime,
        startTimestamp: null,
        lastUpdate: getServerTime()
    });
    
    const urgentUpdate = {
        action: 'pause',
        timestamp: getServerTime(),
        currentTime: videoElement.currentTime,
        processed: false
    };
    
    roomRef.child('urgentUpdates').push(urgentUpdate);
}

function stopVideo() {
    if (!videoElement || !roomRef) return;
    
    const canControl = isRoomOwner || currentRoomData?.controlMode === 'everyone';
    
    if (!canControl) {
        requestVideoControl('stop');
        return;
    }
    
    console.log('⏹️ Stop');
    
    videoElement.pause();
    videoElement.currentTime = 0;
    
    roomRef.child('videoState').update({
        isPlaying: false,
        currentTime: 0,
        startTimestamp: null,
        lastUpdate: getServerTime()
    });
}

function seekVideo(seconds) {
    if (!videoElement || !roomRef) return;
    
    const canControl = isRoomOwner || currentRoomData?.controlMode === 'everyone';
    
    if (!canControl) {
        requestVideoControl('seek', { seconds });
        return;
    }
    
    const now = Date.now();
    if (now - lastSeekTime < SEEK_DEBOUNCE_DELAY) {
        console.log('⏭️ Seek debounced');
        return;
    }
    lastSeekTime = now;
    
    const newTime = Math.max(0, Math.min(videoElement.duration, videoElement.currentTime + seconds));
    
    console.log(`⏭️ Seek: ${seconds > 0 ? '+' : ''}${seconds}s → ${newTime.toFixed(1)}s`);
    
    videoElement.currentTime = newTime;
    
    const isPlaying = !videoElement.paused;
    
    roomRef.child('videoState').update({
        isPlaying: isPlaying,
        currentTime: newTime,
        startTimestamp: isPlaying ? getServerTime() : null,
        lastUpdate: getServerTime()
    });
    
    const urgentUpdate = {
        action: 'seek',
        timestamp: getServerTime(),
        currentTime: newTime,
        startTimestamp: isPlaying ? getServerTime() : null,
        shouldPlay: isPlaying,
        processed: false
    };
    
    roomRef.child('urgentUpdates').push(urgentUpdate);
}

function seekToPosition(percentage) {
    if (!videoElement || !videoElement.duration) return;
    
    const canControl = isRoomOwner || currentRoomData?.controlMode === 'everyone';
    
    if (!canControl) {
        requestVideoControl('seek', { percentage });
        return;
    }
    
    const targetTime = videoElement.duration * percentage;
    const seekAmount = targetTime - videoElement.currentTime;
    
    seekVideo(seekAmount);
}

// ============================================
// ÖNERİ 3: YENİ SENKRONIZASYON MANTIĞI
// ============================================

async function applySyncCorrection(targetTime, targetPlaying, urgentUpdate = false) {
    if (!videoElement) return;
    
    const currentTime = videoElement.currentTime;
    const drift = Math.abs(targetTime - currentTime);
    const driftMs = drift * 1000;
    
    console.log(`📊 Drift: ${drift.toFixed(2)}s (${driftMs.toFixed(0)}ms) | Target: ${targetTime.toFixed(2)}s | Current: ${currentTime.toFixed(2)}s`);
    
    // URGENT UPDATE (play/pause/seek) - Tier bypass
    if (urgentUpdate) {
        console.log('⚡ Urgent update - Tier bypass');
        videoElement.currentTime = targetTime - SEEK_REWIND_SECONDS;
        if (targetPlaying) {
            videoElement.play().catch(err => console.error('❌ Play hatası:', err));
        } else {
            videoElement.pause();
        }
        videoElement.playbackRate = 1.0;
        updateMyDrift(0, 1.0);
        return;
    }
    
    // Grup durumunu al
    const groupStatus = await getGroupSyncStatus();
    
    console.log(`👥 Grup: ${groupStatus.totalViewers} izleyici | ${groupStatus.laggingCount} geride | Ortalama: ${groupStatus.averageDrift.toFixed(0)}ms`);
    
    // TIER 1: Normal (0-3sn)
    if (driftMs < TIER_1_THRESHOLD) {
        if (videoElement.playbackRate !== 1.0) {
            console.log('✅ Tier 1: Normal hız');
            videoElement.playbackRate = 1.0;
        }
        updateMyDrift(drift, 1.0);
    }
    // TIER 2: Hafif catch-up (3-7sn)
    else if (driftMs < TIER_2_THRESHOLD) {
        console.log(`⚡ Tier 2: Hafif hızlanma (${TIER_2_LAGGING_SPEED}x)`);
        videoElement.playbackRate = TIER_2_LAGGING_SPEED;
        updateMyDrift(drift, TIER_2_LAGGING_SPEED);
        showSyncStatus(`⚡ Hızlanıyorsunuz... (${drift.toFixed(1)}sn geride)`);
    }
    // TIER 3: Grup yavaşlama (7-15sn)
    else if (driftMs < TIER_3_THRESHOLD) {
        const isLagging = driftMs > TIER_2_THRESHOLD;
        
        // Grup yavaşlama şartı: 3+ kişi geride
        if (groupStatus.laggingCount >= GROUP_LAGGING_MIN_COUNT) {
            if (isLagging) {
                // Ben gerideyim → Hızlan
                console.log(`🚀 Tier 3: Geride - Hızlanma (${TIER_3_LAGGING_SPEED}x) | Grup: ${groupStatus.laggingCount} kişi geride`);
                videoElement.playbackRate = TIER_3_LAGGING_SPEED;
                showSyncStatus(`🚀 Hızlanıyorsunuz... (${groupStatus.laggingCount} kişi geride)`);
            } else {
                // Ben iyiyim → Yavaşla (grup bekliyor)
                console.log(`⏳ Tier 3: İyi - Grup bekliyor (${TIER_3_GROUP_SPEED}x) | ${groupStatus.laggingCount} kişi geride`);
                videoElement.playbackRate = TIER_3_GROUP_SPEED;
                showSyncStatus(`⏳ Grup bekliyor... (${groupStatus.laggingCount} kişi geride)`);
            }
        } else {
            // Grup yavaşlamıyor, sadece ben varım ya da az kişi geride
            if (isLagging) {
                console.log(`⚡ Tier 3: Solo hızlanma (${TIER_3_LAGGING_SPEED}x) | Grup yok`);
                videoElement.playbackRate = TIER_3_LAGGING_SPEED;
                showSyncStatus(`⚡ Hızlanıyorsunuz... (${drift.toFixed(1)}sn geride)`);
            } else {
                videoElement.playbackRate = 1.0;
            }
        }
        
        updateMyDrift(drift, videoElement.playbackRate);
    }
    // TIER CRITICAL: Yeniden katıl (15sn+)
    else {
        console.error(`❌ Tier Critical: ${drift.toFixed(1)}sn gecikme - Yeniden katılın!`);
        videoElement.playbackRate = 1.0;
        updateMyDrift(drift, 0);
        showSyncStatus('❌ Bağlantı sorunu! Lütfen yeniden katılın (15sn+ gecikme)');
        
        // Opsiyonel: 10sn sonra otomatik reload
        // setTimeout(() => {
        //     if (confirm('Bağlantı sorunu tespit edildi. Sayfayı yenilemek ister misiniz?')) {
        //         location.reload();
        //     }
        // }, 10000);
    }
    
    // Play/Pause durumu
    if (targetPlaying && videoElement.paused) {
        videoElement.play().catch(err => console.error('❌ Play hatası:', err));
    } else if (!targetPlaying && !videoElement.paused) {
        videoElement.pause();
    }
}

// ============================================
// HİBRİT SENKRONIZASYON
// ============================================

function initHybridSync() {
    console.log('🔄 Hibrit senkronizasyon başlatılıyor...');
    
    initClockSync();
    listenVideoState();
    listenUrgentUpdates();
    
    if (isRoomOwner) {
        startKeyframeSending();
        processControlRequests();
    } else {
        listenKeyframes();
    }
    
    startDriftTracking();
    
    console.log('✅ Hibrit senkronizasyon aktif');
}

function listenVideoState() {
    roomRef.child('videoState').on('value', (snapshot) => {
        const state = snapshot.val();
        if (!state || !videoElement) return;
        
        const { isPlaying, currentTime, startTimestamp } = state;
        
        let targetTime = currentTime;
        
        if (isPlaying && startTimestamp) {
            const elapsed = (getServerTime() - startTimestamp) / 1000;
            targetTime = currentTime + elapsed;
        }
        
        applySyncCorrection(targetTime, isPlaying, false);
    });
}

function startKeyframeSending() {
    if (keyframeInterval) {
        clearInterval(keyframeInterval);
    }
    
    keyframeInterval = setInterval(() => {
        if (!videoElement || !roomRef) return;
        
        const now = getServerTime();
        
        if (now - lastKeyframeTimestamp < KEYFRAME_INTERVAL - 500) {
            return;
        }
        
        lastKeyframeTimestamp = now;
        
        const keyframe = {
            timestamp: now,
            currentTime: videoElement.currentTime,
            isPlaying: !videoElement.paused,
            playbackRate: videoElement.playbackRate,
            startTimestamp: !videoElement.paused ? now : null
        };
        
        roomRef.child('keyframes').push(keyframe);
        
        const twoMinutesAgo = now - 120000;
        roomRef.child('keyframes').orderByChild('timestamp').endAt(twoMinutesAgo).once('value', (snapshot) => {
            snapshot.forEach((child) => {
                child.ref.remove();
            });
        });
        
        console.log('📸 Keyframe:', keyframe.currentTime.toFixed(1) + 's');
    }, KEYFRAME_INTERVAL);
    
    console.log('📸 Keyframe gönderimi başlatıldı (7sn)');
}

function listenKeyframes() {
    roomRef.child('keyframes').orderByChild('timestamp').limitToLast(1).on('child_added', (snapshot) => {
        const keyframe = snapshot.val();
        if (!keyframe || !videoElement) return;
        
        const age = getServerTime() - keyframe.timestamp;
        
        if (age > 10000) {
            console.log('📸 Keyframe çok eski:', (age / 1000).toFixed(1) + 's');
            return;
        }
        
        let targetTime = keyframe.currentTime;
        
        if (keyframe.isPlaying && keyframe.startTimestamp) {
            const elapsed = (getServerTime() - keyframe.startTimestamp) / 1000;
            targetTime = keyframe.currentTime + elapsed;
        }
        
        console.log('📸 Keyframe alındı:', targetTime.toFixed(1) + 's');
        
        applySyncCorrection(targetTime, keyframe.isPlaying, false);
    });
}

function listenUrgentUpdates() {
    roomRef.child('urgentUpdates').orderByChild('timestamp').startAt(getServerTime()).on('child_added', (snapshot) => {
        const update = snapshot.val();
        if (!update || !videoElement || update.processed) return;
        
        const age = getServerTime() - update.timestamp;
        
        if (age > 10000) {
            snapshot.ref.remove();
            return;
        }
        
        console.log('⚡ Urgent update:', update.action, '| Age:', age + 'ms');
        
        if (update.action === 'play') {
            const delay = update.startTimestamp - getServerTime();
            
            if (delay > 0) {
                setTimeout(() => {
                    if (videoElement) {
                        videoElement.currentTime = update.currentTime;
                        videoElement.play().catch(err => console.error('❌ Play hatası:', err));
                    }
                }, delay);
            } else {
                const elapsed = (getServerTime() - update.startTimestamp) / 1000;
                const targetTime = update.currentTime + elapsed;
                applySyncCorrection(targetTime, true, true);
            }
        } else if (update.action === 'pause') {
            applySyncCorrection(update.currentTime, false, true);
        } else if (update.action === 'seek') {
            applySyncCorrection(update.currentTime, update.shouldPlay || false, true);
        }
        
        snapshot.ref.update({ processed: true });
        
        setTimeout(() => {
            snapshot.ref.remove();
        }, 30000);
    });
}

function requestVideoControl(action, params = {}) {
    if (!roomRef || !auth.currentUser) return;
    
    console.log('📨 Kontrol isteği:', action);
    
    const request = {
        userId: auth.currentUser.uid,
        action: action,
        timestamp: getServerTime(),
        processed: false,
        params: params
    };
    
    roomRef.child('requests').push(request);
    
    alert(`📨 ${action.toUpperCase()} isteği gönderildi!`);
}

function processControlRequests() {
    roomRef.child('requests').orderByChild('processed').equalTo(false).on('child_added', (snapshot) => {
        const request = snapshot.val();
        if (!request || request.processed) return;
        
        const age = getServerTime() - request.timestamp;
        
        if (age > 30000) {
            snapshot.ref.remove();
            return;
        }
        
        console.log('📨 İstek alındı:', request.action, 'from', request.userId);
        
        const response = confirm(`📨 Kullanıcı "${request.action}" isteği gönderdi. Kabul ediyor musunuz?`);
        
        if (response) {
            if (request.action === 'play') {
                playVideo();
            } else if (request.action === 'pause') {
                pauseVideo();
            } else if (request.action === 'stop') {
                stopVideo();
            } else if (request.action === 'seek' && request.params) {
                if (request.params.seconds) {
                    seekVideo(request.params.seconds);
                } else if (request.params.percentage) {
                    seekToPosition(request.params.percentage);
                }
            }
        }
        
        snapshot.ref.update({ processed: true });
        
        setTimeout(() => {
            snapshot.ref.remove();
        }, 60000);
    });
}

// ============================================
// KLAVYE KISAYOLLARI
// ============================================

document.addEventListener('keydown', (e) => {
    if (!videoElement) return;
    
    if (e.code === 'Space') {
        e.preventDefault();
        if (videoElement.paused) {
            playVideo();
        } else {
            pauseVideo();
        }
    } else if (e.code === 'ArrowLeft') {
        e.preventDefault();
        seekVideo(-10);
    } else if (e.code === 'ArrowRight') {
        e.preventDefault();
        seekVideo(10);
    } else if (e.code === 'ArrowUp' || e.code === 'KeyW') {
        e.preventDefault();
        moveScreen('up');
    } else if (e.code === 'ArrowDown' || e.code === 'KeyS') {
        e.preventDefault();
        moveScreen('down');
    } else if (e.code === 'KeyA') {
        e.preventDefault();
        moveScreen('left');
    } else if (e.code === 'KeyD') {
        e.preventDefault();
        moveScreen('right');
    } else if (e.code === 'KeyR') {
        e.preventDefault();
        moveScreen('reset');
    } else if (e.code === 'KeyM') {
        e.preventDefault();
        videoElement.muted = !videoElement.muted;
    } else if (e.code === 'KeyF') {
        e.preventDefault();
        if (document.fullscreenElement) {
            document.exitFullscreen();
        } else {
            document.documentElement.requestFullscreen();
        }
    }
});

console.log('✅ Core yüklendi - Öneri 3 Adaptive Tier Sistemi');
